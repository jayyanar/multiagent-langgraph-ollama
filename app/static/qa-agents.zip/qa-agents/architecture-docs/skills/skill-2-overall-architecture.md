# SKILL 2: Overall Architecture Synthesis Prompt
# Run ONCE after all 6 component documents are complete

## PROMPT (copy everything between the triple dashes)

---

You are a senior enterprise architect. I have completed component analysis for 6 services in a platform. Synthesize them into a single overall architecture document.

I am pasting all 6 component documents below.

{{PASTE CONTENT OF ALL 6 COMPONENT .md FILES HERE}}

Produce the following document:

---

# Overall System Architecture — Current State

## 1. Executive Summary
- What does this platform do end-to-end? (3-5 sentences)
- Primary users of the system
- Core business capability delivered

## 2. High-Level Architecture Diagram
```
Draw a comprehensive ASCII diagram showing:
- All 6 components as labeled boxes
- Arrows showing data flow with direction and protocol labels
- External systems (databases, queues, cloud services)
- User entry points on the left
- Mark [CRITICAL] on AI Service and Ingestion Service
```

## 3. System Capability Matrix
Map each capability to which components provide it.
Use: ✅ Primary  🔄 Supporting  ❌ Not Involved

| Capability | UI Service | AI Service | Prompt Mgmt | Dashboard | Autosys Trigger | Ingestion |
|-----------|:---:|:---:|:---:|:---:|:---:|:---:|
| User Interface | | | | | | |
| AI/LLM Processing | | | | | | |
| Prompt Management | | | | | | |
| Data Ingestion | | | | | | |
| Job Scheduling | | | | | | |
| Reporting & Analytics | | | | | | |
| REST API | | | | | | |
| Authentication | | | | | | |
| Data Storage | | | | | | |
| Event/Message Handling | | | | | | |
| Configuration Management | | | | | | |

Add rows for any additional capabilities found in the component docs.

## 4. Layer Architecture

Place each component in its architectural layer:

```
┌──────────────────────────────────────────────────────────┐
│  PRESENTATION LAYER                                       │
│  Components: (list here)                                  │
├──────────────────────────────────────────────────────────┤
│  APPLICATION / API LAYER                                  │
│  Components: (list here)                                  │
├──────────────────────────────────────────────────────────┤
│  BUSINESS / SERVICE LAYER                                 │
│  Components: (list here)                                  │
├──────────────────────────────────────────────────────────┤
│  INTEGRATION / ORCHESTRATION LAYER                        │
│  Components: (list here)                                  │
├──────────────────────────────────────────────────────────┤
│  DATA / INFRASTRUCTURE LAYER                              │
│  Databases, Queues, Storage: (list here)                  │
└──────────────────────────────────────────────────────────┘
```

## 5. Component Summary Table
| # | Component | Language | Framework | Criticality | Primary Role |
|---|-----------|----------|-----------|-------------|-------------|
| 1 | ReactJS UI Service | | | | |
| 2 | AI Service | | | CRITICAL | |
| 3 | Prompt Management Service | | | | |
| 4 | Dashboard Service | | | | |
| 5 | Autosys Trigger Service | | | | |
| 6 | Ingestion Service | | | CRITICAL | |

## 6. Integration Map
| From | To | Protocol | Data / Payload | Sync or Async |
|------|----|----------|---------------|--------------|

## 7. End-to-End Flows

### Flow A: User AI Query Flow
```
Trace a user request from UI → AI Service → response back to UI
Number each step. Show component name and action at each step.
```

### Flow B: Scheduled Data Ingestion Flow
```
Trace from Autosys Trigger → Ingestion Service → downstream storage/processing
Number each step.
```

### Flow C: Dashboard / Reporting Flow
```
Trace from user opening dashboard → data retrieval → display
Number each step.
```

### Flow D: Prompt Management Flow
```
Trace how prompts are created, stored, and consumed by AI Service
Number each step.
```

## 8. Technology Landscape
| Category | Technologies |
|----------|-------------|
| Languages | |
| Frameworks | |
| Databases | |
| Message Brokers | |
| AI/LLM | |
| Scheduling | |
| Containerization | |
| Cloud Services | |

## 9. Critical Path & Risk
| Component | Risk if Down | Mitigation Visible in Code |
|-----------|-------------|---------------------------|
| AI Service (CRITICAL) | | |
| Ingestion Service (CRITICAL) | | |
| Others | | |

## 10. Cross-Cutting Concerns
| Concern | Approach | Components Involved |
|---------|----------|-------------------|
| Authentication | | |
| Logging | | |
| Error Handling | | |
| Configuration | | |
| Secrets Management | | |

## 11. Architecture Gaps & Recommendations
List gaps found across all components that need investigation or improvement.

---

RULES:
- Only use information from the 6 component documents provided
- Mark inferences as [INFERRED]
- Mark missing information as [GAP]
- Be precise about integration directions and protocols
