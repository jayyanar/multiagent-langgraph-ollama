# HOW TO RUN: Architecture Discovery Skills
# Complete Step-by-Step Procedure

## What You'll Produce
- 6 component documents (one per repo)
- 1 overall architecture document
- Total: 7 markdown files

## Prerequisites
- All 6 repos cloned locally
- 2-3 hours total time

---

## PHASE 1: Component Discovery (Run 6 times — once per repo)

### Step 1 — Open Skill File
Open: `skill-1-component-discovery.md`

### Step 2 — For each repo, do the following:

**2a. Open a new Claude conversation**

**2b. Upload or paste these files from the repo:**
- `package.json` OR `requirements.txt` OR `pom.xml` (dependency file)
- Main entry point file (e.g., `main.py`, `App.jsx`, `Application.java`)
- All route/controller files
- All config files (`.env.example`, `config.yaml`, `application.properties`)
- README.md (if exists)
- Top-level directory listing

**2c. Paste the Skill 1 prompt** (from `skill-1-component-discovery.md`)
Fill in the placeholders:
- `{{REPO_PATH}}` = actual path to repo
- `{{COMPONENT_NAME}}` = name from table below
- `{{COMPONENT_TYPE}}` = type from table below

**2d. Save the output** to the corresponding file:

| Repo | COMPONENT_NAME | COMPONENT_TYPE | Save As |
|------|---------------|----------------|---------|
| ReactJS UI repo | ReactJS UI Service | ReactJS Frontend | `01-component-reactjs-ui.md` |
| Python AI repo | AI Service | Python AI Service | `02-component-ai-service.md` |
| Python Prompt Mgmt repo | Prompt Management Service | Python Prompt Management | `03-component-prompt-mgmt.md` |
| Python Dashboard repo | Dashboard Service | Python Dashboard Service | `04-component-dashboard.md` |
| Python Autosys repo | Autosys Trigger Service | Python Autosys Trigger | `05-component-autosys-trigger.md` |
| Java Ingestion repo | Ingestion Service | Java Ingestion Service | `06-component-ingestion.md` |

---

## PHASE 2: Overall Architecture (Run once after Phase 1)

### Step 3 — Open a new Claude conversation

### Step 4 — Paste all 6 component documents into the conversation

### Step 5 — Paste the Skill 2 prompt (from `skill-2-overall-architecture.md`)

### Step 6 — Save output as `00-overall-architecture.md`

---

## PHASE 3: Validation (Optional but recommended)

### Step 7 — Open a new Claude conversation

### Step 8 — Paste `00-overall-architecture.md` and all 6 component docs

### Step 9 — Paste the Skill 3 prompt (from `skill-3-validation-gaps.md`)

### Step 10 — Review gaps and update documents accordingly

---

## File Output Structure
```
architecture-docs/
├── 00-overall-architecture.md       ← Overall system doc
├── 01-component-reactjs-ui.md       ← UI Service
├── 02-component-ai-service.md       ← AI Service (CRITICAL)
├── 03-component-prompt-mgmt.md      ← Prompt Management
├── 04-component-dashboard.md        ← Dashboard Service
├── 05-component-autosys-trigger.md  ← Autosys Trigger
└── 06-component-ingestion.md        ← Ingestion Service (CRITICAL)
```

## Tips for Best Results
- For Java/Python repos: include ALL files in `src/` or `app/` folder
- For ReactJS: include `src/` structure, `package.json`, and `src/App.jsx`
- Always include the README — it often has integration context
- If repo is large, prioritize: entry points > routes > models > config
- Run AI Service and Ingestion Service first (they are critical path)
