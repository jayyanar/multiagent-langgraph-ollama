# SKILL 1: Component Discovery Prompt
# Use this once per repo — 6 total runs

## PROMPT (copy everything between the triple dashes)

---

You are a senior software architect performing a deep codebase discovery.

I am sharing files from a single repository. Analyze everything provided and produce a structured component document.

**Component Name:** {{COMPONENT_NAME}}
**Component Type:** {{COMPONENT_TYPE}}
**Repository Path:** {{REPO_PATH}}

Produce the following document exactly:

---

# Component: {{COMPONENT_NAME}}

## 1. Purpose & Overview
- What does this component do in the overall system? (2-3 sentences)
- Who/what calls this component?
- What does this component call?
- Criticality: [CRITICAL / HIGH / MEDIUM / LOW] — justify in one sentence

## 2. Technology Stack
| Category | Technology | Version |
|----------|-----------|---------|
| Language | | |
| Framework | | |
| Package Manager | | |
| Database / Storage | | |
| Message Queue | | |
| External APIs | | |
| Testing | | |
| Containerization | | |

## 3. Repository Structure
Provide the directory tree (2-3 levels deep), then list the 10 most important files:

```
(directory tree here)
```

| File Path | Purpose |
|-----------|---------|
| | |

## 4. Key Features
| # | Feature Name | Description | Entry Point File |
|---|-------------|-------------|-----------------|
| 1 | | | |

## 5. API Surface
**Endpoints Exposed:**
| Method | Path | Purpose |
|--------|------|---------|

**External Services Called:**
| Service | Protocol | Purpose |
|---------|----------|---------|

**Events/Messages Published:**
| Topic/Queue | Payload | Trigger |
|-------------|---------|---------|

**Events/Messages Consumed:**
| Topic/Queue | Action Taken |
|-------------|-------------|

## 6. Data Model
List key entities/models with their fields and relationships.

## 7. Configuration
| Config Key | Purpose | Default |
|-----------|---------|---------|

## 8. Integration Points
| Integrates With | Direction | Protocol | Data |
|----------------|-----------|----------|------|

## 9. Internal Architecture Diagram
```
(ASCII diagram of internal structure and data flow)
```

## 10. Known Gaps / Needs Verification
List anything unclear or that needs a developer to confirm.

---

RULES:
- Only document what is verifiable from the provided code
- Mark unclear items as [NEEDS VERIFICATION]
- Do not invent integrations or features not visible in the code
- Read dependency files, entry points, routes, and config files first

---

## WHAT TO PASTE ALONGSIDE THIS PROMPT

For each repo type, paste these files:

### ReactJS UI Repo
- `package.json`
- `src/App.jsx` or `src/App.tsx`
- All files in `src/pages/` or `src/views/`
- All files in `src/services/` or `src/api/`
- `.env.example`
- `README.md`

### Python Service Repos (AI, Prompt Mgmt, Dashboard, Autosys)
- `requirements.txt` or `pyproject.toml`
- `main.py` or `app.py` or `run.py`
- All route/endpoint files
- All model files
- `config.py` or `settings.py` or `.env.example`
- `README.md`

### Java Ingestion Repo
- `pom.xml` or `build.gradle`
- `src/main/java/` — all files (or top-level classes)
- `src/main/resources/application.properties` or `application.yml`
- `README.md`
