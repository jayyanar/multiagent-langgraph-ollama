# SKILL 3: Validation & Gap Analysis Prompt
# Run ONCE after the overall architecture document is complete
# Purpose: Find what's missing, inconsistent, or needs developer input

## PROMPT (copy everything between the triple dashes)

---

You are a senior software architect reviewing architecture documentation for completeness and accuracy.

I am providing:
1. The overall architecture document
2. All 6 component documents

{{PASTE 00-overall-architecture.md HERE}}
{{PASTE ALL 6 COMPONENT DOCS HERE}}

Perform a validation and produce a gap analysis report:

---

# Architecture Validation & Gap Analysis Report

## 1. Consistency Check
Review all 7 documents and flag any contradictions:
| Inconsistency | Document A Says | Document B Says | Recommended Resolution |
|--------------|----------------|----------------|----------------------|

## 2. Integration Gaps
List integrations that are mentioned in one component doc but not reflected in the overall architecture:
| Missing Integration | Source Component | Target Component | Evidence |
|--------------------|-----------------|-----------------|---------|

## 3. Missing Information by Component
For each component, list what could not be determined from the code:
| Component | Missing Information | Why It Matters |
|-----------|-------------------|---------------|

## 4. Critical Path Verification
- Is the AI Service → Ingestion Service relationship fully documented?
- Are all data flows between critical components traced?
- List any critical path gaps

## 5. Questions for Development Team
Generate a list of specific questions to ask developers to fill the gaps:
| # | Question | Target Component | Why It's Needed |
|---|---------|-----------------|----------------|

## 6. Document Update Checklist
List specific updates needed in each document:
| Document | Section | Update Needed |
|----------|---------|--------------|

---
