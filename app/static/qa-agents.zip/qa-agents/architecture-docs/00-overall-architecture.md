# Overall System Architecture — Current State
<!-- Generated using Skill 2: Overall Architecture Synthesis -->
<!-- Status: PENDING — Complete all 6 component docs first, then run skill-2-overall-architecture.md -->

---

## 1. Executive Summary
[TO BE FILLED after all component docs are complete]

---

## 2. High-Level Architecture Diagram

```
[TO BE FILLED]

Expected shape:

  User
   │
   ▼
┌──────────────────┐
│  ReactJS UI      │ ◄──── Presentation Layer
└────────┬─────────┘
         │ REST
    ┌────┴──────────────────────────────┐
    │                                   │
    ▼                                   ▼
┌───────────┐                  ┌─────────────────┐
│ AI Service│ [CRITICAL]       │ Dashboard Svc   │
└─────┬─────┘                  └────────┬────────┘
      │                                 │
      │ fetch prompts                   │ reads metrics
      ▼                                 │
┌──────────────────┐                    │
│ Prompt Mgmt Svc  │                    │
└──────────────────┘                    │
                                        │
┌──────────────────┐                    │
│ Autosys Trigger  │                    │
└────────┬─────────┘                    │
         │ triggers                     │
         ▼                              │
┌──────────────────┐ ──── metrics ──────┘
│ Ingestion Svc    │ [CRITICAL]
└──────────────────┘
         │
         ▼
   [Source Data / Storage]
```

---

## 3. System Capability Matrix
[TO BE FILLED]

| Capability | UI Service | AI Service | Prompt Mgmt | Dashboard | Autosys Trigger | Ingestion |
|-----------|:---:|:---:|:---:|:---:|:---:|:---:|
| User Interface | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| AI/LLM Processing | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Prompt Management | 🔄 | 🔄 | ✅ | ❌ | ❌ | ❌ |
| Data Ingestion | ❌ | ❌ | ❌ | ❌ | 🔄 | ✅ |
| Job Scheduling | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ |
| Reporting & Analytics | 🔄 | ❌ | ❌ | ✅ | ❌ | ❌ |
| REST API | 🔄 | ✅ | ✅ | ✅ | ✅ | ✅ |
| Authentication | | | | | | |
| Data Storage | | | | | | |

---

## 4. Layer Architecture
[TO BE FILLED]

```
┌──────────────────────────────────────────────────────────┐
│  PRESENTATION LAYER                                       │
│  ReactJS UI Service                                       │
├──────────────────────────────────────────────────────────┤
│  APPLICATION / API LAYER                                  │
│  AI Service  |  Dashboard Service  |  Prompt Mgmt Svc    │
├──────────────────────────────────────────────────────────┤
│  ORCHESTRATION / INTEGRATION LAYER                        │
│  Autosys Trigger Service                                  │
├──────────────────────────────────────────────────────────┤
│  DATA PROCESSING LAYER                                    │
│  Ingestion Service [CRITICAL]                             │
├──────────────────────────────────────────────────────────┤
│  INFRASTRUCTURE LAYER                                     │
│  Databases | Message Queues | Autosys Scheduler           │
└──────────────────────────────────────────────────────────┘
```

---

## 5. Component Summary Table
| # | Component | Language | Framework | Criticality | Primary Role |
|---|-----------|----------|-----------|-------------|-------------|
| 1 | ReactJS UI Service | JavaScript/TypeScript | ReactJS | MEDIUM | User Interface |
| 2 | AI Service | Python | TBD | **CRITICAL** | AI/LLM Processing |
| 3 | Prompt Management Service | Python | TBD | HIGH | Prompt Storage & Retrieval |
| 4 | Dashboard Service | Python | TBD | MEDIUM | Reporting & Analytics |
| 5 | Autosys Trigger Service | Python | TBD | HIGH | Job Orchestration |
| 6 | Ingestion Service | Java | TBD | **CRITICAL** | Data Ingestion & Processing |

---

## 6. Integration Map
[TO BE FILLED after component docs complete]

| From | To | Protocol | Data | Sync/Async |
|------|----|----------|------|-----------|
| ReactJS UI | AI Service | REST/HTTP | User query | Sync |
| ReactJS UI | Dashboard Service | REST/HTTP | Dashboard request | Sync |
| ReactJS UI | Prompt Mgmt Service | REST/HTTP | Prompt CRUD | Sync |
| AI Service | Prompt Mgmt Service | REST/HTTP | Fetch prompt | Sync |
| Autosys Trigger | Ingestion Service | TBD | Trigger + params | TBD |
| Ingestion Service | AI Service | TBD | Processed data | TBD |
| Ingestion Service | Dashboard Service | TBD | Metrics | TBD |

---

## 7. End-to-End Flows
[TO BE FILLED]

### Flow A: User AI Query
```
1. User types query → ReactJS UI
2. ReactJS UI → POST /query → AI Service
3. AI Service → GET /prompt/{id} → Prompt Mgmt Service
4. AI Service → calls LLM with prompt + query
5. AI Service → returns response → ReactJS UI
6. ReactJS UI displays response to User
```

### Flow B: Scheduled Data Ingestion
```
1. Autosys Scheduler fires job at scheduled time
2. Autosys Trigger Service receives trigger
3. Autosys Trigger Service → calls Ingestion Service with job params
4. Ingestion Service extracts data from source systems
5. Ingestion Service transforms and loads data
6. Ingestion Service → notifies completion (to AI Service / Dashboard)
7. Dashboard Service reflects updated ingestion status
```

### Flow C: Dashboard Reporting
```
1. User opens Dashboard → ReactJS UI
2. ReactJS UI → GET /dashboard → Dashboard Service
3. Dashboard Service queries metrics from data store
4. Dashboard Service returns aggregated data
5. ReactJS UI renders charts/tables
```

### Flow D: Prompt Management
```
1. Admin creates/edits prompt → ReactJS UI
2. ReactJS UI → POST/PUT /prompt → Prompt Mgmt Service
3. Prompt Mgmt Service stores prompt in DB
4. AI Service fetches prompt by ID when processing queries
```

---

## 8. Technology Landscape
[TO BE FILLED after component docs complete]

| Category | Technologies |
|----------|-------------|
| Languages | JavaScript/TypeScript, Python, Java |
| Frameworks | ReactJS, TBD (Python), TBD (Java) |
| Databases | TBD |
| Message Brokers | TBD |
| AI/LLM | TBD |
| Scheduling | Autosys |
| Containerization | TBD |

---

## 9. Critical Path & Risk
| Component | Risk if Down | Mitigation |
|-----------|-------------|-----------|
| AI Service | All AI queries fail; platform unusable | TBD |
| Ingestion Service | No new data ingested; AI responses stale | TBD |
| Autosys Trigger | Ingestion never triggered; data goes stale | TBD |
| Prompt Mgmt Service | AI Service cannot fetch prompts; queries fail | TBD |

---

## 10. Cross-Cutting Concerns
[TO BE FILLED]

| Concern | Approach | Components |
|---------|----------|-----------|
| Authentication | TBD | All |
| Logging | TBD | All |
| Error Handling | TBD | All |
| Configuration | TBD | All |
| Secrets Management | TBD | All |

---

## 11. Architecture Gaps
[TO BE FILLED after Skill 3 validation]
