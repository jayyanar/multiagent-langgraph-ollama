# Component: Ingestion Service ⚠️ CRITICAL
<!-- Generated using Skill 1: Component Discovery -->
<!-- Status: PENDING — Run skill-1-component-discovery.md against the Java Ingestion repo -->
<!-- PRIORITY: Run this FIRST alongside AI Service — it is on the critical path -->

## 1. Purpose & Overview
[TO BE FILLED]
- Criticality: **CRITICAL** — Core data ingestion engine; feeds data to AI Service

## 2. Technology Stack
| Category | Technology | Version |
|----------|-----------|---------|
| Language | Java | |
| Framework | Spring Boot / Quarkus / other | |
| Build Tool | Maven / Gradle | |
| Database / Storage | | |
| Message Queue | | |
| Testing | JUnit / other | |
| Containerization | | |

## 3. Repository Structure
```
[TO BE FILLED]
```

| File Path | Purpose |
|-----------|---------|
| | |

## 4. Key Features
| # | Feature Name | Description | Entry Point File |
|---|-------------|-------------|-----------------|
| | | | |

## 5. API Surface
**Endpoints Exposed:**
| Method | Path | Purpose |
|--------|------|---------|

**External Services Called:**
| Service | Protocol | Purpose |
|---------|----------|---------|
| Source Data Systems | | Data extraction |
| AI Service | | Processed data delivery |

**Events/Messages Published:**
| Topic/Queue | Payload | Trigger |
|-------------|---------|---------|

**Events/Messages Consumed:**
| Topic/Queue | Action Taken |
|-------------|-------------|

## 6. Data Model
[TO BE FILLED — expected: ingestion job, source record, processed record, status tracking]

## 7. Configuration
| Config Key | Purpose | Default |
|-----------|---------|---------|

## 8. Integration Points
| Integrates With | Direction | Protocol | Data |
|----------------|-----------|----------|------|
| Autosys Trigger Service | Inbound | | Trigger signal + params |
| Source Data Systems | Outbound | | Raw data extraction |
| AI Service | Outbound | | Processed/transformed data |
| Dashboard Service | Outbound | | Ingestion status metrics |

## 9. Internal Architecture Diagram
```
[TO BE FILLED]
```

## 10. Known Gaps / Needs Verification
- [ ] Source data systems (databases, files, APIs, S3?)
- [ ] Data transformation logic
- [ ] How processed data is delivered to AI Service
- [ ] Error handling and dead-letter queue
- [ ] Idempotency / duplicate detection
- [ ] Volume and throughput characteristics
