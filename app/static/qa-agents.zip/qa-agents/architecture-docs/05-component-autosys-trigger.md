# Component: Autosys Trigger Service
<!-- Generated using Skill 1: Component Discovery -->
<!-- Status: PENDING — Run skill-1-component-discovery.md against the Python Autosys repo -->

## 1. Purpose & Overview
[TO BE FILLED]
- Criticality: **HIGH** — Orchestrates scheduled ingestion; if this fails, ingestion stops

## 2. Technology Stack
| Category | Technology | Version |
|----------|-----------|---------|
| Language | Python | |
| Framework | | |
| Package Manager | pip / poetry | |
| Scheduler | Autosys | |
| Testing | | |
| Containerization | | |

## 3. Repository Structure
```
[TO BE FILLED]
```

| File Path | Purpose |
|-----------|---------|
| | |

## 4. Key Features
| # | Feature Name | Description | Entry Point File |
|---|-------------|-------------|-----------------|
| | | | |

## 5. API Surface
**Endpoints Exposed:**
| Method | Path | Purpose |
|--------|------|---------|

**External Services Called:**
| Service | Protocol | Purpose |
|---------|----------|---------|
| Ingestion Service | | Trigger ingestion jobs |

**Autosys Job Definitions:**
| Job Name | Schedule | Action |
|----------|---------|--------|

## 6. Data Model
[TO BE FILLED — expected: job configs, trigger parameters, run history]

## 7. Configuration
| Config Key | Purpose | Default |
|-----------|---------|---------|

## 8. Integration Points
| Integrates With | Direction | Protocol | Data |
|----------------|-----------|----------|------|
| Autosys Scheduler | Inbound | CLI / API | Job trigger signal |
| Ingestion Service | Outbound | REST/HTTP or CLI | Trigger ingestion with params |

## 9. Internal Architecture Diagram
```
[TO BE FILLED]
```

## 10. Known Gaps / Needs Verification
- [ ] How Autosys invokes this service (CLI script? REST call? direct Python execution?)
- [ ] Parameters passed to Ingestion Service
- [ ] Error handling and retry on trigger failure
- [ ] Logging and alerting on job failure
