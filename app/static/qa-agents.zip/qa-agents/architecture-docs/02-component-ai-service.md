# Component: AI Service ⚠️ CRITICAL
<!-- Generated using Skill 1: Component Discovery -->
<!-- Status: PENDING — Run skill-1-component-discovery.md against the Python AI Service repo -->
<!-- PRIORITY: Run this FIRST — it is on the critical path -->

## 1. Purpose & Overview
[TO BE FILLED]
- Criticality: **CRITICAL** — Core AI/LLM processing engine of the platform

## 2. Technology Stack
| Category | Technology | Version |
|----------|-----------|---------|
| Language | Python | |
| Framework | | |
| LLM / AI Library | | |
| Package Manager | pip / poetry | |
| Database / Storage | | |
| Message Queue | | |
| Testing | | |
| Containerization | | |

## 3. Repository Structure
```
[TO BE FILLED]
```

| File Path | Purpose |
|-----------|---------|
| | |

## 4. Key Features
| # | Feature Name | Description | Entry Point File |
|---|-------------|-------------|-----------------|
| | | | |

## 5. API Surface
**Endpoints Exposed:**
| Method | Path | Purpose |
|--------|------|---------|

**External Services Called:**
| Service | Protocol | Purpose |
|---------|----------|---------|
| LLM Provider (OpenAI/Bedrock/etc.) | | |
| Prompt Management Service | | |

**Events/Messages Published:**
| Topic/Queue | Payload | Trigger |
|-------------|---------|---------|

**Events/Messages Consumed:**
| Topic/Queue | Action Taken |
|-------------|-------------|

## 6. Data Model
[TO BE FILLED]

## 7. Configuration
| Config Key | Purpose | Default |
|-----------|---------|---------|

## 8. Integration Points
| Integrates With | Direction | Protocol | Data |
|----------------|-----------|----------|------|
| ReactJS UI | Inbound | REST/HTTP | User queries |
| Prompt Mgmt Service | Outbound | REST/HTTP | Fetch prompts |
| Ingestion Service | | | |

## 9. Internal Architecture Diagram
```
[TO BE FILLED]
```

## 10. Known Gaps / Needs Verification
- [ ] Which LLM provider is used (OpenAI, AWS Bedrock, Azure OpenAI, etc.)
- [ ] How prompts are fetched from Prompt Management Service
- [ ] Relationship with Ingestion Service
- [ ] Authentication/authorization mechanism
- [ ] Rate limiting and retry logic
