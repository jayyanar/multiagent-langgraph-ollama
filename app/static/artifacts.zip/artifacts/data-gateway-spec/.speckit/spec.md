# Specification — Data Gateway Service

## 1. Overview

The Data Gateway is the single execution layer for all registered data sources. It provides:

1. **Connection pooling** — Per-source pools with independent sizing, lazy creation, and credential refresh.
2. **Query brokering** — Parameterized query execution with hard-enforced safety (timeouts, row caps, byte caps).
3. **Streaming** — gRPC server-streaming for large result sets.
4. **Governance** — Rate limits, quotas, audit logging for every operation.
5. **Resilience** — Circuit breakers, retries, and health reporting per source.
6. **Connector SPI** — Pluggable interface for adding new source types without core changes.

## 2. Functional Requirements

### 2.1 Connector SPI

| ID | Requirement |
|----|-------------|
| CN-01 | Define `SourceConnector` interface with methods: `testConnection`, `describeSchema`, `executeQuery`, `streamResults`, `sampleRows` |
| CN-02 | Built-in connectors (Phase 1): JDBC (Postgres, Oracle), S3 |
| CN-03 | JDBC connector uses parameterized `PreparedStatement` — no string concatenation |
| CN-04 | S3 connector supports parquet, CSV, JSON formats; uses S3 Select or local read + parse |
| CN-05 | Each connector is a separate module/package; loaded via ServiceLoader or Spring component scan |
| CN-06 | Connector test harness provided — new connectors must pass standard test suite |

### 2.2 Connection Management

| ID | Requirement |
|----|-------------|
| CM-01 | Per-source connection pool, sized and tuned independently |
| CM-02 | JDBC pools: HikariCP with configurable min/max/idle/timeout per source |
| CM-03 | Mongo pools: native driver pool with configurable settings |
| CM-04 | S3: AWS SDK client with transfer manager (no traditional pool — client reuse) |
| CM-05 | Lazy pool creation on first call to a source |
| CM-06 | Warm pool on demand via explicit API call |
| CM-07 | Credentials resolved from Vault at pool initialization |
| CM-08 | Credential refresh on Vault rotation events (TTL-based or event-driven) |
| CM-09 | Pool eviction and recreation on credential rotation |
| CM-10 | Pool metrics exposed: active connections, idle connections, pending acquisitions, timeouts |

### 2.3 Query Brokering

| ID | Requirement |
|----|-------------|
| QB-01 | API: `ExecuteQuery(source_id, statement_template, params, options)` |
| QB-02 | Statement templates only — no raw user SQL passthrough |
| QB-03 | Parameter binding via prepared statements (JDBC) or equivalent (Mongo query builder) |
| QB-04 | Hard-enforced query timeout (configurable per source, default 30s) |
| QB-05 | Hard-enforced row cap (configurable, default 10,000 rows) |
| QB-06 | Hard-enforced byte cap (configurable, default 50 MB) |
| QB-07 | Streaming response for large result sets via gRPC server-streaming (`StreamQuery`) |
| QB-08 | Query cancellation on client disconnect or deadline exceeded |
| QB-09 | Read-only enforcement — reject any statement containing DDL/DML keywords (Phase 1) |

### 2.4 Profiling Support

| ID | Requirement |
|----|-------------|
| PS-01 | `SampleRows(source_id, object_id, n)` — returns first/sample N rows |
| PS-02 | `DescribeSchema(source_id, object_id)` — returns column names, types, nullability |
| PS-03 | Separate quota bucket for profiling — never starves runtime traffic |
| PS-04 | Profiling queries use lower priority in pool (if supported by source) |

### 2.5 Governance

| ID | Requirement |
|----|-------------|
| GV-01 | Rate limit per source (queries/second, configurable) |
| GV-02 | Rate limit per caller identity (queries/second) |
| GV-03 | Quota per caller (queries/minute, rows/day) — configurable |
| GV-04 | Caller identity extracted from mTLS cert + signed header |
| GV-05 | mTLS required for all inbound connections |
| GV-06 | Every call audited: `{caller, source, object, statement_hash, params_hash, rows_returned, bytes_returned, latency_ms, status, timestamp}` |
| GV-07 | Audit log: 1 year retention, queryable by caller/source/time range |
| GV-08 | Quota exceeded → return `RESOURCE_EXHAUSTED` gRPC status with reset time |

### 2.6 Resilience

| ID | Requirement |
|----|-------------|
| RS-01 | Circuit breaker per source — configurable failure threshold, half-open timeout |
| RS-02 | When circuit opens: fail fast on subsequent calls, return `UNAVAILABLE` with source status |
| RS-03 | Notify Tool Registry of source degradation (via `GetSourceHealth` response or callback) |
| RS-04 | Retry policy for idempotent reads only — configurable max retries, backoff |
| RS-05 | Connection acquisition timeout — fail fast if pool exhausted |
| RS-06 | Graceful shutdown: drain in-flight queries before termination (configurable drain timeout) |

### 2.7 Health & Monitoring

| ID | Requirement |
|----|-------------|
| HM-01 | `GetSourceHealth(source_id)` — returns: status (HEALTHY/DEGRADED/UNAVAILABLE), recent error rate, avg latency, pool utilization |
| HM-02 | `TestConnection(source_spec)` — validates credentials and reachability without creating a persistent pool |
| HM-03 | Periodic health probes per source (configurable interval, default 30s) |
| HM-04 | Expose metrics: active queries, pool stats, circuit breaker state, audit volume |

## 3. gRPC API (from platform-contracts)

```protobuf
syntax = "proto3";
package com.platform.gateway;

service DataGatewayService {
  rpc TestConnection(TestConnectionRequest) returns (TestConnectionResponse);
  rpc DescribeSchema(DescribeSchemaRequest) returns (DescribeSchemaResponse);
  rpc SampleRows(SampleRowsRequest) returns (SampleRowsResponse);
  rpc ExecuteQuery(ExecuteQueryRequest) returns (ExecuteQueryResponse);
  rpc StreamQuery(StreamQueryRequest) returns (stream QueryResultChunk);
  rpc GetSourceHealth(GetSourceHealthRequest) returns (GetSourceHealthResponse);
}

message TestConnectionRequest {
  string source_type = 1;       // POSTGRES, ORACLE, S3, MONGO
  string endpoint = 2;
  int32 port = 3;
  string database = 4;
  string vault_ref = 5;         // Vault secret path
}

message TestConnectionResponse {
  bool success = 1;
  string error_message = 2;
}

message DescribeSchemaRequest {
  string source_id = 1;
  string object_name = 2;
}

message DescribeSchemaResponse {
  repeated ColumnSchema columns = 1;
}

message ColumnSchema {
  string name = 1;
  string native_type = 2;
  bool nullable = 3;
}

message SampleRowsRequest {
  string source_id = 1;
  string object_name = 2;
  int32 max_rows = 3;
}

message SampleRowsResponse {
  repeated ColumnSchema columns = 1;
  repeated Row rows = 2;
}

message Row {
  repeated string values = 1;   // String-encoded values
}

message ExecuteQueryRequest {
  string source_id = 1;
  string statement_template = 2;
  map<string, string> params = 3;
  QueryOptions options = 4;
}

message QueryOptions {
  int32 timeout_ms = 1;
  int32 max_rows = 2;
  int64 max_bytes = 3;
}

message ExecuteQueryResponse {
  repeated ColumnSchema columns = 1;
  repeated Row rows = 2;
  int32 total_rows = 3;
  bool truncated = 4;
}

message StreamQueryRequest {
  string source_id = 1;
  string statement_template = 2;
  map<string, string> params = 3;
  QueryOptions options = 4;
}

message QueryResultChunk {
  repeated ColumnSchema columns = 1;  // Only in first chunk
  repeated Row rows = 2;
  bool is_last = 3;
}

message GetSourceHealthRequest {
  string source_id = 1;
}

message GetSourceHealthResponse {
  string status = 1;            // HEALTHY, DEGRADED, UNAVAILABLE
  double error_rate = 2;        // Last 5 min
  double avg_latency_ms = 3;   // Last 5 min
  double pool_utilization = 4; // 0.0 - 1.0
}
```

## 4. Data Model

### 4.1 Persisted (Postgres)

```
gateway_audit(
  id BIGSERIAL PRIMARY KEY,
  caller VARCHAR(255) NOT NULL,
  source_id VARCHAR(64) NOT NULL,
  object_name VARCHAR(255),
  statement_hash VARCHAR(64) NOT NULL,
  params_hash VARCHAR(64),
  rows_returned INT,
  bytes_returned BIGINT,
  latency_ms INT NOT NULL,
  status VARCHAR(20) NOT NULL,    -- SUCCESS, FAILED, TIMEOUT, CANCELLED
  error_message TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Partitioned by month for efficient retention management
-- Index on (source_id, created_at) and (caller, created_at)
```

### 4.2 In-Memory / Redis

| Entity | Storage | Purpose |
|--------|---------|---------|
| Connection pool (per source) | In-memory (HikariCP/native) | Active connections |
| Circuit breaker state | In-memory + Redis | Cross-replica consistency |
| Quota counters | Redis (sliding window) | Per-caller rate/quota enforcement |
| Active query registry | In-memory | Graceful shutdown, cancellation |

## 5. Configuration

```yaml
# application.yml (key sections)
spring:
  datasource:
    url: jdbc:postgresql://${AUDIT_DB_HOST}:5432/gateway_audit

data-gateway:
  grpc:
    port: 9090
    tls:
      cert-path: /etc/certs/server.pem
      key-path: /etc/certs/server-key.pem
      ca-path: /etc/certs/ca.pem
  vault:
    address: ${VAULT_ADDR}
    secret-path-prefix: data-platform/sources
  defaults:
    query-timeout-ms: 30000
    max-rows: 10000
    max-bytes: 52428800  # 50 MB
    pool-min: 5
    pool-max: 20
    pool-idle-timeout-ms: 600000
  circuit-breaker:
    failure-rate-threshold: 50
    slow-call-rate-threshold: 80
    slow-call-duration-ms: 5000
    wait-duration-in-open-state-ms: 30000
    permitted-calls-in-half-open: 3
  rate-limit:
    default-per-source-rps: 100
    default-per-caller-rps: 50
  quota:
    default-queries-per-minute: 300
    default-rows-per-day: 1000000
  health:
    probe-interval-ms: 30000
  audit:
    retention-days: 365
    batch-flush-size: 100
    batch-flush-interval-ms: 1000
  redis:
    host: ${REDIS_HOST}
    port: 6379
```

## 6. Error Handling

| Scenario | gRPC Status | Behavior |
|----------|-------------|----------|
| Source unreachable | UNAVAILABLE | Circuit breaker opens; health status updated |
| Query timeout | DEADLINE_EXCEEDED | Query cancelled at source; audit logged |
| Row cap exceeded | OK (truncated=true) | Return partial results with truncation flag |
| Byte cap exceeded | RESOURCE_EXHAUSTED | Return error; audit logged |
| Pool exhausted | UNAVAILABLE | Fail fast; metric incremented |
| Quota exceeded | RESOURCE_EXHAUSTED | Return reset time in metadata |
| Rate limit hit | RESOURCE_EXHAUSTED | Return retry-after in metadata |
| Invalid statement | INVALID_ARGUMENT | Reject before execution |
| Vault unreachable | INTERNAL | Pool creation fails; source marked UNAVAILABLE |
| Client disconnect | CANCELLED | Cancel in-flight query; release connection |

## 7. Security

- mTLS required for all inbound gRPC connections
- Caller identity extracted from client certificate CN
- No credentials stored at rest — only Vault references in config
- Credentials exist in memory only during pool lifetime
- Statement templates validated against allowlist patterns (no DDL/DML)
- Audit log tamper-evident (append-only, hash chain optional for Phase 2)
- No source data cached — results streamed directly to caller
- Connection strings never logged; only source_id appears in logs
