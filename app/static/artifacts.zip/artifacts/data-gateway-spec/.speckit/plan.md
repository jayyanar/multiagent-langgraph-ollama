# Technical Plan — Data Gateway Service

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      DATA GATEWAY SERVICE                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              gRPC Server (mTLS)                           │   │
│  │  TestConnection | DescribeSchema | SampleRows            │   │
│  │  ExecuteQuery   | StreamQuery    | GetSourceHealth       │   │
│  └──────────────────────────┬───────────────────────────────┘   │
│                             │                                   │
│  ┌──────────────────────────▼───────────────────────────────┐   │
│  │              Governance Layer                             │   │
│  │  RateLimiter → QuotaChecker → Auditor                    │   │
│  └──────────────────────────┬───────────────────────────────┘   │
│                             │                                   │
│  ┌──────────────────────────▼───────────────────────────────┐   │
│  │              Query Broker                                 │   │
│  │  StatementValidator → ParamBinder → TimeoutEnforcer      │   │
│  │  → ResultCapper → StreamController                       │   │
│  └──────────────────────────┬───────────────────────────────┘   │
│                             │                                   │
│  ┌──────────────────────────▼───────────────────────────────┐   │
│  │              Connection Manager                           │   │
│  │  PoolRegistry → CredentialResolver → HealthProber        │   │
│  └──────────────────────────┬───────────────────────────────┘   │
│                             │                                   │
│  ┌──────────────────────────▼───────────────────────────────┐   │
│  │              Connector SPI                                │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐               │   │
│  │  │  JDBC    │  │  Mongo   │  │   S3     │               │   │
│  │  │Connector │  │Connector │  │Connector │               │   │
│  │  └────┬─────┘  └────┬─────┘  └────┬─────┘               │   │
│  └───────┼──────────────┼──────────────┼────────────────────┘   │
│          │              │              │                         │
└──────────┼──────────────┼──────────────┼─────────────────────────┘
           │              │              │
           ▼              ▼              ▼
      JDBC Sources    MongoDB         S3/MinIO
      (Postgres,                    (parquet/csv/json)
       Oracle)
           ▲                              ▲
           │                              │
         Vault ◄──────────────────────── Redis
      (credentials)                  (circuit state,
                                      quota counters)
```

## 2. Module Structure

```
data-gateway/
├── pom.xml                              (parent POM)
├── platform-contracts/                  (shared proto — same artifact as Tool Registry)
│   └── src/main/proto/
│       └── gateway.proto
├── data-gateway-app/
│   ├── pom.xml
│   └── src/
│       ├── main/java/com/platform/datagateway/
│       │   ├── DataGatewayApplication.java
│       │   ├── config/
│       │   │   ├── GrpcServerConfig.java
│       │   │   ├── VaultConfig.java
│       │   │   ├── RedisConfig.java
│       │   │   ├── ResilienceConfig.java
│       │   │   └── MetricsConfig.java
│       │   ├── grpc/
│       │   │   ├── DataGatewayGrpcService.java
│       │   │   └── GrpcExceptionHandler.java
│       │   ├── governance/
│       │   │   ├── RateLimiterService.java
│       │   │   ├── QuotaService.java
│       │   │   ├── CallerIdentityExtractor.java
│       │   │   └── AuditService.java
│       │   ├── broker/
│       │   │   ├── QueryBroker.java
│       │   │   ├── StatementValidator.java
│       │   │   ├── ParameterBinder.java
│       │   │   ├── ResultCapper.java
│       │   │   └── StreamController.java
│       │   ├── pool/
│       │   │   ├── PoolRegistry.java
│       │   │   ├── PoolFactory.java
│       │   │   ├── CredentialResolver.java
│       │   │   └── PoolHealthProber.java
│       │   ├── connector/
│       │   │   ├── SourceConnector.java          (SPI interface)
│       │   │   ├── ConnectorRegistry.java
│       │   │   ├── ConnectorTestHarness.java
│       │   │   └── ConnectorResult.java
│       │   ├── connector/jdbc/
│       │   │   ├── JdbcConnector.java
│       │   │   ├── PostgresDialect.java
│       │   │   └── OracleDialect.java
│       │   ├── connector/s3/
│       │   │   ├── S3Connector.java
│       │   │   ├── ParquetReader.java
│       │   │   ├── CsvReader.java
│       │   │   └── JsonReader.java
│       │   ├── resilience/
│       │   │   ├── CircuitBreakerManager.java
│       │   │   ├── RetryPolicyFactory.java
│       │   │   └── ActiveQueryRegistry.java
│       │   └── audit/
│       │       ├── AuditRecord.java
│       │       ├── AuditRepository.java
│       │       └── AuditBatchWriter.java
│       └── main/resources/
│           ├── application.yml
│           ├── application-local.yml
│           └── db/migration/
│               ├── V001__create_audit_table.sql
│               └── V002__create_audit_indexes.sql
├── data-gateway-connector-mongo/        (Phase 2 — separate module)
│   └── ...
└── data-gateway-tests/
    ├── pom.xml
    └── src/test/java/
        ├── integration/
        ├── contract/
        └── unit/
```

## 3. Key Design Decisions

### 3.1 Connection Pool Lifecycle

```
Source registered in Tool Registry
        │
        ▼
First query arrives for source_id
        │
        ▼
PoolRegistry.getOrCreate(source_id)
        │
        ├── Resolve credentials from Vault
        ├── Determine connector type
        ├── Create pool with source-specific config
        ├── Validate with test query
        └── Register in pool map
        │
        ▼
Pool active — serves queries
        │
        ├── Credential rotation → evict + recreate
        ├── Idle timeout → shrink to min
        └── Source deregistered → destroy pool
```

### 3.2 Query Execution Pipeline

```
gRPC Request arrives
    │
    ▼
[1] Extract caller identity (mTLS cert CN)
    │
    ▼
[2] Rate limit check (Redis sliding window)
    │   └── FAIL → RESOURCE_EXHAUSTED
    ▼
[3] Quota check (Redis counter)
    │   └── FAIL → RESOURCE_EXHAUSTED
    ▼
[4] Statement validation (no DDL/DML, template format)
    │   └── FAIL → INVALID_ARGUMENT
    ▼
[5] Resolve connector for source_id
    │   └── FAIL → NOT_FOUND
    ▼
[6] Circuit breaker check
    │   └── OPEN → UNAVAILABLE
    ▼
[7] Acquire connection from pool
    │   └── TIMEOUT → UNAVAILABLE
    ▼
[8] Bind parameters + execute with timeout
    │   └── TIMEOUT → DEADLINE_EXCEEDED (cancel query)
    ▼
[9] Cap results (row/byte limit)
    │
    ▼
[10] Write audit record (async batch)
    │
    ▼
Return response
```

### 3.3 Audit Batching

- Audit records buffered in-memory (bounded queue, 1000 entries)
- Flushed to Postgres every 1 second OR when buffer reaches 100 records
- On graceful shutdown: flush remaining records
- On crash: accept loss of last ~1s of audit (acceptable for internal service)
- Monthly table partitioning for efficient retention management

### 3.4 Circuit Breaker Strategy

- **Per-source** circuit breaker (not per-connector-type)
- State stored in Redis for cross-replica consistency
- Failure counting: connection failures + query timeouts + 5xx-equivalent errors
- Threshold: 50% failure rate in sliding window of 10 calls
- Half-open: allow 3 probe calls after 30s wait
- Recovery: close circuit after 3 consecutive successes in half-open

### 3.5 Autoscaling

- HPA metric: `active_queries_total` (custom metric via Prometheus adapter)
- Scale-up threshold: 70% of `max_concurrent_queries` per replica
- Scale-down: 5-minute cooldown, scale to floor when < 30% utilization
- Each replica manages its own pools — pools are NOT shared across replicas
- Source connection limit = `pool_max * replica_count` (must not exceed source DB max_connections)

### 3.6 S3 Connector Design

- No traditional connection pool — reuses AWS SDK client
- `DescribeSchema`: read parquet metadata or CSV headers from first file
- `SampleRows`: read first N rows from first file matching prefix
- `ExecuteQuery`: S3 Select (SQL subset) for parquet/CSV; full-read + filter for JSON
- Large files: streaming read with byte-cap enforcement

## 4. Database Migrations

Audit DB only (minimal schema):
1. `V001` — `gateway_audit` table, partitioned by month
2. `V002` — Indexes on `(source_id, created_at)`, `(caller, created_at)`, `(statement_hash)`

## 5. Observability

- **Traces**: OpenTelemetry auto-instrumentation + manual spans for pool acquisition, query execution, streaming
- **Metrics**: Micrometer → Prometheus
  - `gateway_active_queries` (gauge, by source)
  - `gateway_query_latency_seconds` (histogram, by source and status)
  - `gateway_pool_active_connections` (gauge, by source)
  - `gateway_pool_pending_acquisitions` (gauge, by source)
  - `gateway_circuit_breaker_state` (gauge, by source: 0=closed, 1=open, 2=half-open)
  - `gateway_rate_limit_rejected_total` (counter, by caller)
  - `gateway_quota_exceeded_total` (counter, by caller)
  - `gateway_audit_records_total` (counter)
- **Logs**: Structured JSON; never log credentials or query results; log statement_hash + source_id
- **Health**: gRPC health check service + `/actuator/health` for K8s probes

## 6. Testing Strategy

| Layer | Tool | Scope |
|-------|------|-------|
| Unit | JUnit 5 + Mockito | Query broker, statement validator, result capper, governance logic |
| Integration | Testcontainers (Postgres, Redis, LocalStack S3) | JDBC connector, S3 connector, audit writer, pool lifecycle |
| Contract | gRPC InProcessServer | All 6 RPCs — request/response validation |
| Connector | ConnectorTestHarness | Standard test suite each connector must pass |
| Load | Gatling/k6 | Concurrent query throughput, pool saturation, circuit breaker behavior |
| Chaos | Toxiproxy | Network partitions, latency injection, connection drops |

## 7. Deployment

```yaml
# Kubernetes deployment sketch
apiVersion: apps/v1
kind: Deployment
metadata:
  name: data-gateway
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: data-gateway
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
        ports:
        - containerPort: 9090  # gRPC
        - containerPort: 8080  # actuator
        livenessProbe:
          grpc:
            port: 9090
        readinessProbe:
          httpGet:
            path: /actuator/health/readiness
            port: 8080
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: data-gateway-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: data-gateway
  minReplicas: 3
  maxReplicas: 20
  metrics:
  - type: Pods
    pods:
      metric:
        name: gateway_active_queries
      target:
        type: AverageValue
        averageValue: "70"
```
