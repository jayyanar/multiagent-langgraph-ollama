# Project Constitution — Data Gateway

## Identity

**Project**: Data Gateway Service
**Platform**: Data-Aware Agent Platform
**Role**: System of record for **access** — owns pooled connections to every registered source, resolves credentials from Vault, executes parameterized queries within enforced quotas and timeouts, streams results, and writes a complete audit trail.

## Core Principles

1. **Single execution layer** — This is the only component in the enterprise that opens a connection to any data source. No exceptions.
2. **Internal-only surface** — Exposes gRPC API only. No MCP, no REST, no UI. The only client is Tool Registry.
3. **Credential isolation** — Only component that resolves live DB credentials from Vault. Credentials exist in memory only during pool lifetime.
4. **Stateful toward sources, stateless toward callers** — Maintains connection pools, circuit breakers, and in-flight query state. Callers are stateless gRPC requests.
5. **Governance by default** — Every query is audited, rate-limited, quota-checked, and timeout-enforced. No bypass path.
6. **Pluggable connectors** — New source types are added via a `SourceConnector` SPI. No core changes required.

## Technology Constraints

- Java 21, Spring Boot 3
- gRPC server (internal API, mTLS)
- HikariCP for JDBC connection pooling
- MongoDB Java Driver for Mongo pooling
- AWS SDK v2 for S3 client + transfer manager
- Vault SDK for credential resolution
- Resilience4j for circuit breakers, rate limiting, retry
- Redis for cross-replica state (circuit state, quota counters)
- Postgres for audit log persistence
- OpenTelemetry for tracing and metrics
- Kubernetes HPA for autoscaling on active query count
- Shared `platform-contracts` Maven artifact for proto definitions

## Engineering Practices

- Test-Driven Development for all connector logic
- Integration tests with Testcontainers (Postgres, Mongo, LocalStack S3)
- Contract tests for gRPC server behavior
- Flyway for audit DB migrations
- Structured logging (JSON) with correlation IDs
- Connector SPI with clear interface contract and test harness
- Git trunk-based development with short-lived feature branches

## Non-Functional Targets

| Property | Target |
|----------|--------|
| Gateway overhead p95 | < 50 ms (excluding source time) |
| Concurrent active queries | 10K cluster-wide |
| Connection pool per source | Configurable (default 20 JDBC, 50 Mongo) |
| Availability | 99.9% |
| Audit retention | 1 year, queryable |
| Secret handling | Vault only; zero secrets at rest |

## Out of Scope

- MCP or REST exposure (Tool Registry's responsibility)
- Data Dictionary or semantic enrichment (Tool Registry's responsibility)
- Write operations (Phase 3)
- Federated cross-source queries (Phase 3)
- Multi-region active-active (Phase 3)
