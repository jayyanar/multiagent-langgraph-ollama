# Tasks — Data Gateway Service

## Phase 1 — MVP Implementation

### Task Group 1: Project Scaffolding & Infrastructure

#### Task 1.1: Initialize Spring Boot project
- **What**: Create multi-module Maven project with `data-gateway-app` and `data-gateway-tests`
- **Acceptance**: `mvn clean compile` passes; Spring Boot app starts with empty context
- **Dependencies**: None
- **Estimate**: 0.5 day

#### Task 1.2: Set up platform-contracts dependency
- **What**: Add `platform-contracts` as Maven dependency. Include proto file with all 6 RPCs. Generate Java stubs. Configure gRPC server.
- **Acceptance**: gRPC server starts on port 9090; all 6 service methods registered (returning UNIMPLEMENTED)
- **Dependencies**: Coordinate with Tool Registry team on proto definitions
- **Estimate**: 1 day

#### Task 1.3: Audit database setup with Flyway
- **What**: Configure Flyway, create migrations V001–V002 for audit table (partitioned by month) and indexes
- **Acceptance**: `mvn flyway:migrate` creates partitioned audit table in local Postgres
- **Dependencies**: Task 1.1
- **Estimate**: 0.5 day

#### Task 1.4: Configuration & profiles
- **What**: Set up `application.yml`, `application-local.yml`, `application-test.yml`. Externalize all secrets as env vars. Configure Redis connection.
- **Acceptance**: App starts in local profile; connects to local Redis and Postgres
- **Dependencies**: Task 1.1
- **Estimate**: 0.5 day

#### Task 1.5: mTLS & security setup
- **What**: Configure gRPC server with mTLS. Implement `CallerIdentityExtractor` to read CN from client cert. Reject unauthenticated connections.
- **Acceptance**: gRPC calls without valid client cert are rejected; caller identity extracted and available in context
- **Dependencies**: Task 1.2
- **Estimate**: 1 day

#### Task 1.6: Observability baseline
- **What**: Configure OpenTelemetry auto-instrumentation, Micrometer metrics, structured logging, actuator health endpoints
- **Acceptance**: Traces exported; metrics available at `/actuator/prometheus`; health check responds
- **Dependencies**: Task 1.1
- **Estimate**: 0.5 day

---

### Task Group 2: Connector SPI & JDBC Connector

#### Task 2.1: Define SourceConnector SPI
- **What**: Create `SourceConnector` interface with methods: `testConnection`, `describeSchema`, `executeQuery`, `streamResults`, `sampleRows`. Define `ConnectorResult` types.
- **Acceptance**: Interface compiles; Javadoc documents contract for each method
- **Dependencies**: Task 1.1
- **Estimate**: 0.5 day

#### Task 2.2: Connector registry & discovery
- **What**: Implement `ConnectorRegistry` — discovers connectors via Spring component scan, maps source_type → connector instance
- **Acceptance**: Unit test registers and retrieves connectors by type
- **Dependencies**: Task 2.1
- **Estimate**: 0.5 day

#### Task 2.3: JDBC connector — core
- **What**: Implement `JdbcConnector` with `testConnection`, `describeSchema`, `executeQuery`, `sampleRows`. Use PreparedStatement for all queries. Support Postgres and Oracle dialects.
- **Acceptance**: Integration test with Testcontainers Postgres: test connection, describe schema, execute parameterized query, sample rows
- **Dependencies**: Tasks 2.1, 3.1 (pool)
- **Estimate**: 2.5 days

#### Task 2.4: JDBC connector — streaming
- **What**: Implement `streamResults` for JDBC — cursor-based fetch with configurable fetch size, gRPC server-streaming chunks
- **Acceptance**: Integration test streams 10K rows in chunks; memory usage bounded
- **Dependencies**: Task 2.3
- **Estimate**: 1.5 days

#### Task 2.5: Connector test harness
- **What**: Create `ConnectorTestHarness` — abstract test class that any connector must pass (test connection, schema, query, sample, error handling)
- **Acceptance**: JDBC connector passes full harness; harness reusable for future connectors
- **Dependencies**: Task 2.3
- **Estimate**: 1 day

---

### Task Group 3: Connection Management

#### Task 3.1: Pool registry & factory
- **What**: Implement `PoolRegistry` (concurrent map of source_id → pool) and `PoolFactory` (creates HikariCP pools with source-specific config). Lazy creation on first access.
- **Acceptance**: Unit test: first call creates pool; subsequent calls reuse; pool config matches source settings
- **Dependencies**: Task 1.4
- **Estimate**: 1.5 days

#### Task 3.2: Vault credential resolver
- **What**: Implement `CredentialResolver` — resolves credentials from Vault by vault_ref. Caches with TTL. Supports refresh on rotation.
- **Acceptance**: Integration test with Vault dev server; credentials resolved; cache expires and re-fetches
- **Dependencies**: Task 1.4
- **Estimate**: 1.5 days

#### Task 3.3: Pool lifecycle management
- **What**: Implement pool eviction on credential rotation, warm-on-demand API, idle shrink, destroy on source deregistration
- **Acceptance**: Unit test: credential rotation triggers pool recreation; idle pool shrinks; explicit destroy works
- **Dependencies**: Tasks 3.1, 3.2
- **Estimate**: 1 day

#### Task 3.4: Pool health probing
- **What**: Implement `PoolHealthProber` — periodic lightweight query per source (e.g., `SELECT 1`). Update health status. Feed circuit breaker.
- **Acceptance**: Unit test: healthy source returns HEALTHY; failed probe updates status; configurable interval
- **Dependencies**: Task 3.1
- **Estimate**: 1 day

---

### Task Group 4: Governance Layer

#### Task 4.1: Rate limiter
- **What**: Implement `RateLimiterService` using Redis sliding window. Per-source and per-caller limits. Configurable thresholds.
- **Acceptance**: Integration test with embedded Redis: requests within limit pass; excess rejected with RESOURCE_EXHAUSTED
- **Dependencies**: Task 1.4
- **Estimate**: 1.5 days

#### Task 4.2: Quota service
- **What**: Implement `QuotaService` — tracks queries/minute and rows/day per caller in Redis. Separate bucket for profiling.
- **Acceptance**: Integration test: quota increments on each call; exceeding quota returns error with reset time
- **Dependencies**: Task 1.4
- **Estimate**: 1.5 days

#### Task 4.3: Audit service & batch writer
- **What**: Implement `AuditService` + `AuditBatchWriter` — buffer audit records in-memory, flush to Postgres in batches (every 1s or 100 records). Statement hashing (SHA-256).
- **Acceptance**: Integration test: audit records persisted after flush; graceful shutdown flushes remaining; no credentials in audit
- **Dependencies**: Task 1.3
- **Estimate**: 1.5 days

#### Task 4.4: Statement validator
- **What**: Implement `StatementValidator` — reject statements with DDL/DML keywords (INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE). Validate template format.
- **Acceptance**: Unit test: SELECT passes; INSERT/UPDATE/DELETE/DROP rejected; edge cases (keywords in strings) handled
- **Dependencies**: Task 1.1
- **Estimate**: 1 day

---

### Task Group 5: Query Broker

#### Task 5.1: Query broker orchestration
- **What**: Implement `QueryBroker` — orchestrates the full pipeline: rate limit → quota → validate → resolve connector → circuit check → acquire connection → execute → cap → audit
- **Acceptance**: Unit test with mocked dependencies: happy path returns results; each failure point returns correct gRPC status
- **Dependencies**: Tasks 2.3, 3.1, 4.1, 4.2, 4.3, 4.4
- **Estimate**: 2 days

#### Task 5.2: Parameter binder
- **What**: Implement `ParameterBinder` — binds named parameters from map to PreparedStatement positions. Type inference from string values.
- **Acceptance**: Unit test: string, int, date, null parameters bound correctly; missing param returns error
- **Dependencies**: Task 2.3
- **Estimate**: 1 day

#### Task 5.3: Result capper
- **What**: Implement `ResultCapper` — enforces row cap and byte cap. Tracks bytes as rows are read. Sets truncated flag.
- **Acceptance**: Unit test: 10K row cap stops at 10K; byte cap stops mid-stream; truncated flag set correctly
- **Dependencies**: Task 1.1
- **Estimate**: 0.5 day

#### Task 5.4: Stream controller
- **What**: Implement `StreamController` — manages gRPC server-streaming: chunk size, backpressure, cancellation on client disconnect
- **Acceptance**: Integration test: streams large result in chunks; client cancel stops processing; backpressure respected
- **Dependencies**: Tasks 2.4, 5.1
- **Estimate**: 1.5 days

---

### Task Group 6: Resilience

#### Task 6.1: Circuit breaker manager
- **What**: Implement `CircuitBreakerManager` using Resilience4j. Per-source circuit breaker. State synced to Redis for cross-replica consistency.
- **Acceptance**: Integration test: failures open circuit; half-open allows probes; recovery closes circuit; state visible across replicas
- **Dependencies**: Tasks 1.4, 3.4
- **Estimate**: 1.5 days

#### Task 6.2: Retry policy
- **What**: Implement `RetryPolicyFactory` — configurable retry with exponential backoff for idempotent reads. No retry on non-idempotent or client errors.
- **Acceptance**: Unit test: transient failure retried; permanent failure not retried; backoff increases
- **Dependencies**: Task 1.1
- **Estimate**: 0.5 day

#### Task 6.3: Active query registry & graceful shutdown
- **What**: Implement `ActiveQueryRegistry` — tracks in-flight queries. On shutdown: stop accepting new queries, drain in-flight with configurable timeout, force-cancel remaining.
- **Acceptance**: Integration test: shutdown waits for in-flight; timeout forces cancellation; no new queries accepted during drain
- **Dependencies**: Task 5.1
- **Estimate**: 1 day

---

### Task Group 7: S3 Connector

#### Task 7.1: S3 connector — schema & sample
- **What**: Implement `S3Connector.describeSchema` (read parquet metadata or CSV headers) and `sampleRows` (read first N rows)
- **Acceptance**: Integration test with LocalStack: describe parquet schema; sample CSV rows; sample JSON rows
- **Dependencies**: Tasks 2.1, 2.2
- **Estimate**: 2 days

#### Task 7.2: S3 connector — query execution
- **What**: Implement `S3Connector.executeQuery` — S3 Select for parquet/CSV; full-read + filter for JSON. Byte-cap enforcement.
- **Acceptance**: Integration test: S3 Select query returns filtered results; byte cap enforced; JSON fallback works
- **Dependencies**: Task 7.1
- **Estimate**: 1.5 days

#### Task 7.3: S3 connector — pass test harness
- **What**: Run `ConnectorTestHarness` against S3 connector; fix any failures
- **Acceptance**: S3 connector passes full harness suite
- **Dependencies**: Tasks 2.5, 7.2
- **Estimate**: 0.5 day

---

### Task Group 8: gRPC Service Implementation

#### Task 8.1: Implement all 6 RPCs
- **What**: Wire `DataGatewayGrpcService` to delegate to QueryBroker, PoolRegistry, ConnectorRegistry. Implement all 6 RPCs with proper error mapping.
- **Acceptance**: Contract test: all 6 RPCs return expected responses for valid/invalid inputs; gRPC status codes correct
- **Dependencies**: Tasks 5.1, 3.4, 7.2
- **Estimate**: 2 days

#### Task 8.2: gRPC exception handler
- **What**: Implement `GrpcExceptionHandler` — maps domain exceptions to gRPC status codes with appropriate metadata (retry-after, reset-time)
- **Acceptance**: Unit test: each exception type maps to correct status; metadata populated
- **Dependencies**: Task 8.1
- **Estimate**: 0.5 day

---

### Task Group 9: End-to-End Testing

#### Task 9.1: Docker Compose setup
- **What**: Create `docker-compose.yml` with Postgres (audit), Redis, Vault dev, LocalStack (S3). Include test Postgres source.
- **Acceptance**: `docker-compose up` starts all dependencies; gateway connects successfully
- **Dependencies**: All above
- **Estimate**: 1 day

#### Task 9.2: E2E test suite
- **What**: Automated test: TestConnection → DescribeSchema → SampleRows → ExecuteQuery → StreamQuery → GetSourceHealth. Test against real Postgres source and S3.
- **Acceptance**: Full flow passes; audit records written; circuit breaker tested
- **Dependencies**: Task 9.1
- **Estimate**: 1.5 days

#### Task 9.3: Load test baseline
- **What**: Gatling/k6 script: 100 concurrent queries against Postgres source. Measure p50/p95/p99 latency, throughput, pool utilization.
- **Acceptance**: Gateway overhead p95 < 50ms; no connection leaks under load; metrics accurate
- **Dependencies**: Task 9.1
- **Estimate**: 1 day

---

## Summary

| Group | Tasks | Estimated Days |
|-------|-------|---------------|
| 1. Scaffolding | 6 | 4.5 |
| 2. Connector SPI & JDBC | 5 | 6 |
| 3. Connection Management | 4 | 5 |
| 4. Governance | 4 | 5.5 |
| 5. Query Broker | 4 | 5 |
| 6. Resilience | 3 | 3 |
| 7. S3 Connector | 3 | 4 |
| 8. gRPC Service | 2 | 2.5 |
| 9. E2E Testing | 3 | 3.5 |
| **Total** | **34** | **~39 days** |

**Critical path**: Scaffolding → Connector SPI → Connection Management → Query Broker → gRPC Service → E2E

**Parallelizable**:
- Governance (Group 4) can run in parallel with Connection Management (Group 3)
- S3 Connector (Group 7) can run in parallel with Query Broker (Group 5)
- Resilience (Group 6) can start after Connection Management (Group 3)
