# Technical Plan — Tool Registry Service

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      TOOL REGISTRY SERVICE                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │  MCP Server  │  │  REST API    │  │  Profiling Engine    │  │
│  │  (Java MCP   │  │  (Spring     │  │  (Spring Batch /     │  │
│  │   SDK)       │  │   REST)      │  │   Temporal)          │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘  │
│         │                  │                     │              │
│         └──────────┬───────┘                     │              │
│                    ▼                             │              │
│  ┌─────────────────────────────────┐            │              │
│  │         Domain Services          │◄───────────┘              │
│  │  SourceService, ToolService,     │                           │
│  │  DictionaryService, GlossaryService,                         │
│  │  ApprovalService, SearchService  │                           │
│  └──────────────┬──────────────────┘                           │
│                 │                                               │
│  ┌──────────────┼──────────────────────────────────────────┐   │
│  │              ▼                                          │   │
│  │  ┌────────────────┐  ┌─────────────┐  ┌────────────┐   │   │
│  │  │  JPA Repos     │  │  gRPC Client│  │  LLM Client│   │   │
│  │  │  (Postgres +   │  │  (to Data   │  │  (Enrichment│  │   │
│  │  │   pgvector)    │  │   Gateway)  │  │   + Embed)  │   │   │
│  │  └───────┬────────┘  └──────┬──────┘  └─────┬──────┘   │   │
│  │          │                  │               │           │   │
│  └──────────┼──────────────────┼───────────────┼───────────┘   │
│             │                  │               │               │
└─────────────┼──────────────────┼───────────────┼───────────────┘
              │                  │               │
              ▼                  ▼               ▼
         Postgres +         Data Gateway      LLM / Embedding
         pgvector           (gRPC/mTLS)       Provider
```

## 2. Module Structure

```
tool-registry/
├── pom.xml                              (parent POM)
├── platform-contracts/                  (shared proto — Git submodule or Maven dep)
│   └── src/main/proto/
│       └── gateway.proto
├── tool-registry-app/
│   ├── pom.xml
│   └── src/
│       ├── main/java/com/platform/toolregistry/
│       │   ├── ToolRegistryApplication.java
│       │   ├── config/
│       │   │   ├── GrpcClientConfig.java
│       │   │   ├── VaultConfig.java
│       │   │   ├── McpServerConfig.java
│       │   │   ├── CacheConfig.java
│       │   │   └── SecurityConfig.java
│       │   ├── domain/
│       │   │   ├── source/
│       │   │   │   ├── Source.java
│       │   │   │   ├── SourceObject.java
│       │   │   │   ├── SourceType.java (enum)
│       │   │   │   ├── SourceStatus.java (enum)
│       │   │   │   └── SourceRepository.java
│       │   │   ├── dictionary/
│       │   │   │   ├── ColumnProfile.java
│       │   │   │   ├── DictionaryEntry.java
│       │   │   │   ├── ApprovalStatus.java (enum)
│       │   │   │   └── DictionaryRepository.java
│       │   │   ├── glossary/
│       │   │   │   ├── GlossaryTerm.java
│       │   │   │   └── GlossaryRepository.java
│       │   │   ├── tool/
│       │   │   │   ├── ToolDefinition.java
│       │   │   │   ├── ToolStatus.java (enum)
│       │   │   │   └── ToolRepository.java
│       │   │   └── relationship/
│       │   │       ├── RelationshipCandidate.java
│       │   │       └── RelationshipRepository.java
│       │   ├── service/
│       │   │   ├── SourceOnboardingService.java
│       │   │   ├── ProfilingService.java
│       │   │   ├── LlmEnrichmentService.java
│       │   │   ├── DictionaryService.java
│       │   │   ├── GlossaryService.java
│       │   │   ├── ApprovalService.java
│       │   │   ├── ToolService.java
│       │   │   ├── SemanticSearchService.java
│       │   │   └── AuditService.java
│       │   ├── gateway/
│       │   │   ├── DataGatewayClient.java
│       │   │   └── DataGatewayHealthMonitor.java
│       │   ├── profiling/
│       │   │   ├── ProfilingJobLauncher.java
│       │   │   ├── ProfilingStep.java
│       │   │   └── SchemaChangeDetector.java
│       │   ├── mcp/
│       │   │   ├── McpToolServer.java
│       │   │   └── McpToolHandler.java
│       │   ├── rest/
│       │   │   ├── SourceController.java
│       │   │   ├── DictionaryController.java
│       │   │   ├── GlossaryController.java
│       │   │   ├── ToolController.java
│       │   │   └── ApprovalController.java
│       │   └── vault/
│       │       └── VaultCredentialWriter.java
│       └── main/resources/
│           ├── application.yml
│           ├── application-local.yml
│           └── db/migration/
│               ├── V001__create_source_tables.sql
│               ├── V002__create_dictionary_tables.sql
│               ├── V003__create_glossary_tables.sql
│               ├── V004__create_tool_tables.sql
│               ├── V005__create_audit_tables.sql
│               └── V006__enable_pgvector.sql
└── tool-registry-tests/
    ├── pom.xml
    └── src/test/java/
        ├── integration/
        └── unit/
```

## 3. Key Design Decisions

### 3.1 Caching Strategy

| Data | Cache | TTL | Invalidation |
|------|-------|-----|--------------|
| Tool descriptions | Caffeine L1 + Redis L2 | 5 min | On approval/re-profile |
| Glossary terms | Caffeine | 10 min | On import/edit |
| Source health status | Redis | 30 sec | On gateway health callback |
| Search embeddings | pgvector (persistent) | N/A | Re-embed on description change |

### 3.2 Profiling Job Design

- **Orchestrator**: Spring Batch (simpler for v1; Temporal if workflow complexity grows)
- **Job per object**: Each source_object gets an independent job
- **Steps**: `FetchSchema → SampleRows → ComputeStats → LlmEnrich → PersistDictionary`
- **Scheduling**: Cron-based (configurable per source) + on-demand trigger via API
- **Concurrency**: Bounded thread pool; max 10 concurrent profiling jobs per source to avoid gateway overload
- **Retry**: 3 retries with exponential backoff on transient failures; mark FAILED after exhaustion

### 3.3 LLM Enrichment

- **Input**: Column name, native type, sample values, table context (sibling columns), glossary terms
- **Output**: Semantic description, glossary term mapping (with confidence), relationship candidates
- **Model**: Configurable via feature flag (supports OpenAI, Bedrock, local models)
- **Batching**: Enrich all columns of an object in a single LLM call (reduces latency, improves context)
- **Fallback**: If LLM fails, persist profile without enrichment; schedule retry

### 3.4 MCP Server Implementation

- Java MCP SDK with stdio/SSE transport
- Tool definitions generated from `tool_definition` table
- Dynamic tool list — refreshed on approval events
- Each MCP tool maps 1:1 to a REST endpoint handler

### 3.5 gRPC Client to Data Gateway

- Generated stubs from `platform-contracts` proto
- mTLS with client certificate
- Deadline propagation (caller timeout → gRPC deadline)
- Circuit breaker wrapping gRPC calls (Resilience4j)
- Health monitoring via periodic `GetSourceHealth` calls

## 4. Database Migrations

Phase 1 migrations:
1. `V001` — source, source_object tables with indexes
2. `V002` — column_profile, dictionary_entry with pgvector column
3. `V003` — glossary_term
4. `V004` — tool_definition, relationship_candidate
5. `V005` — approval_event, audit_event (append-only)
6. `V006` — enable pgvector extension, create HNSW index

## 5. Configuration

```yaml
# application.yml (key sections)
spring:
  datasource:
    url: jdbc:postgresql://${DB_HOST}:5432/tool_registry
  batch:
    job:
      enabled: false  # triggered via API, not on startup

tool-registry:
  profiling:
    default-sample-size: 100
    max-concurrent-jobs: 10
    schedule-cron: "0 0 2 * * *"  # 2 AM daily
  cache:
    describe-ttl: 5m
    glossary-ttl: 10m
  search:
    embedding-model: text-embedding-3-small
    top-k-default: 10
  gateway:
    host: ${DATA_GATEWAY_HOST}
    port: 9090
    tls:
      cert-path: /etc/certs/client.pem
      key-path: /etc/certs/client-key.pem
      ca-path: /etc/certs/ca.pem
  vault:
    address: ${VAULT_ADDR}
    secret-path-prefix: data-platform/sources
  llm:
    provider: bedrock  # or openai, local
    model: anthropic.claude-3-haiku
    max-tokens: 4096
```

## 6. Observability

- **Traces**: OpenTelemetry auto-instrumentation for Spring Boot + manual spans for profiling jobs and LLM calls
- **Metrics**: Micrometer → Prometheus
  - `tool_registry_describe_latency_seconds` (histogram)
  - `tool_registry_search_latency_seconds` (histogram)
  - `tool_registry_profiling_jobs_active` (gauge)
  - `tool_registry_profiling_jobs_total` (counter by status)
  - `tool_registry_gateway_calls_total` (counter by RPC and status)
- **Logs**: Structured JSON, correlation ID propagated from incoming request
- **Health**: `/actuator/health` with sub-indicators for Postgres, pgvector, Data Gateway, Vault

## 7. Testing Strategy

| Layer | Tool | Scope |
|-------|------|-------|
| Unit | JUnit 5 + Mockito | Domain services, enrichment logic, schema change detection |
| Integration | Testcontainers (Postgres + pgvector) | Repository layer, migrations, search |
| Contract | gRPC mock server | Data Gateway client behavior |
| API | MockMvc + WebTestClient | REST controllers, MCP handler |
| E2E | Docker Compose (both services) | Full flow: register → profile → approve → query |
