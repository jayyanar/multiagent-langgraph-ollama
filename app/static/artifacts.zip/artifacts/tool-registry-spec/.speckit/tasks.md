# Tasks — Tool Registry Service

## Phase 1 — MVP Implementation

### Task Group 1: Project Scaffolding & Infrastructure

#### Task 1.1: Initialize Spring Boot project
- **What**: Create multi-module Maven project with `tool-registry-app` and `tool-registry-tests`
- **Acceptance**: `mvn clean compile` passes; Spring Boot app starts with empty context
- **Dependencies**: None
- **Estimate**: 0.5 day

#### Task 1.2: Set up platform-contracts dependency
- **What**: Add `platform-contracts` as Maven dependency (or Git submodule). Include proto file with all 6 RPCs defined. Generate Java stubs.
- **Acceptance**: gRPC stubs compile; `TestConnection`, `DescribeSchema`, `SampleRows`, `ExecuteQuery`, `StreamQuery`, `GetSourceHealth` stubs available
- **Dependencies**: Coordinate with Data Gateway team on proto definitions
- **Estimate**: 1 day

#### Task 1.3: Database setup with Flyway
- **What**: Configure Flyway, create migrations V001–V006 for all entities. Enable pgvector extension.
- **Acceptance**: `mvn flyway:migrate` creates all tables in local Postgres; pgvector HNSW index created
- **Dependencies**: Task 1.1
- **Estimate**: 1.5 days

#### Task 1.4: Configuration & profiles
- **What**: Set up `application.yml`, `application-local.yml`, `application-test.yml`. Externalize all secrets as env vars.
- **Acceptance**: App starts in local profile with embedded/local Postgres
- **Dependencies**: Task 1.1
- **Estimate**: 0.5 day

#### Task 1.5: Security & observability baseline
- **What**: Configure Spring Security (service-account auth), OpenTelemetry auto-instrumentation, structured logging, actuator health endpoints
- **Acceptance**: Requests require auth token; traces exported to collector; `/actuator/health` returns UP
- **Dependencies**: Task 1.1
- **Estimate**: 1 day

---

### Task Group 2: Source Onboarding

#### Task 2.1: Source domain model & repository
- **What**: Implement `Source`, `SourceObject` JPA entities, repositories, status lifecycle enum
- **Acceptance**: Unit tests for entity creation, status transitions; integration test persists to Testcontainers Postgres
- **Dependencies**: Task 1.3
- **Estimate**: 1 day

#### Task 2.2: Vault credential writer
- **What**: Implement `VaultCredentialWriter` — writes credentials to Vault, returns `vault_ref`
- **Acceptance**: Integration test with Vault dev server; credentials stored at configured path; only reference returned
- **Dependencies**: Task 1.4
- **Estimate**: 1 day

#### Task 2.3: Data Gateway gRPC client
- **What**: Implement `DataGatewayClient` wrapping generated stubs. Add mTLS config, deadline propagation, Resilience4j circuit breaker.
- **Acceptance**: Contract test with gRPC mock server; circuit breaker opens after 5 consecutive failures; deadline propagated
- **Dependencies**: Task 1.2
- **Estimate**: 1.5 days

#### Task 2.4: Source onboarding service
- **What**: Implement `SourceOnboardingService` — orchestrates: validate input → write creds to Vault → test connection via gateway → persist source + objects
- **Acceptance**: Unit test for happy path and failure scenarios (vault fail, connection fail, idempotent re-register)
- **Dependencies**: Tasks 2.1, 2.2, 2.3
- **Estimate**: 1.5 days

#### Task 2.5: Source REST controller
- **What**: Implement `SourceController` with endpoints: POST/GET/PUT/DELETE sources, POST test, GET objects
- **Acceptance**: MockMvc tests for all endpoints; proper error responses (400, 404, 502)
- **Dependencies**: Task 2.4
- **Estimate**: 1 day

---

### Task Group 3: Profiling & Data Dictionary

#### Task 3.1: Column profile domain model
- **What**: Implement `ColumnProfile`, `DictionaryEntry`, `ProfilingJob` entities and repositories
- **Acceptance**: Integration test persists profiles with JSON columns (top_k, samples)
- **Dependencies**: Task 1.3
- **Estimate**: 1 day

#### Task 3.2: Profiling job launcher
- **What**: Implement Spring Batch job: `FetchSchema → SampleRows → ComputeStats → PersistProfile`. Configurable sample size. Bounded concurrency.
- **Acceptance**: Integration test runs profiling job against mock gateway; profile persisted with stats
- **Dependencies**: Tasks 2.3, 3.1
- **Estimate**: 2 days

#### Task 3.3: LLM enrichment service
- **What**: Implement `LlmEnrichmentService` — takes column profiles + glossary terms, calls LLM, parses structured output into descriptions + mappings + relationship candidates
- **Acceptance**: Unit test with mocked LLM response; handles malformed LLM output gracefully
- **Dependencies**: Task 3.1
- **Estimate**: 2 days

#### Task 3.4: Enrichment step integration
- **What**: Add LLM enrichment as a step in the profiling batch job. Batch all columns of an object in one call. Fallback: persist without enrichment on failure.
- **Acceptance**: End-to-end profiling job produces enriched dictionary entries; partial success on LLM failure
- **Dependencies**: Tasks 3.2, 3.3
- **Estimate**: 1 day

#### Task 3.5: Schema change detection
- **What**: Implement `SchemaChangeDetector` — compares new schema against existing profiles; flags added/removed/renamed columns
- **Acceptance**: Unit test detects column additions, removals, type changes; creates appropriate review flags
- **Dependencies**: Task 3.1
- **Estimate**: 1 day

#### Task 3.6: Profiling REST endpoints
- **What**: POST trigger profiling, GET profiling job status, GET dictionary for object
- **Acceptance**: MockMvc tests; async job trigger returns job ID; polling returns status
- **Dependencies**: Tasks 3.2, 3.4
- **Estimate**: 0.5 day

---

### Task Group 4: Business Glossary

#### Task 4.1: Glossary domain model & repository
- **What**: Implement `GlossaryTerm` entity, repository, versioning
- **Acceptance**: Integration test for CRUD + version increment
- **Dependencies**: Task 1.3
- **Estimate**: 0.5 day

#### Task 4.2: Glossary import service
- **What**: Implement CSV/JSON import parsing, upsert logic (match on term name), validation
- **Acceptance**: Unit test imports 100-term CSV; handles duplicates, missing fields
- **Dependencies**: Task 4.1
- **Estimate**: 1 day

#### Task 4.3: Glossary REST controller
- **What**: POST import, GET list (paginated), PUT update term
- **Acceptance**: MockMvc tests for all endpoints
- **Dependencies**: Task 4.2
- **Estimate**: 0.5 day

---

### Task Group 5: Approval Workflow

#### Task 5.1: Approval service
- **What**: Implement `ApprovalService` — approve/reject dictionary entries, bulk approve with exceptions, create immutable approval events
- **Acceptance**: Unit tests for approve, reject, bulk-approve; rejected entries not exposed as tools; re-profile creates new pending version
- **Dependencies**: Task 3.1
- **Estimate**: 1 day

#### Task 5.2: Approval REST controller
- **What**: POST approve, POST reject, POST bulk-approve endpoints
- **Acceptance**: MockMvc tests; proper authorization checks (steward role required)
- **Dependencies**: Task 5.1
- **Estimate**: 0.5 day

---

### Task Group 6: Tool Exposure

#### Task 6.1: Tool definition generator
- **What**: Implement logic to generate `ToolDefinition` (MCP schema + REST schema) from approved dictionary entries. Triggered on approval.
- **Acceptance**: Unit test generates valid MCP tool schema from dictionary entry; schema includes parameter definitions
- **Dependencies**: Tasks 3.1, 5.1
- **Estimate**: 1.5 days

#### Task 6.2: Tool service — describe & sample
- **What**: Implement `ToolService.describe()` (cache-first, fallback to DB) and `ToolService.sample()` (delegates to gateway)
- **Acceptance**: Unit test for cache hit/miss; integration test for sample delegation
- **Dependencies**: Tasks 2.3, 6.1
- **Estimate**: 1 day

#### Task 6.3: Tool service — query
- **What**: Implement `ToolService.query()` — resolves statement template from tool definition, binds parameters, delegates to gateway `ExecuteQuery`
- **Acceptance**: Unit test for parameter binding; integration test with mock gateway
- **Dependencies**: Tasks 2.3, 6.1
- **Estimate**: 1.5 days

#### Task 6.4: Semantic search service
- **What**: Implement `SemanticSearchService` — embed query using embedding model, perform pgvector cosine similarity search, return ranked results
- **Acceptance**: Integration test with Testcontainers pgvector; returns relevant results for semantic query
- **Dependencies**: Tasks 1.3, 3.4
- **Estimate**: 1.5 days

#### Task 6.5: Tool REST controller
- **What**: GET /tools, GET /tools/{id}/describe, POST /tools/{id}/query, GET /tools/{id}/sample, POST /tools/search
- **Acceptance**: MockMvc tests for all endpoints; proper error handling for degraded tools
- **Dependencies**: Tasks 6.2, 6.3, 6.4
- **Estimate**: 1 day

#### Task 6.6: MCP server implementation
- **What**: Implement MCP server using Java MCP SDK. Register tools dynamically from `tool_definition` table. Handle describe/query/sample/search_tools.
- **Acceptance**: MCP client can list tools, call describe, execute query; tools refresh on approval
- **Dependencies**: Tasks 6.2, 6.3, 6.4
- **Estimate**: 2 days

---

### Task Group 7: Gateway Health & Degradation

#### Task 7.1: Health monitor
- **What**: Implement `DataGatewayHealthMonitor` — periodic `GetSourceHealth` calls, update source/tool status on degradation
- **Acceptance**: Unit test transitions tool to DEGRADED when health check fails; recovers when healthy
- **Dependencies**: Task 2.3
- **Estimate**: 1 day

---

### Task Group 8: End-to-End Testing

#### Task 8.1: Docker Compose setup
- **What**: Create `docker-compose.yml` with Postgres+pgvector, Vault dev, mock Data Gateway (or real if available)
- **Acceptance**: `docker-compose up` starts all dependencies; app connects successfully
- **Dependencies**: All above
- **Estimate**: 1 day

#### Task 8.2: E2E test suite
- **What**: Automated test: register source → profile → approve → describe tool → query tool → search tools
- **Acceptance**: Full flow passes in CI
- **Dependencies**: Task 8.1
- **Estimate**: 1.5 days

---

## Summary

| Group | Tasks | Estimated Days |
|-------|-------|---------------|
| 1. Scaffolding | 5 | 4.5 |
| 2. Source Onboarding | 5 | 6 |
| 3. Profiling & Dictionary | 6 | 7.5 |
| 4. Business Glossary | 3 | 2 |
| 5. Approval Workflow | 2 | 1.5 |
| 6. Tool Exposure | 6 | 8.5 |
| 7. Health & Degradation | 1 | 1 |
| 8. E2E Testing | 2 | 2.5 |
| **Total** | **30** | **~33.5 days** |

**Critical path**: Scaffolding → Source Onboarding → Profiling → Approval → Tool Exposure → E2E

**Parallelizable**: Glossary (Group 4) can run in parallel with Profiling (Group 3). Health monitoring (Group 7) can run in parallel with Tool Exposure (Group 6).
