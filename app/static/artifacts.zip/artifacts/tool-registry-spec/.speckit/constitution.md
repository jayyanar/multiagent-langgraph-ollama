# Project Constitution — Tool Registry

## Identity

**Project**: Tool Registry Service
**Platform**: Data-Aware Agent Platform
**Role**: System of record for **meaning** — catalogs data sources, profiles objects, produces curated Data Dictionaries, and exposes approved objects as callable Tools over MCP and REST.

## Core Principles

1. **Metadata-only service** — This service never opens a database connection to any data source. All data access is delegated to the Data Gateway via internal gRPC.
2. **Approval-gated exposure** — No data object is exposed as a Tool until a steward (human or bulk-approval policy) explicitly approves it.
3. **Contract-first** — The inter-service gRPC contract (`platform-contracts`) is the single source of truth for communication with Data Gateway. Changes are additive only.
4. **Semantic richness** — Every column/field must have a machine-readable description, glossary mapping, and relationship candidates before it can be approved.
5. **Dual transport** — Every Tool operation is available over both MCP (for LLM agents) and REST (for humans/debugging). Same logic, two serialization layers.
6. **Security posture** — Zero credentials at rest. Only Vault references stored. No secret ever appears in logs, responses, or error messages.

## Technology Constraints

- Java 21, Spring Boot 3
- Postgres for relational metadata
- pgvector for semantic search (OpenSearch as alternative)
- Java MCP SDK for MCP server
- Spring REST for REST surface
- Spring Batch or Temporal for profiling workflows
- Vault SDK for secret writes (reference only)
- OpenTelemetry for tracing and metrics
- gRPC client to Data Gateway (mTLS)
- Shared `platform-contracts` Maven artifact for proto definitions

## Engineering Practices

- Test-Driven Development for all domain logic
- Integration tests against embedded Postgres (Testcontainers)
- API-first design — OpenAPI spec generated from code annotations
- Flyway for database migrations
- Structured logging (JSON) with correlation IDs
- Feature flags for LLM enrichment strategies
- Git trunk-based development with short-lived feature branches

## Non-Functional Targets

| Property | Target |
|----------|--------|
| `describe` p95 latency | < 100 ms (cache-served) |
| `search_tools` p95 latency | < 300 ms over 50K objects |
| Catalog size | 100s of sources, 50K+ objects |
| Availability | 99.9% |
| Profiling throughput | 50K objects in < 24h |

## Out of Scope

- Agent Generator (downstream consumer, not part of this repo)
- Direct database connectivity (Data Gateway's responsibility)
- Write-back operations (Phase 3)
- Multi-region deployment (Phase 3)
