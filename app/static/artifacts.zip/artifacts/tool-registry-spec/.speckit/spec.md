# Specification — Tool Registry Service

## 1. Overview

The Tool Registry is the metadata backbone of the Data-Aware Agent Platform. It provides:

1. **Source onboarding** — Register data sources with connection metadata and Vault-stored credentials.
2. **Profiling & Data Dictionary** — Asynchronous jobs that sample data, capture column statistics, and invoke LLM enrichment to produce semantic descriptions, glossary mappings, and relationship candidates.
3. **Business Glossary** — An importable, versioned vocabulary of business terms used as authoritative input to LLM mapping.
4. **Steward Approval** — Human-in-the-loop (or bulk-policy) approval workflow before any object is exposed.
5. **Tool Exposure** — Each approved object becomes a callable Tool with `describe`, `query`, `sample`, and `search_tools` operations over MCP and REST.

## 2. Functional Requirements

### 2.1 Source Onboarding

| ID | Requirement |
|----|-------------|
| SR-01 | Register a source via REST API providing: name, type, endpoint, port, database/schema/bucket, auth method, scoped object list |
| SR-02 | Supported source types (Phase 1): Postgres, Oracle, S3. Extensible via `SourceType` plugin interface |
| SR-03 | Mongo input accepts collections. S3 input accepts bucket + prefix + format (parquet/csv/json) |
| SR-04 | "Test connection" must pass before save — delegates to Data Gateway `TestConnection` RPC |
| SR-05 | Credentials submitted once, written to Vault; only `vault_ref` (secret_id) persisted in registry DB |
| SR-06 | Re-registration is idempotent — updating endpoint or scoping objects must not invalidate existing dictionary entries unless the object disappears |
| SR-07 | Source status lifecycle: `PENDING_TEST → ACTIVE → DEGRADED → DEREGISTERED` |

### 2.2 Profiling & Data Dictionary

| ID | Requirement |
|----|-------------|
| PR-01 | On registration, on schedule, and on demand — launch a profiling job per object |
| PR-02 | Sample first N rows (default 100, per-source override) via Data Gateway `SampleRows` RPC |
| PR-03 | Capture per column: native type, nullability, distinct count in sample, min/max, top-K values, examples |
| PR-04 | S3: derive schema from headers/parquet metadata; sample N rows from first file matching prefix |
| PR-05 | LLM enrichment produces per column: plain-English semantic description, business glossary mapping, cross-object relationship candidates |
| PR-06 | Relationship candidates use: name similarity + value-overlap heuristic + LLM confirmation |
| PR-07 | Persist as versioned Dictionary records: `{source, object, column, native_type, samples, description, glossary_term, related_to[], version, approval_status}` |
| PR-08 | Profiling jobs run in separate quota bucket — never starve runtime traffic |
| PR-09 | Incremental re-profile detects schema drift (new/removed/renamed columns) and flags for review |

### 2.3 Business Glossary

| ID | Requirement |
|----|-------------|
| GL-01 | Import glossary from CSV/JSON: `{term, definition, synonyms[], owner}` |
| GL-02 | Versioned, editable via REST API |
| GL-03 | Used as authoritative input to LLM mapping pass |
| GL-04 | Glossary terms linkable to multiple dictionary entries |

### 2.4 Steward Approval Workflow

| ID | Requirement |
|----|-------------|
| AP-01 | Dictionary entries default to `PENDING_APPROVAL` status |
| AP-02 | Stewards approve/reject via REST API with reason |
| AP-03 | Bulk-approve-with-exceptions for objects at scale |
| AP-04 | Only `APPROVED` entries are exposed as Tools |
| AP-05 | Approval events are immutable audit records |
| AP-06 | Re-profiling a previously approved column creates a new version in `PENDING_APPROVAL` — previous approved version remains active until new version is approved |

### 2.5 Tool Exposure (MCP + REST)

| ID | Requirement |
|----|-------------|
| TE-01 | Each approved object becomes a Tool with a stable `tool_id` |
| TE-02 | `describe(tool_id)` — Returns approved dictionary entry: columns, types, descriptions, glossary mapping, sample values, related Tools. Served from local cache + Postgres |
| TE-03 | `query(tool_id, params)` — Parameterized read. Delegates to Data Gateway `ExecuteQuery` RPC. SQL templates for RDBMS, find/aggregate for Mongo, S3 select for S3 |
| TE-04 | `sample(tool_id, n)` — Fresh sample fetch bypassing dictionary samples. Delegates to Data Gateway `SampleRows` |
| TE-05 | `search_tools(q, k)` — Semantic search over dictionary. Returns ranked Tool IDs with descriptions. Backed by pgvector |
| TE-06 | MCP transport via Java MCP SDK; REST transport via Spring REST. Same service logic, two serialization layers |
| TE-07 | Tool schema versioned — when schema changes, Tool ID stays stable, schema version increments |
| TE-08 | Degraded sources: Tools marked as `DEGRADED` when Data Gateway circuit breaker opens; agents receive degradation notice in `describe` response |

### 2.6 Semantic Search

| ID | Requirement |
|----|-------------|
| SS-01 | Embed dictionary descriptions using an embedding model at dictionary write time |
| SS-02 | Store embeddings in pgvector |
| SS-03 | `search_tools` performs cosine similarity search, returns top-k results |
| SS-04 | Re-embed on description update |

## 3. Data Model

### 3.1 Entities

```
source(id, name, type, endpoint, port, database_schema, vault_ref, status, created_by, created_at, updated_at)
source_object(id, source_id, kind[TABLE|COLLECTION|PREFIX], name, native_metadata_json, status, created_at)
column_profile(id, object_id, name, native_type, nullable, distinct_count, min_val, max_val, top_k_json, samples_json, profiled_at)
dictionary_entry(id, column_profile_id, version, description, embedding, glossary_term_id, approval_status, approved_by, approved_at, created_at)
glossary_term(id, term, definition, synonyms_json, owner, version, created_at, updated_at)
relationship_candidate(id, from_column_id, to_column_id, evidence_json, confidence, status[SUGGESTED|CONFIRMED|REJECTED], confirmed_by, created_at)
tool_definition(id, object_id, version, mcp_schema_json, rest_schema_json, status[ACTIVE|DEGRADED|RETIRED], created_at)
approval_event(id, entity_type, entity_id, actor, decision[APPROVED|REJECTED], reason, created_at)
audit_event(id, actor, action, entity_type, entity_id, payload_json, created_at)
profiling_job(id, source_id, object_id, status[QUEUED|RUNNING|COMPLETED|FAILED], started_at, completed_at, error_message)
```

### 3.2 Indexes

- `dictionary_entry.embedding` — pgvector HNSW index for semantic search
- `source_object(source_id, name)` — unique constraint
- `dictionary_entry(column_profile_id, version)` — unique constraint
- `tool_definition(object_id, status)` — for active tool lookup
- `audit_event(created_at)` — for time-range queries

## 4. API Surface

### 4.1 REST Endpoints

```
POST   /api/v1/sources                    — Register source
GET    /api/v1/sources                    — List sources
GET    /api/v1/sources/{id}               — Get source details
PUT    /api/v1/sources/{id}               — Update source
DELETE /api/v1/sources/{id}               — Deregister source
POST   /api/v1/sources/{id}/test          — Test connection

GET    /api/v1/sources/{id}/objects       — List objects
GET    /api/v1/objects/{id}               — Get object details
POST   /api/v1/objects/{id}/profile       — Trigger profiling

GET    /api/v1/dictionary/{object_id}     — Get dictionary for object
POST   /api/v1/dictionary/{id}/approve    — Approve entry
POST   /api/v1/dictionary/{id}/reject     — Reject entry
POST   /api/v1/dictionary/bulk-approve    — Bulk approve

POST   /api/v1/glossary/import            — Import glossary
GET    /api/v1/glossary                   — List terms
PUT    /api/v1/glossary/{id}              — Update term

GET    /api/v1/tools                      — List active tools
GET    /api/v1/tools/{id}/describe        — Describe tool
POST   /api/v1/tools/{id}/query           — Execute query
GET    /api/v1/tools/{id}/sample          — Get sample
POST   /api/v1/tools/search               — Semantic search
```

### 4.2 MCP Tools

```
describe(tool_id)        — Same as REST describe
query(tool_id, params)   — Same as REST query
sample(tool_id, n)       — Same as REST sample
search_tools(q, k)       — Same as REST search
```

## 5. Integration Points

| System | Protocol | Direction | Purpose |
|--------|----------|-----------|---------|
| Data Gateway | gRPC (mTLS) | Outbound | TestConnection, DescribeSchema, SampleRows, ExecuteQuery, StreamQuery, GetSourceHealth |
| Vault | Vault SDK | Outbound | Write credentials on registration, read vault_ref for validation |
| LLM Provider | HTTP/SDK | Outbound | Column enrichment, glossary mapping, relationship confirmation |
| Embedding Model | HTTP/SDK | Outbound | Generate embeddings for semantic search |

## 6. Error Handling

| Scenario | Behavior |
|----------|----------|
| Data Gateway unavailable | Return 503 for query/sample; describe served from cache |
| Source degraded (circuit open) | Mark tools as DEGRADED; include notice in describe response |
| LLM enrichment fails | Profiling job marked PARTIAL; column profile saved without enrichment; retry scheduled |
| Vault unreachable on registration | Fail registration with 502; no partial state saved |
| Semantic search index stale | Serve from last-known-good; background re-index |

## 7. Security

- No credentials stored in registry DB — only Vault references
- All API endpoints require authentication (service-account or user token)
- Audit trail for all mutations (source registration, approvals, dictionary edits)
- mTLS for Data Gateway communication
- Input validation on all API parameters; parameterized queries only
- Rate limiting on public-facing endpoints
