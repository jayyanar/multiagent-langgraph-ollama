#!/usr/bin/env bash
# Local HyperExecute runner. Use to validate a yaml before pushing to CI.
#
# Usage:
#   ./run-locally.sh <config.yaml>
# Example:
#   ./run-locally.sh hyperexecute-autosplit-ts.yaml

set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "usage: $0 <hyperexecute.yaml>" >&2
  exit 1
fi
CONFIG="$1"

# Load env vars from a local .env if present (gitignored).
if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

: "${LT_USERNAME:?set LT_USERNAME (LambdaTest username)}"
: "${LT_ACCESS_KEY:?set LT_ACCESS_KEY (LambdaTest access key)}"

if [[ ! -x ./hyperexecute ]]; then
  echo "Downloading HyperExecute CLI..."
  os="$(uname -s | tr '[:upper:]' '[:lower:]')"
  curl -fsSL "https://downloads.lambdatest.com/hyperexecute/${os}/hyperexecute" -o hyperexecute
  chmod +x hyperexecute
fi

./hyperexecute \
  --user "$LT_USERNAME" \
  --key "$LT_ACCESS_KEY" \
  --config "$CONFIG" \
  --verbose
