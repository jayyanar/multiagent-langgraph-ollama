// UI test starter — Repo 6 (Dashboard Web, ReactJS).
//
// Required env vars:
//   BASE_UI_URL         - e.g. https://dashboard.dev.example.com
//
// Pre-requisite: globalSetup created storageState.json with a logged-in session.

import { test, expect } from '@playwright/test';
import { DashboardPage } from '../pages/DashboardPage';

test.describe('Dashboard - <feature under test>', () => {
  let dashboard: DashboardPage;

  test.beforeEach(async ({ page }) => {
    dashboard = new DashboardPage(page);
    await dashboard.goto();
  });

  test('should <observable behavior, written in user terms>', async ({ page }) => {
    // Arrange — make the page show the state you want to test.
    await dashboard.refresh();

    // Act — perform the interaction under test.
    const rowCount = await dashboard.getRowCount();

    // Assert — specific expectations on observable state.
    expect(rowCount).toBeGreaterThan(0);
  });
});
