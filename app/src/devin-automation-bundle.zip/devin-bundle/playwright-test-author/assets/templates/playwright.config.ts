import { defineConfig, devices } from '@playwright/test';

/**
 * Multi-project Playwright config.
 *  - `ui-*`     : browser tests for Repo 6 (Dashboard Web)
 *  - `api`      : API tests for Repos 2, 3, 4
 *  - `contract` : cross-service contract tests (Repo 2 ↔ Repo 5 contract on the consumer side)
 *
 * Required env vars:
 *   BASE_UI_URL          - e.g. https://dashboard.dev.example.com
 *   PROMPT_API_URL       - e.g. https://prompts.dev.example.com
 *   INGESTION_API_URL    - e.g. https://ingest.dev.example.com
 *   DASHBOARD_API_URL    - e.g. https://dashboard-svc.dev.example.com
 *   MONGO_URL            - for Dashboard Service Mongo assertions
 */
export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 4 : undefined,
  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['junit', { outputFile: 'reports/junit.xml' }],
  ],
  use: {
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    {
      name: 'ui-chromium',
      testDir: './tests/ui',
      use: { ...devices['Desktop Chrome'], baseURL: process.env.BASE_UI_URL, storageState: 'storageState.json' },
    },
    {
      name: 'ui-firefox',
      testDir: './tests/ui',
      use: { ...devices['Desktop Firefox'], baseURL: process.env.BASE_UI_URL, storageState: 'storageState.json' },
    },
    {
      name: 'ui-webkit',
      testDir: './tests/ui',
      use: { ...devices['Desktop Safari'], baseURL: process.env.BASE_UI_URL, storageState: 'storageState.json' },
    },
    {
      name: 'api',
      testDir: './tests/api',
      use: {},
    },
    {
      name: 'contract',
      testDir: './tests/contract',
      use: {},
    },
  ],
  globalSetup: './global-setup.ts',
});
