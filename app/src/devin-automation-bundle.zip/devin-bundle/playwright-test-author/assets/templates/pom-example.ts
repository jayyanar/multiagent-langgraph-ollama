// Page Object Model example — Repo 6 (Dashboard Web).
//
// One class per page. The class exposes ACTIONS and STATE QUERIES, not raw locators.

import { Page, Locator, expect } from '@playwright/test';

export class DashboardPage {
  readonly page: Page;
  private readonly heading: Locator;
  private readonly refreshButton: Locator;
  private readonly resultsTable: Locator;
  private readonly dateRangeStart: Locator;
  private readonly dateRangeEnd: Locator;
  private readonly applyFiltersButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.heading = page.getByRole('heading', { name: 'Dashboard' });
    this.refreshButton = page.getByRole('button', { name: 'Refresh' });
    this.resultsTable = page.getByTestId('results-table');
    this.dateRangeStart = page.getByLabel('Start date');
    this.dateRangeEnd = page.getByLabel('End date');
    this.applyFiltersButton = page.getByRole('button', { name: 'Apply filters' });
  }

  async goto(): Promise<void> {
    await this.page.goto('/dashboard');
    await expect(this.heading).toBeVisible();
  }

  async refresh(): Promise<void> {
    await this.refreshButton.click();
    await this.page.waitForLoadState('networkidle');
  }

  async applyDateRange(start: string, end: string): Promise<void> {
    await this.dateRangeStart.fill(start);
    await this.dateRangeEnd.fill(end);
    await this.applyFiltersButton.click();
    await this.page.waitForLoadState('networkidle');
  }

  async getRowCount(): Promise<number> {
    return this.resultsTable.getByRole('row').count();
  }

  async getRowText(rowIndex: number): Promise<string> {
    const row = this.resultsTable.getByRole('row').nth(rowIndex);
    return (await row.textContent()) ?? '';
  }
}
