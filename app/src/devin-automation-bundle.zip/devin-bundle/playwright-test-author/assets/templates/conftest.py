"""Shared pytest fixtures for the Python AI Service test suite (Repo 5).

Required env vars (load via .env or your CI secrets manager):
  AI_SERVICE_URL       - base URL of the AI Service under test
  PROMPT_API_URL       - Prompt Management base URL (Repo 3)
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pytest


@pytest.fixture
def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


@pytest.fixture
def env_required() -> dict[str, str]:
    """Assert required env vars exist before a test runs."""
    keys = ["AI_SERVICE_URL", "PROMPT_API_URL"]
    missing = [k for k in keys if not os.environ.get(k)]
    if missing:
        pytest.skip(f"missing required env vars: {missing}")
    return {k: os.environ[k] for k in keys}


@pytest.fixture
def fake_llm(monkeypatch: pytest.MonkeyPatch) -> dict[str, Any]:
    """Patch the AI Service's LLM adapter so tests are deterministic and offline.

    The fixture returns a dict you can inspect:
      captured["calls"] -> list of {"prompt": str, "kwargs": dict}
    """
    captured: dict[str, list[dict[str, Any]]] = {"calls": []}

    def fake_invoke(prompt: str, **kwargs: Any) -> dict[str, Any]:
        captured["calls"].append({"prompt": prompt, "kwargs": kwargs})
        return {"text": "stubbed response", "input_tokens": 42, "output_tokens": 10}

    try:
        from ai_service.adapters import llm
    except ImportError:
        pytest.skip("ai_service not importable; install the service package")
    monkeypatch.setattr(llm, "invoke", fake_invoke)
    return captured


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """Mark live (real-LLM) tests so they're opt-in."""
    if not config.getoption("--run-live", default=False):
        skip_live = pytest.mark.skip(reason="opt-in with --run-live")
        for item in items:
            if "live" in item.keywords:
                item.add_marker(skip_live)


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption("--run-live", action="store_true", help="run tests marked @pytest.mark.live")
