// API test starter — Repos 2 (Ingestion), 3 (Prompt Mgmt), 4 (Dashboard Service).
//
// Required env vars (depending on repo under test):
//   PROMPT_API_URL, INGESTION_API_URL, DASHBOARD_API_URL
//   <SERVICE>_API_TOKEN  - service account token for the test tenant

import { test, expect } from '@playwright/test';
import { PromptService } from '../services/PromptService';

test.describe('Prompt Management - <feature>', () => {
  let prompts: PromptService;
  const createdIds: string[] = [];

  test.beforeEach(async ({ request }) => {
    prompts = new PromptService(request, process.env.PROMPT_API_URL!);
  });

  test.afterEach(async () => {
    for (const id of createdIds) {
      await prompts.delete(id);
    }
    createdIds.length = 0;
  });

  test('should create a prompt with valid payload', async () => {
    const res = await prompts.create({ name: `t-${Date.now()}`, template: 'Hi {{name}}' });
    expect(res.status()).toBe(201);
    const body = await res.json();
    expect(body.id).toBeDefined();
    createdIds.push(body.id);
  });

  test('should reject prompt creation when name exceeds 200 characters', async () => {
    const res = await prompts.create({ name: 'x'.repeat(201), template: 'ok' });
    expect(res.status()).toBe(400);
    const body = await res.json();
    expect(body.error).toMatch(/name.*length/i);
  });
});
