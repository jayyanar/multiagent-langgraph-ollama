"""AI Service contract test starter — Repo 5 (Python + Google ADK).

Run:
    pytest py/tests/ai/test_response_shape.py -v
"""
from __future__ import annotations

from typing import Any

import pytest

# Prompt-id snapshots. Update intentionally when prompts change in Repo 3.
SUMMARIZE_PROMPT_ID = "summarize.v3"
CLASSIFY_PROMPT_ID = "classify.v2"


def test_summarize_response_has_required_fields(fake_llm: dict[str, Any]) -> None:
    """Shape contract: required fields and types are present on the response."""
    from ai_service.app import process_request

    response = process_request({
        "request_id": "req-001",
        "type": "summarize",
        "payload": {"text": "hello world"},
    })

    assert "request_id" in response
    assert "text" in response
    assert "prompt_id" in response
    assert "usage" in response

    assert isinstance(response["text"], str)
    assert isinstance(response["usage"]["input_tokens"], int)
    assert isinstance(response["usage"]["output_tokens"], int)

    # invariant: request_id round-trips
    assert response["request_id"] == "req-001"


def test_summarize_uses_pinned_prompt_id(fake_llm: dict[str, Any]) -> None:
    """Prompt regression: the summarize request type must use the pinned prompt id."""
    from ai_service.app import process_request

    response = process_request({"request_id": "x", "type": "summarize", "payload": {"text": "..."}})
    assert response["prompt_id"] == SUMMARIZE_PROMPT_ID


def test_response_does_not_echo_pii(monkeypatch: pytest.MonkeyPatch) -> None:
    """Policy: PII present in the input must not appear in the response."""
    from ai_service.adapters import llm
    from ai_service.app import process_request

    # have the fake LLM echo the prompt, so we can check redaction
    monkeypatch.setattr(
        llm, "invoke",
        lambda prompt, **kw: {"text": prompt, "input_tokens": 1, "output_tokens": 1},
    )

    response = process_request({
        "request_id": "r",
        "type": "summarize",
        "payload": {"text": "My SSN is 123-45-6789"},
    })

    assert "123-45-6789" not in response["text"], "service must redact PII before returning"


def test_returns_documented_error_when_prompt_missing(monkeypatch: pytest.MonkeyPatch, fake_llm: dict[str, Any]) -> None:
    """Error fallback: unknown request types return the documented error envelope."""
    from ai_service.adapters import prompts
    from ai_service.app import process_request

    monkeypatch.setattr(prompts, "fetch", lambda pid: None)

    response = process_request({"request_id": "r", "type": "unknown_type", "payload": {}})

    assert response["status"] == "error"
    assert response["error"]["code"] == "PROMPT_NOT_FOUND"


@pytest.mark.live
def test_live_summarize_returns_text() -> None:
    """End-to-end against a real (small, cheap) model. Opt-in: pytest --run-live."""
    from ai_service.app import process_request

    response = process_request({
        "request_id": "live-1",
        "type": "summarize",
        "payload": {"text": "The quick brown fox jumps over the lazy dog."},
    })
    assert isinstance(response["text"], str)
    assert len(response["text"]) > 0
    assert response["usage"]["output_tokens"] <= 200
