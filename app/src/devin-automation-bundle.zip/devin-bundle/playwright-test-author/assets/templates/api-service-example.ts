// Service Object example — Repos 2, 3, 4.
//
// One class per backend service. Tests call domain methods; the service object
// hides URL paths, auth headers, and payload shape.

import { APIRequestContext, APIResponse } from '@playwright/test';

export interface PromptPayload {
  name: string;
  template: string;
  tags?: string[];
}

export class PromptService {
  constructor(
    private readonly request: APIRequestContext,
    private readonly baseUrl: string,
    private readonly token: string = process.env.PROMPT_API_TOKEN ?? '',
  ) {}

  private headers(): Record<string, string> {
    return {
      'Authorization': `Bearer ${this.token}`,
      'Content-Type': 'application/json',
    };
  }

  async create(payload: PromptPayload): Promise<APIResponse> {
    return this.request.post(`${this.baseUrl}/prompts`, { data: payload, headers: this.headers() });
  }

  async get(id: string): Promise<APIResponse> {
    return this.request.get(`${this.baseUrl}/prompts/${id}`, { headers: this.headers() });
  }

  async update(id: string, payload: Partial<PromptPayload>): Promise<APIResponse> {
    return this.request.patch(`${this.baseUrl}/prompts/${id}`, { data: payload, headers: this.headers() });
  }

  async delete(id: string): Promise<APIResponse> {
    return this.request.delete(`${this.baseUrl}/prompts/${id}`, { headers: this.headers() });
  }

  async list(params: { tag?: string } = {}): Promise<APIResponse> {
    return this.request.get(`${this.baseUrl}/prompts`, { params, headers: this.headers() });
  }

  /**
   * Convenience: create a prompt with sensible defaults and return its id.
   * Use this in tests where the prompt itself isn't the subject of the test.
   */
  async createWithDefaults(overrides: Partial<PromptPayload> = {}): Promise<{ id: string; payload: PromptPayload }> {
    const payload: PromptPayload = {
      name: `prompt-${Date.now()}`,
      template: 'You are a helpful assistant. {{input}}',
      tags: ['test'],
      ...overrides,
    };
    const res = await this.create(payload);
    if (res.status() !== 201) {
      throw new Error(`createWithDefaults failed: ${res.status()} ${await res.text()}`);
    }
    const body = await res.json();
    return { id: body.id, payload };
  }
}
