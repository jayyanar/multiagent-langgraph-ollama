# HyperExecute Execution Modes — Decision Guide

HyperExecute supports several execution shapes. The two main ones for our suites are **matrix** and **auto-split**. The other two — **smart retry** and **artifact upload** — are orthogonal and apply on top of either mode.

## Matrix Mode

Run the same suite once per parameter combination. Each combination runs in its own lane.

**Use when:**
- You need cross-browser coverage for UI (Repo 6) — Chrome, Firefox, Edge, WebKit.
- You need cross-OS coverage (rare; only when OS-specific behavior matters).
- You need to run multiple "personas" (admin / standard user / read-only) and the test logic is identical across them.

**Don't use for:**
- API-only suites — they have no browser/OS dimension to vary. Use auto-split instead.
- Long suites you just want faster — matrix multiplies cost. Auto-split divides time.

**Example matrix (TS UI suite):**

```yaml
matrix:
  browser: [chrome, firefox, edge, webkit]
  os: [linux]
testRunnerCommand: 'npx playwright test --project=ui-$browser --reporter=junit'
```

This produces 4 lanes. Each runs the full UI suite under a different browser.

## Auto-Split Mode

HyperExecute reads a discovery command that prints test paths, then distributes those paths across N concurrent lanes. Each lane runs a subset of the suite.

**Use when:**
- The suite is long enough that wall-clock time matters (typically > 5 min serial).
- The suite has no parameter dimension to vary.
- You want fast PR feedback.

**Don't use for:**
- Tests with order dependencies (auto-split assumes independence).
- Tests that share global state on the test runner (sharing is fine if managed via fixtures; bad if implicit).

**Example auto-split (Python AI contract suite):**

```yaml
testDiscovery:
  type: raw
  mode: dynamic
  command: 'find py/tests/ai -name "test_*.py" -type f'
concurrency: 6
testRunnerCommand: 'pytest $test -v --junitxml=reports/$test.xml'
```

This finds all AI test files, distributes them across 6 lanes, and each lane runs one or more files via `pytest`.

## Hybrid: Matrix × Auto-Split

You can combine them — for example, "run the UI suite across 4 browsers, and within each browser shard tests across 3 lanes" — but only do this when the savings justify the lane count (4 × 3 = 12 lanes).

```yaml
matrix:
  browser: [chrome, firefox, edge, webkit]
testDiscovery:
  type: raw
  mode: dynamic
  command: 'find tests/ui -name "*.spec.ts"'
concurrency: 3
testRunnerCommand: 'npx playwright test $test --project=ui-$browser'
```

For our stack, this is overkill for PR runs. Reserve hybrid for nightly regression.

## Smart Retry

After the main run, HyperExecute can re-run only the failed tests. This separates real failures from flakes in the report.

```yaml
retryOnFailure: true
maxRetries: 1
```

**Guidance:**
- PR runs: `maxRetries: 0` or `1`. Don't paper over flakes.
- Nightly regression: `maxRetries: 2`. The goal is reliable signal, not bug discovery on the second try.
- Always look at retry counts in the report. A high retry rate is a flake-debt signal — pay it down.

## Artifact Upload

Always upload, period. Failure investigation without traces is guesswork.

```yaml
postDirectives:
  upload:
    - playwright-report/**
    - test-results/**
    - reports/junit*.xml
    - traces/**
```

For Playwright specifically, `trace: 'retain-on-failure'` in `playwright.config.ts` ensures traces only exist for failed tests — keeping artifact size manageable while preserving debuggability.

## How to choose, fast

1. Is the suite a UI suite needing cross-browser coverage? → **Matrix** (browser × linux).
2. Is the suite an API or Python suite? → **Auto-split**.
3. Is the suite > 10 min serial and not parameterized? → **Auto-split** with concurrency ≥ 4.
4. Are the tests known-flaky? → Address the root cause first; then enable `maxRetries: 1` as a safety net.
5. Is this a nightly regression? → **Auto-split + smart retry + full artifact upload**.
