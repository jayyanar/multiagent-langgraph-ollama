# TypeScript UI Tests — Repo 6 (Dashboard Web, ReactJS)

This reference covers UI/E2E tests for the React dashboard. Use Playwright with TypeScript and the Page Object Model (POM) pattern.

## Folder layout

```
ts/tests/ui/
├── pages/                  # Page Object Models (one class per page)
│   ├── BasePage.ts
│   ├── LoginPage.ts
│   └── DashboardPage.ts
├── components/             # Reusable component objects (modal, table, header)
└── specs/                  # Test files (.spec.ts)
    ├── auth/
    ├── dashboard/
    └── filters/
```

## Page Object Model rules

1. One class per page. The class exposes **actions** (`login(user, pw)`) and **state queries** (`getRowCount()`) — never raw locators.
2. Selectors live as private properties at the top of the class. If a designer renames a class, the selector changes in one place.
3. POMs return data, not Playwright objects (with the exception of returning `this` for chaining).
4. POMs accept a `Page` in the constructor. They don't create one.

```typescript
import { Page, Locator, expect } from '@playwright/test';

export class DashboardPage {
  readonly page: Page;
  private readonly heading: Locator;
  private readonly refreshButton: Locator;
  private readonly resultsTable: Locator;

  constructor(page: Page) {
    this.page = page;
    this.heading = page.getByRole('heading', { name: 'Dashboard' });
    this.refreshButton = page.getByRole('button', { name: 'Refresh' });
    this.resultsTable = page.getByTestId('results-table');
  }

  async goto(): Promise<void> {
    await this.page.goto('/dashboard');
    await expect(this.heading).toBeVisible();
  }

  async refresh(): Promise<void> {
    await this.refreshButton.click();
    await this.page.waitForLoadState('networkidle');
  }

  async getRowCount(): Promise<number> {
    return this.resultsTable.getByRole('row').count();
  }
}
```

## Selector priority

Use in this order, falling back only when the prior option isn't available:

1. `getByRole(...)` — most resilient, accessible.
2. `getByLabel(...)` — form inputs.
3. `getByTestId(...)` — add `data-testid` to React components when role/label aren't unique.
4. `getByText(...)` — for static, copy-stable strings (avoid for dynamic content).
5. CSS selectors — last resort, comment why.

Avoid `nth-child`, deep CSS chains, and class-based selectors. They break on visual refactors.

## Test file structure

```typescript
import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';
import { testUser } from '../../../data/users';

test.describe('Dashboard - Filters', () => {
  let dashboard: DashboardPage;

  test.beforeEach(async ({ page }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.signIn(testUser.email, testUser.password);
    dashboard = new DashboardPage(page);
    await dashboard.goto();
  });

  test('should filter results by date range', async ({ page }) => {
    await dashboard.applyDateRange('2026-01-01', '2026-01-31');
    const count = await dashboard.getRowCount();
    expect(count).toBeGreaterThan(0);
    expect(count).toBeLessThan(1000);
  });
});
```

## Auth handling

Don't log in inside every test. Use storage state.

```typescript
// global-setup.ts
import { chromium, FullConfig } from '@playwright/test';

async function globalSetup(config: FullConfig) {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  // perform login flow
  await page.context().storageState({ path: 'storageState.json' });
  await browser.close();
}
export default globalSetup;
```

Reference `storageState.json` in `playwright.config.ts` under `use`.

## Visual & accessibility tests

For visual regression:

```typescript
await expect(page).toHaveScreenshot('dashboard-empty.png', { maxDiffPixels: 100 });
```

For accessibility (install `@axe-core/playwright`):

```typescript
import AxeBuilder from '@axe-core/playwright';

test('dashboard has no a11y violations', async ({ page }) => {
  await new DashboardPage(page).goto();
  const results = await new AxeBuilder({ page }).analyze();
  expect(results.violations).toEqual([]);
});
```

## Common pitfalls

- **Hard waits (`page.waitForTimeout(2000)`)**: never use them. Wait on the thing you actually expect (`expect(locator).toBeVisible()`).
- **Race conditions on data load**: use `page.waitForResponse(url)` if the API is slow.
- **Stale POM**: if the page navigates, re-instantiate the POM. Don't reuse old locators.
- **CSS-only selectors**: brittle. Anything beyond `data-testid` should make you nervous.
