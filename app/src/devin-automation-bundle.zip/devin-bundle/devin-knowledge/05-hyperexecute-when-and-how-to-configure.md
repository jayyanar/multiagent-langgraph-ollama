# hyperexecute: when and how to configure


# HyperExecute Runner

## What this skill does

This skill produces the configuration and procedures needed to execute Playwright test suites on LambdaTest HyperExecute. It handles TypeScript and Python suites, four execution modes, secrets, artifacts, retries, and CI integration.

It does NOT author tests — that's `playwright-test-author`. If the user hasn't written tests yet, hand them off to that skill first.

## Scope: which repos this covers

| Repo | Name | Suite Language | Default Mode |
|------|------|----------------|--------------|
| Repo 2 | Ingestion Pipeline (Java) | TypeScript API | Auto-split |
| Repo 3 | Prompt Management | TypeScript API | Auto-split |
| Repo 4 | Dashboard Service | TypeScript API | Auto-split |
| Repo 5 | AI Service (Python + Google ADK) | Python contract | Auto-split (mock) + Matrix (live, nightly only) |
| Repo 6 | Dashboard Web (ReactJS) | TypeScript UI | Matrix (browser × OS) |

## When the user asks to run on HyperExecute, do this FIRST

1. **Identify the suite's language** — TypeScript (UI for Repo 6, API for Repos 2/3/4) or Python (Repo 5).
2. **Identify the execution mode** the user wants. If unspecified, default to **auto-split** for fastest feedback. Always offer matrix as the alternative for cross-browser coverage.
3. **Read the matching reference file**:
   - `references/execution-modes.md` — when to use matrix vs auto-split vs hybrid.
   - `references/ci-integration.md` — wiring HyperExecute into GitHub Actions / Jenkins / GitLab.
   - `references/troubleshooting.md` — common failure modes and fixes.
4. **Generate the yaml** from the matching template under `assets/templates/`.
5. **Always include**: secrets binding, artifact upload, retry config, and a reasonable concurrency value.
6. **Output the CLI command** the user can run locally to verify before pushing to CI.

## Language → Mode → Template Matrix

| Suite Language | Best Default Mode | Template |
|----------------|-------------------|----------|
| TypeScript (UI cross-browser) | Matrix (browser × OS) | `assets/templates/hyperexecute-matrix-ts.yaml` |
| TypeScript (API only) | Auto-split | `assets/templates/hyperexecute-autosplit-ts.yaml` |
| Python (AI contract, mocked) | Auto-split | `assets/templates/hyperexecute-autosplit-py.yaml` |
| Python (live LLM smoke) | Matrix (single lane, gated) | `assets/templates/hyperexecute-matrix-py.yaml` |

Matrix mode runs the same suite under different parameter combinations (browser, OS, region). Use it for cross-browser coverage. Auto-split mode shards tests across concurrent lanes for speed. Use it when there's no parameter dimension to vary.

## Execution Modes (high-level)

### Matrix Mode

You define a matrix of parameters (e.g., browser × OS). HyperExecute runs the full test suite once per combination. Use for:
- Cross-browser UI tests (Repo 6) — Chromium, Firefox, WebKit.
- Cross-OS coverage when relevant (rare for this stack).
- Multiple test "personas" (e.g., admin vs user roles).

### Auto-split Mode

HyperExecute reads the list of tests from a discovery command, then automatically distributes test files across N concurrent lanes. Use for:
- Long suites where wall-clock time matters.
- API and Python suites that have no parameter dimension.
- Reducing CI feedback time from 30 min → 5 min.

### Smart Retry

Configure HyperExecute to retry only the failed tests after a run, with separate reporting. This isolates real failures from flakes. Always enable for nightly runs; consider disabling for fast PR runs where flake budget is low.

### Artifact Handling

Always upload:
- Playwright HTML report
- Test traces (`.zip`) for failed tests
- Screenshots and videos (already captured by Playwright config)
- JUnit XML (for Octane ingestion later)

Failure investigation without traces wastes hours. Never skip this.

## Standard outputs

Every time you generate a HyperExecute setup, produce:

1. **`hyperexecute.yaml`** — the config.
2. **`.env.example`** — listing required env vars (without values).
3. **CLI command** to run locally:
   ```bash
   ./hyperexecute --user $LT_USERNAME --key $LT_ACCESS_KEY --config hyperexecute.yaml --verbose
   ```
4. **CI snippet** for the user's CI of choice (GitHub Actions by default).
5. **A one-paragraph "what happens when you run this"** so the user knows what to expect (lanes, duration estimate, artifacts produced).

## Required environment variables

| Var | Purpose |
|-----|---------|
| `LT_USERNAME` | LambdaTest username |
| `LT_ACCESS_KEY` | LambdaTest access key |
| `BASE_UI_URL`, `PROMPT_API_URL`, `INGESTION_API_URL`, `DASHBOARD_API_URL`, `AI_SERVICE_URL`, `MONGO_URL` | Service endpoints — bind these via env section in the yaml so test runners see them |
| `*_API_TOKEN` | Per-service auth tokens |
| `GOOGLE_API_KEY` | For Repo 5 live LLM smoke (nightly only) |

All secrets must be set via `hyperexecute secrets set` or through CI's secret store — never committed.

## Authoring principles for HyperExecute yaml

### Pin the runner image

Pin `runtime.language` and version. "Latest" is a future flake.

```yaml
runtime:
  language: node
  version: "20"
```

### Cache dependencies

`npm ci` cold is slow. Cache `node_modules` or `~/.cache/ms-playwright`.

```yaml
cacheKey: '{{ checksum "package-lock.json" }}'
cacheDirectories:
  - node_modules
  - ~/.cache/ms-playwright
```

### Discovery commands list tests, not generate them

For auto-split, the discovery command must print one test file or test id per line.

```yaml
testDiscovery:
  type: raw
  mode: dynamic
  command: 'find tests -name "*.spec.ts" -type f'
```

### Concurrency = your plan limit, not "as many as possible"

Set `concurrency` based on your LambdaTest plan. Going higher just queues lanes and gives no speedup.

### Fail fast on infra problems, not on test failures

`failFast: true` only at the matrix/lane level. Tests within a lane should report all failures, not stop at the first one.

## What NOT to do

- Do not run live LLM tests in PR pipelines. Cost spikes. Gate with `@pytest.mark.live` and run nightly only.
- Do not upload `node_modules` as an artifact. Pointless and slow.
- Do not put secrets in the yaml. Use HyperExecute Secrets Vault.
- Do not set concurrency higher than your plan supports.
- Do not skip the discovery command's filter. Running `*.ts` will pick up unrelated files.
- Do not chain `npm install` in the test command. Install in `preDirectives` once, run tests in `testRunnerCommand`.

## Reference files

- `references/execution-modes.md` — matrix vs auto-split decision guide, hybrid patterns.
- `references/ci-integration.md` — GitHub Actions, Jenkins, GitLab snippets.
- `references/troubleshooting.md` — common errors, fixes, and how to read HyperExecute logs.

## Template assets

- `assets/templates/hyperexecute-matrix-ts.yaml` — TS matrix (browser × OS) for Repo 6.
- `assets/templates/hyperexecute-autosplit-ts.yaml` — TS auto-split for API suites (Repos 2, 3, 4).
- `assets/templates/hyperexecute-matrix-py.yaml` — Python matrix for Repo 5 live LLM smoke.
- `assets/templates/hyperexecute-autosplit-py.yaml` — Python auto-split for Repo 5 AI contract.
- `assets/templates/.env.example` — env vars listing.
- `assets/templates/github-actions.yml` — CI snippet for GitHub Actions.
- `assets/templates/run-locally.sh` — local CLI invocation script.
