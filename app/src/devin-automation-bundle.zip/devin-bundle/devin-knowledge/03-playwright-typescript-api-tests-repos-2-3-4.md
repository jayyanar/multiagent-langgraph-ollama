# TypeScript API Tests — Repos 2, 3, 4

Covers:
- Repo 2: Ingestion Pipeline (Java) — REST endpoints, payload contracts, integration with AI Service.
- Repo 3: Prompt Management — CRUD coverage, validation, auth.
- Repo 4: Dashboard Service — API + MongoDB read-back assertions.

## Folder layout

```
ts/tests/api/
├── services/                  # One service object per repo
│   ├── IngestionService.ts
│   ├── PromptService.ts
│   └── DashboardService.ts
├── clients/
│   ├── HttpClient.ts          # Wraps Playwright `request` with auth, base URL, retry
│   └── MongoClient.ts         # Read-only Mongo client for Repo 4 assertions
└── specs/
    ├── ingestion/
    ├── prompts/
    └── dashboard/
```

## Service Object pattern

Mirror the POM pattern but for HTTP. One class per service. Tests call domain methods, not raw HTTP.

```typescript
// services/PromptService.ts
import { APIRequestContext, APIResponse } from '@playwright/test';

export interface PromptPayload {
  name: string;
  template: string;
  tags?: string[];
}

export class PromptService {
  constructor(private readonly request: APIRequestContext, private readonly baseUrl: string) {}

  async create(payload: PromptPayload): Promise<APIResponse> {
    return this.request.post(`${this.baseUrl}/prompts`, { data: payload });
  }

  async get(id: string): Promise<APIResponse> {
    return this.request.get(`${this.baseUrl}/prompts/${id}`);
  }

  async delete(id: string): Promise<APIResponse> {
    return this.request.delete(`${this.baseUrl}/prompts/${id}`);
  }

  async createWithDefaults(overrides: Partial<PromptPayload> = {}): Promise<{ id: string; payload: PromptPayload }> {
    const payload: PromptPayload = {
      name: `prompt-${Date.now()}`,
      template: 'You are a helpful assistant. {{input}}',
      tags: ['test'],
      ...overrides,
    };
    const res = await this.create(payload);
    if (res.status() !== 201) throw new Error(`createWithDefaults failed: ${res.status()}`);
    const body = await res.json();
    return { id: body.id, payload };
  }
}
```

## Test file structure

```typescript
import { test, expect } from '@playwright/test';
import { PromptService } from '../services/PromptService';

test.describe('Prompt Management - CRUD', () => {
  let prompts: PromptService;
  const createdIds: string[] = [];

  test.beforeEach(async ({ request }) => {
    prompts = new PromptService(request, process.env.PROMPT_API_URL!);
  });

  test.afterEach(async () => {
    for (const id of createdIds) {
      await prompts.delete(id);
    }
    createdIds.length = 0;
  });

  test('should create a prompt with valid payload', async () => {
    const res = await prompts.create({ name: 'test-prompt', template: 'Hello {{name}}' });
    expect(res.status()).toBe(201);
    const body = await res.json();
    expect(body.id).toBeDefined();
    expect(body.name).toBe('test-prompt');
    createdIds.push(body.id);
  });

  test('should reject prompt creation when name exceeds 200 characters', async () => {
    const res = await prompts.create({ name: 'x'.repeat(201), template: 'ok' });
    expect(res.status()).toBe(400);
    const body = await res.json();
    expect(body.error).toMatch(/name.*length/i);
  });
});
```

## MongoDB assertions (Repo 4)

Dashboard Service writes aggregated data to MongoDB. After calling the service API, assert what landed in Mongo. This catches silent data loss.

```typescript
import { MongoClient } from 'mongodb';

let mongo: MongoClient;

test.beforeAll(async () => {
  mongo = await MongoClient.connect(process.env.MONGO_URL!);
});

test.afterAll(async () => {
  await mongo.close();
});

test('aggregation writes to dashboard.events collection', async ({ request }) => {
  const dashboard = new DashboardService(request, process.env.DASHBOARD_API_URL!);
  const res = await dashboard.aggregate({ source: 'ingestion', windowMinutes: 5 });
  expect(res.status()).toBe(202);

  // poll Mongo with a sensible timeout, not a hard sleep
  const events = mongo.db('dashboard').collection('events');
  await expect.poll(
    async () => events.countDocuments({ source: 'ingestion' }),
    { timeout: 10_000, intervals: [500, 1000, 2000] }
  ).toBeGreaterThan(0);
});
```

## Contract testing (Repo 2 ↔ Repo 5)

The Ingestion Pipeline calls the AI Service and consumes the response. Test the contract from both sides:

1. **Provider side (Repo 5)**: snapshot the response shape and types — assert each field exists with the right type.
2. **Consumer side (Repo 2)**: replay a recorded AI Service response and verify Ingestion processes it correctly.

Don't assert exact text — assert shape and required fields. See `python-ai-contract-tests.md` for the provider side.

## Auth, secrets, base URLs

Read from env vars. Never hardcode. Document required vars in a header comment of every spec:

```typescript
// Required env vars:
//   PROMPT_API_URL - e.g. https://prompts.dev.example.com
//   PROMPT_API_TOKEN - service account token for the test tenant
```

For multi-env runs, use `playwright.config.ts` projects:

```typescript
projects: [
  { name: 'api-dev', use: { baseURL: process.env.DEV_API_URL } },
  { name: 'api-stage', use: { baseURL: process.env.STAGE_API_URL } },
]
```

## Common pitfalls

- **Reusing IDs across tests**: each test creates its own data. The `afterEach` cleanup teardown matters.
- **Asserting `response.ok()`**: hides the actual status. Use `expect(response.status()).toBe(...)`.
- **Hardcoded timeouts**: use `expect.poll` with intervals.
- **Skipping Mongo verification**: a 202 from the API doesn't mean data landed. Verify the side effect.
- **Coupling tests to Java's stack traces**: assert on the public error contract (status + body shape), not on internal exception strings.
