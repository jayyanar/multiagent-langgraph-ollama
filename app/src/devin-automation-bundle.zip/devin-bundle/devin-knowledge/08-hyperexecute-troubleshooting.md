# HyperExecute Troubleshooting

Common failure modes when running Playwright on HyperExecute, with the actual fix rather than a guess.

## "command not found: playwright"

The runtime image didn't have Playwright installed, or `npm ci` was skipped.

**Fix:** `npm ci` must run in `preDirectives`, not in `testRunnerCommand`. Putting it in the command means each lane reinstalls (slow), and if the cache step expects `node_modules` to exist, it fails.

```yaml
preDirectives:
  commands:
    - npm ci
    - npx playwright install --with-deps chromium firefox webkit
```

## Tests pass locally, fail on HyperExecute with timeouts

Three likely causes, in order of frequency:

1. **Service URL not set in the lane.** Local `.env` doesn't carry over. Add the env vars under `secrets:` in the yaml and reference them in the lane's environment.
2. **Cold start on the dependent service.** Increase `expect.poll` timeouts; add a `beforeAll` health-check that polls a status endpoint until ready.
3. **Different browser version.** Pin Playwright version in `package.json` and match `npx playwright install` to it.

## Auto-split runs every test in every lane

The discovery command isn't producing one path per line, or HyperExecute isn't reading `$test`.

**Fix:** verify the command output:

```bash
find tests -name "*.spec.ts" -type f
```

Should print one path per line. Then in `testRunnerCommand`, use `$test`:

```yaml
testRunnerCommand: 'npx playwright test $test'
```

Without `$test`, every lane runs everything.

## "ECONNRESET" or "socket hang up" to backend

The backend doesn't accept connections from LambdaTest IPs, or is behind a VPN.

**Fix:** add LambdaTest's egress IPs to the backend allowlist, or run tests against a public test environment. For private envs, use HyperExecute Tunnel.

## Traces aren't uploading

The trace file path doesn't match `postDirectives.upload`.

**Fix:** Playwright writes traces to `test-results/<test-name>/trace.zip`. The wildcard pattern must match:

```yaml
postDirectives:
  upload:
    - 'test-results/**'
    - 'playwright-report/**'
```

## Matrix lane silently skipped

You parameterized `$browser` but the project name in `playwright.config.ts` is different.

**Fix:** the project name in `playwright.config.ts` must literally match what the command substitutes. If yaml says `--project=ui-$browser` and browser is `chrome`, the project must be named `ui-chrome`.

## Quota exceeded / lanes queued

You set `concurrency` higher than your plan supports.

**Fix:** check `Settings → Plan` in the LambdaTest UI. Lower `concurrency` to your plan's parallel limit. Lanes don't run faster by being queued.

## "Failed to read hyperexecute.yaml"

Almost always a YAML syntax issue. Run a linter locally:

```bash
yamllint hyperexecute.yaml
```

Common offenders: tabs instead of spaces, unquoted strings starting with `*` or `&`, missing `- ` before list items.

## How to read the HyperExecute log

The CLI prints a per-lane log. The first 30 lines are setup; the actual test output is later. Search for:
- `[runner] Starting test` — the test actually started running.
- `[runner] Test passed/failed` — outcome per test.
- `[upload]` — artifact upload status. Missing uploads means the glob in `postDirectives` didn't match.

For deep failures, download the artifact bundle and inspect the trace via `npx playwright show-trace trace.zip`.

## When to file a HyperExecute support ticket

If you've verified:
- Local run passes.
- Env vars are bound (echo a sentinel value in `preDirectives` to confirm).
- Browser image is installed.
- Network egress is allowed.

…and the lane still fails with no informative log, open a support ticket with the run ID and the yaml. Don't keep iterating yaml changes blindly.
