# Devin Knowledge — 9 Entries to Upload

Each `.md` file in this folder corresponds to one Knowledge entry in Devin.

## How to upload

1. Open Devin → **Settings → Knowledge → New Knowledge**.
2. For each file below, create a new entry using:
   - **Title** — exact text from the "Knowledge Title" column.
   - **Body** — paste the file's contents.
   - **Trigger** — as listed (Always or Keyword-based).

## Entries

| # | Knowledge Title (use this exact text) | File | Trigger |
|---|---------------------------------------|------|---------|
| 1 | `playwright: when and how to author tests` | `01-playwright-when-and-how-to-author-tests.md` | Always |
| 2 | `playwright: TypeScript UI tests (Repo 6)` | `02-playwright-typescript-ui-tests-repo-6.md` | Keyword: `ui, dashboard web, react, repo 6, e2e` |
| 3 | `playwright: TypeScript API tests (Repos 2, 3, 4)` | `03-playwright-typescript-api-tests-repos-2-3-4.md` | Keyword: `api, ingestion, prompt management, dashboard service, repo 2, repo 3, repo 4` |
| 4 | `playwright: Python AI contract tests (Repo 5)` | `04-playwright-python-ai-contract-tests-repo-5.md` | Keyword: `ai service, adk, llm, repo 5, contract` |
| 5 | `hyperexecute: when and how to configure` | `05-hyperexecute-when-and-how-to-configure.md` | Always |
| 6 | `hyperexecute: execution modes` | `06-hyperexecute-execution-modes.md` | Keyword: `matrix, auto-split, hyperexecute` |
| 7 | `hyperexecute: CI integration` | `07-hyperexecute-ci-integration.md` | Keyword: `github actions, jenkins, gitlab, ci, pipeline` |
| 8 | `hyperexecute: troubleshooting` | `08-hyperexecute-troubleshooting.md` | Keyword: `timeout, fail, error, hyperexecute` |
| 9 | `qa-automation repos in scope` | `09-qa-automation-repos-in-scope.md` | Always |

## After uploading

Verify the Playbooks (in `devin-playbooks.md`) reference these titles by their
exact strings. Devin uses literal title matching when a Playbook says
"read Knowledge: `playwright: when and how to author tests`".
