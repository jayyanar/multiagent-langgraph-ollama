# playwright: when and how to author tests


# Playwright Test Author

## What this skill does

This skill produces Playwright test code that drops directly into the team's test framework, following team conventions. It covers three test types across five repos and two languages.

## When the user asks for a test, do this FIRST

1. **Identify the repo** (2, 3, 4, 5, or 6) from the user's prompt. Ask if it's ambiguous.
2. **Identify the test type** (UI, API, or AI/LLM contract). If unclear, ask one short clarifying question — never guess.
3. **Pick the language** from the table below. Language is non-negotiable per repo; don't offer alternatives.
4. **Read the matching reference file** in `references/` before writing any code. Each reference file contains the team's conventions, folder layout, sample structure, and edge cases for that combination.
5. **Generate the test** using the template under `assets/templates/` as the starting point.
6. **Always add** the required imports, fixtures, and the cleanup hook. Tests that don't clean up after themselves break the next run.

## Repo → Test Type → Language Matrix

| Repo | Name | Test Type | Language | Reference File |
|------|------|-----------|----------|----------------|
| Repo 2 | Ingestion Pipeline (Java) | API / integration | TypeScript | `references/typescript-api-tests.md` |
| Repo 3 | Prompt Management | API (CRUD) | TypeScript | `references/typescript-api-tests.md` |
| Repo 4 | Dashboard Service | API + MongoDB assertion | TypeScript | `references/typescript-api-tests.md` |
| Repo 5 | AI Service (Python + Google ADK) | LLM contract + integration | Python | `references/python-ai-contract-tests.md` |
| Repo 6 | Dashboard Web (ReactJS) | UI / E2E | TypeScript | `references/typescript-ui-tests.md` |

The reason TypeScript covers Repos 2, 3, 4, 6: the test framework lives outside the application code. A single TS Playwright project tests Java HTTP services and the React UI, keeping the test tooling unified.

The reason Python covers Repo 5: it already has Python tooling, virtual environments, and CI runners. Adding TS would mean a second runtime for marginal gain — and the AI Service tests rely on patching Python adapters that can only be reached from Python.

## Authoring principles

### Tests describe behavior, not implementation

A test name like `should reject prompt creation when name exceeds 200 characters` tells a reader what the system promises. A name like `test_create_prompt_400` tells them nothing. Always write the behavior in the test name.

### Assertions are specific

`expect(response.status()).toBe(201)` is good. `expect(response.ok()).toBeTruthy()` hides what was expected. Be specific about status codes, payload fields, and counts so failures point at the actual contract.

### Isolation per test

Every test creates its own data and cleans up. Shared fixtures across tests cause order-dependent failures that waste hours to debug. Use `beforeEach`/`fixtures` for setup and `afterEach`/`fixtures` for teardown. For the rare cases where setup is expensive (e.g., spinning up a tenant), use `beforeAll` with explicit comments explaining why.

### Selectors prefer semantics

For UI tests (Repo 6), prefer `getByRole`, `getByLabel`, `getByTestId` (in that order) over CSS selectors. Selectors that break when a designer renames a CSS class are not tests — they're alarms.

### API tests use the service object, not raw `request`

The team has a `services/` layer that wraps each backend. Tests call `prompts.create(...)` rather than `request.post('/prompts', ...)`. This keeps endpoint changes in one place. See `assets/templates/api-service-example.ts`.

### LLM contract tests assert shape, not content

For Repo 5 (AI Service), don't assert on the exact LLM response text — it will drift. Assert on response shape (fields present, types correct), business rules (no profanity, correct prompt template used), and prompt regression (snapshot the prompt-id used). See `references/python-ai-contract-tests.md`.

## Standard outputs

Every test you generate includes:

1. **The test file** itself (`.spec.ts` or `_test.py`).
2. **A short list of any new helpers added** (e.g., "Added `PromptService.createWithDefaults()` to `services/prompts.ts`").
3. **A run command** the user can copy-paste:
   - TS: `npx playwright test path/to/spec.ts --project=chromium`
   - Python: `pytest path/to/test_file.py -v`
4. **A note on test data**: which factory was used, what gets cleaned up, what doesn't.

## Folder conventions (where the test goes)

```
qa-automation/
├── ts/                              # TypeScript Playwright project
│   ├── playwright.config.ts
│   ├── tests/
│   │   ├── ui/                      # Repo 6 - Dashboard Web
│   │   │   ├── pages/               # Page Object Models
│   │   │   └── specs/
│   │   └── api/                     # Repos 2, 3, 4
│   │       ├── services/            # Service objects (one per repo)
│   │       └── specs/
│   ├── fixtures/
│   ├── data/                        # Test data factories
│   └── utils/
└── py/                              # Python Playwright project
    ├── conftest.py
    ├── tests/
    │   └── ai/                      # Repo 5
    ├── fixtures/
    └── data/
```

If the user is working in a single repo, mirror this under `tests/` inside that repo.

## What NOT to do

- Do not write Playwright UI tests for Repo 6 in Python. Use TypeScript.
- Do not write tests that depend on production data. Create what you need; clean it up.
- Do not chain `await` on a single line for steps you'd want to debug separately.
- Do not assert exact LLM output text in Repo 5 tests. Assert shape and policy.
- Do not skip teardown to "make tests faster". A polluted environment is slower in aggregate.
- Do not commit credentials. Use env vars and document them in the test file header.

## Reference files

- `references/typescript-ui-tests.md` — Repo 6 conventions, POM patterns, selectors, visual testing.
- `references/typescript-api-tests.md` — Repos 2, 3, 4 conventions, service objects, MongoDB assertions, contract tests.
- `references/python-ai-contract-tests.md` — Repo 5 conventions, LLM contract shape, prompt regression, mocking strategy.

## Template assets

- `assets/templates/playwright.config.ts` — Base TS config (multi-project: ui, api, contract).
- `assets/templates/conftest.py` — Base Python fixtures and config for Repo 5.
- `assets/templates/ui-test.spec.ts` — UI test starter.
- `assets/templates/api-test.spec.ts` — API test starter.
- `assets/templates/pom-example.ts` — Page Object Model example.
- `assets/templates/api-service-example.ts` — Service object example.
- `assets/templates/ai_contract_test_example.py` — AI/LLM contract test starter.
