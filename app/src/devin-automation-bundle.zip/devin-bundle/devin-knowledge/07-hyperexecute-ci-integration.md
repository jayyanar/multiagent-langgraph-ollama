# HyperExecute CI Integration

This reference covers wiring HyperExecute into the three CIs most commonly used. The pattern is the same everywhere: download the CLI, set secrets, run the yaml.

## GitHub Actions

```yaml
# .github/workflows/playwright-hyperexecute.yml
name: Playwright on HyperExecute

on:
  pull_request:
  schedule:
    - cron: '0 2 * * *'   # nightly regression

jobs:
  hyperexecute:
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v4

      - name: Download HyperExecute CLI
        run: |
          curl -L https://downloads.lambdatest.com/hyperexecute/linux/hyperexecute -o hyperexecute
          chmod +x hyperexecute

      - name: Run HyperExecute
        env:
          LT_USERNAME: ${{ secrets.LT_USERNAME }}
          LT_ACCESS_KEY: ${{ secrets.LT_ACCESS_KEY }}
          BASE_UI_URL: ${{ secrets.BASE_UI_URL }}
          PROMPT_API_URL: ${{ secrets.PROMPT_API_URL }}
          PROMPT_API_TOKEN: ${{ secrets.PROMPT_API_TOKEN }}
        run: |
          ./hyperexecute \
            --user $LT_USERNAME \
            --key $LT_ACCESS_KEY \
            --config hyperexecute.yaml \
            --verbose

      - name: Upload reports
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: hyperexecute-reports
          path: |
            playwright-report/
            reports/
```

**Notes:**
- The nightly run uses the same yaml. If you want a different config for nightly, branch the workflow with two jobs and two yamls.
- Secrets are scoped to the repo — never echo them in logs.

## Jenkins (Declarative)

```groovy
pipeline {
  agent any
  environment {
    LT_USERNAME = credentials('lt-username')
    LT_ACCESS_KEY = credentials('lt-access-key')
    PROMPT_API_TOKEN = credentials('prompt-api-token')
    BASE_UI_URL = 'https://dashboard.dev.example.com'
    PROMPT_API_URL = 'https://prompts.dev.example.com'
  }
  stages {
    stage('Setup CLI') {
      steps {
        sh '''
          curl -L https://downloads.lambdatest.com/hyperexecute/linux/hyperexecute -o hyperexecute
          chmod +x hyperexecute
        '''
      }
    }
    stage('Run HyperExecute') {
      steps {
        sh './hyperexecute --user $LT_USERNAME --key $LT_ACCESS_KEY --config hyperexecute.yaml --verbose'
      }
    }
  }
  post {
    always {
      archiveArtifacts artifacts: 'playwright-report/**, reports/**', allowEmptyArchive: true
      junit 'reports/junit*.xml'
    }
  }
}
```

## GitLab CI

```yaml
# .gitlab-ci.yml
hyperexecute:
  image: ubuntu:22.04
  timeout: 30 minutes
  variables:
    LT_USERNAME: $LT_USERNAME
    LT_ACCESS_KEY: $LT_ACCESS_KEY
    BASE_UI_URL: $BASE_UI_URL
    PROMPT_API_URL: $PROMPT_API_URL
    PROMPT_API_TOKEN: $PROMPT_API_TOKEN
  before_script:
    - apt-get update && apt-get install -y curl
    - curl -L https://downloads.lambdatest.com/hyperexecute/linux/hyperexecute -o hyperexecute
    - chmod +x hyperexecute
  script:
    - ./hyperexecute --user $LT_USERNAME --key $LT_ACCESS_KEY --config hyperexecute.yaml --verbose
  artifacts:
    when: always
    paths:
      - playwright-report/
      - reports/
    reports:
      junit: reports/junit*.xml
```

## Trigger strategy across all 6 repos

| Trigger | Suite | Mode | Concurrency |
|---------|-------|------|-------------|
| PR / MR | Smoke + impacted | Auto-split | 4 |
| Nightly | Full regression | Auto-split + matrix UI | 8 |
| Pre-release | Cross-browser smoke + UI matrix | Matrix | 4 |
| Post-deploy | Sanity (critical journeys) | Auto-split | 2 |

Tag tests with `@smoke`, `@regression`, `@critical` in the test name or use a tag tag system (Playwright `test.describe` titles can carry tags; pytest uses `pytest.mark`). Then filter at the test discovery command:

```yaml
# PR run - only smoke
command: 'npx playwright test --grep @smoke --list | awk "/\\.spec\\.ts/{print \\$0}"'
```

## Octane handoff (future)

The JUnit XML output produced under `reports/` is the integration point to Octane. Once Octane is wired, a follow-up step pushes those XMLs via Octane's REST API or the official plugin. That is out of scope for this skill — it belongs to a future `octane-integration` skill.
