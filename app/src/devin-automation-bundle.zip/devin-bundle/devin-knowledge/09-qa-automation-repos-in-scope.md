# qa-automation repos in scope

This is the canonical list of repos covered by the Playwright + HyperExecute
automation. The two Playbooks (`author-playwright-tests` and
`configure-hyperexecute`) operate on these five repos only.

## Repos in scope

| Repo | Name | Suite Language | Test Type |
|------|------|----------------|-----------|
| Repo 2 | Ingestion Pipeline (Java) | TypeScript | API / integration |
| Repo 3 | Prompt Management | TypeScript | API (CRUD) |
| Repo 4 | Dashboard Service | TypeScript | API + MongoDB read-back assertion |
| Repo 5 | AI Service (Python + Google ADK) | Python | AI/LLM contract |
| Repo 6 | Dashboard Web (ReactJS) | TypeScript | UI / E2E |

## Out of scope

- Repo 1 (Autosys-triggered Python batch job) is explicitly **out of scope** for
  this automation effort. Do not author Playwright tests or HyperExecute configs
  for it under these Playbooks.

## Language choice rationale

- **TypeScript for Repos 2, 3, 4, 6**: a single TS Playwright project tests both
  the Java HTTP services and the React UI. Keeping the test tooling unified
  reduces context-switching cost and consolidates the framework.
- **Python for Repo 5**: the AI Service is Python-native, and contract tests
  rely on patching Python adapters (`ai_service.adapters.llm`,
  `ai_service.adapters.prompts`) that can only be reached from Python.

## Quick repo lookup for prompts

| Repo Number | repo_name (use in Playbook prompts) | suite_language | execution_mode (default) |
|-------------|-------------------------------------|----------------|--------------------------|
| 2 | `ingestion-pipeline` | typescript | autosplit |
| 3 | `prompt-management` | typescript | autosplit |
| 4 | `dashboard-service` | typescript | autosplit |
| 5 | `ai-service` | python | autosplit |
| 6 | `dashboard-web` | typescript | matrix |
