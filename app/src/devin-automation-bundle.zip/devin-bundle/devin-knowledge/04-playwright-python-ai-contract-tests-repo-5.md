# Python AI Service Contract Tests — Repo 5 (Google ADK)

Repo 5 is the AI Service. It receives a request from the Ingestion Pipeline, fetches a prompt from Prompt Management, calls an LLM, and returns the response back to Ingestion.

LLM outputs drift over time. Tests must focus on **what the system promises** — shape, policy, and integration — not on exact response text.

## What AI/LLM tests verify

1. **Response shape contract** — required fields, types, optional vs required, null handling.
2. **Prompt regression** — the right prompt template (by id/version) is used for a given request type.
3. **Policy compliance** — no PII echoed, no banned tokens, language matches request.
4. **Error fallbacks** — when the LLM fails or returns malformed JSON, the service degrades correctly.
5. **Integration with Prompt Management** — when the prompt doesn't exist, the service returns the documented error.
6. **Token / cost guardrails** — input/output token counts are within configured limits.

## Folder layout

```
py/tests/ai/
├── conftest.py             # fixtures for LLM mocking, request factories
├── test_response_shape.py
├── test_prompt_regression.py
├── test_policy.py
├── test_error_fallbacks.py
└── data/
    ├── sample_request.json
    └── snapshots/          # prompt id snapshots
```

## Mocking the LLM

For most tests, replace the LLM call with a deterministic stub. The team uses Google ADK — patch the model client at the ADK adapter boundary, not deep inside the SDK.

```python
# conftest.py
from typing import Any
import pytest

@pytest.fixture
def fake_llm(monkeypatch: pytest.MonkeyPatch) -> dict[str, Any]:
    """Patch the ADK client so tests are deterministic and offline."""
    captured = {"calls": []}

    def fake_invoke(prompt: str, **kwargs: Any) -> dict[str, Any]:
        captured["calls"].append({"prompt": prompt, "kwargs": kwargs})
        return {
            "text": "stubbed response",
            "input_tokens": 42,
            "output_tokens": 10,
        }

    from ai_service.adapters import llm
    monkeypatch.setattr(llm, "invoke", fake_invoke)
    return captured
```

## Shape contract test

```python
import pytest
from ai_service.app import process_request


def test_response_has_required_fields(fake_llm):
    response = process_request({
        "request_id": "req-001",
        "type": "summarize",
        "payload": {"text": "hello world"},
    })

    # required fields
    assert "request_id" in response
    assert "text" in response
    assert "prompt_id" in response
    assert "usage" in response

    # types
    assert isinstance(response["text"], str)
    assert isinstance(response["usage"]["input_tokens"], int)
    assert isinstance(response["usage"]["output_tokens"], int)

    # invariant: request_id round-trips
    assert response["request_id"] == "req-001"
```

## Prompt regression (the prompt-id snapshot)

When a request comes in with `type=summarize`, the service should pick `prompt_id=summarize.v3` (or whatever the current version is). If someone changes that mapping inadvertently, this test fails:

```python
SUMMARIZE_PROMPT_ID = "summarize.v3"  # snapshot — update intentionally when prompt changes

def test_summarize_uses_pinned_prompt_id(fake_llm):
    response = process_request({"request_id": "x", "type": "summarize", "payload": {"text": "..."}})
    assert response["prompt_id"] == SUMMARIZE_PROMPT_ID
```

If a developer changes the prompt mapping on purpose, they update the snapshot in the same PR. That's the point — the test forces the change to be deliberate.

## Policy test

```python
def test_response_does_not_echo_pii(fake_llm, monkeypatch):
    # have the fake LLM echo the input
    from ai_service.adapters import llm
    monkeypatch.setattr(llm, "invoke", lambda prompt, **kw: {"text": prompt, "input_tokens": 1, "output_tokens": 1})

    response = process_request({
        "request_id": "r",
        "type": "summarize",
        "payload": {"text": "My SSN is 123-45-6789"},
    })

    assert "123-45-6789" not in response["text"], "service must redact PII before returning"
```

## Error fallback test

```python
def test_returns_documented_error_when_prompt_missing(monkeypatch, fake_llm):
    from ai_service.adapters import prompts
    monkeypatch.setattr(prompts, "fetch", lambda pid: None)

    response = process_request({"request_id": "r", "type": "unknown_type", "payload": {}})

    assert response["status"] == "error"
    assert response["error"]["code"] == "PROMPT_NOT_FOUND"
```

## Integration tests (small, gated)

For a handful of end-to-end tests that hit a real (cheap) model:

- Mark with `pytest.mark.live` so they only run nightly.
- Use the smallest model available.
- Cap output tokens hard.
- Still assert on **shape and policy** — never exact text.

```python
@pytest.mark.live
def test_live_summarize_returns_text(real_config):
    response = process_request({
        "request_id": "live-1", "type": "summarize",
        "payload": {"text": "The quick brown fox jumps over the lazy dog."},
    })
    assert isinstance(response["text"], str)
    assert len(response["text"]) > 0
    assert response["usage"]["output_tokens"] <= 200
```

## Common pitfalls

- **Asserting exact LLM text**: it will drift. Assert shape, length bounds, and policy.
- **Hitting the live LLM by default**: expensive and flaky. Mock by default, gate live tests.
- **Patching too deep into the SDK**: brittle. Patch at the adapter boundary.
- **Forgetting prompt versioning**: tests must lock the prompt-id used per request type.
- **Ignoring token budgets**: silent cost regressions. Assert on `usage.output_tokens` upper bounds.
- **Missing PII tests**: a single regression here is a real incident. Cover the redaction path.
