# Devin Playbooks — Paste-Ready

This document contains both Playbooks in the exact format Devin's UI expects.
Open **Devin → Settings → Playbooks → New Playbook** twice — once for each.

> Prerequisite: the 9 Knowledge entries in `devin-knowledge/` must already be
> uploaded. The procedures below reference them by exact title.

---

## Playbook A — `author-playwright-tests`

### Name
```
author-playwright-tests
```

### Description
```
Authors Playwright test cases for a target repo. Picks language and patterns
based on repo number. Opens a PR with new tests plus any required helpers.
```

### Parameters

| Name | Type | Required | Allowed values | Default | Example |
|------|------|----------|----------------|---------|---------|
| `repo_name` | string | yes | — | — | `prompt-management` |
| `repo_number` | string | yes | `2`, `3`, `4`, `5`, `6` | — | `3` |
| `test_type` | string | yes | `ui`, `api`, `ai_contract` | — | `api` |
| `feature_area` | string | yes | — | — | `prompt CRUD operations` |

### Procedure

````markdown
# Goal
Add high-quality Playwright tests to `{{repo_name}}` (Repo {{repo_number}}) covering `{{feature_area}}`.

# Steps

## 1. Load conventions
Read these Knowledge entries:
- `playwright: when and how to author tests`
- `qa-automation repos in scope`

Based on `{{test_type}}`, also read:
- if `ui` → `playwright: TypeScript UI tests (Repo 6)`
- if `api` → `playwright: TypeScript API tests (Repos 2, 3, 4)`
- if `ai_contract` → `playwright: Python AI contract tests (Repo 5)`

## 2. Clone repos
- Clone `{{repo_name}}`.
- Also clone `qa-automation` for the templates under `skills/playwright-test-author/assets/templates/`.

## 3. Inspect existing tests
- Find the existing test folder in `{{repo_name}}` (commonly `tests/`, `__tests__/`, `e2e/`, or a top-level `qa/`).
- Read 1-2 existing test files to match style. If there are none, follow the folder layout in the SKILL.md.

## 4. Propose test cases (CHECKPOINT)
List 3-5 highest-value test cases for `{{feature_area}}`. Each case must include:
- The behavior under test, in user-visible terms.
- The expected status / assertions.
- Any setup data and teardown needed.

**STOP and post the list to the session for human approval before continuing.**

## 5. Generate tests
After approval:
- Copy the matching template from `qa-automation/skills/playwright-test-author/assets/templates/` into the target test folder.
- Adapt to the proposed test cases.
- Add or extend the Page Object Model (UI) or Service Object (API) — do not inline locators or raw `request.post`.
- For Repo 5 (AI contract): mock the LLM at the adapter boundary; assert on shape and policy, NOT on response text.
- For Repo 4 (Dashboard Service): include at least one Mongo read-back assertion using `expect.poll`.

## 6. Run locally
Run the new tests inside the repo's dev container or local environment.
- TypeScript: `npx playwright test path/to/spec.ts --project=<project>`
- Python: `pytest path/to/test_file.py -v`

Iterate until green.

## 7. Open a PR
Title: `test: {{test_type}} coverage for {{feature_area}} (Repo {{repo_number}})`

PR description must include:
- Files added/modified
- Helpers introduced (POMs, service objects, fixtures)
- Local run output (pass count, duration)
- Required env vars (listed; no values)
- Cleanup behavior (what gets created and removed per test)

## 8. Final summary
Post a one-paragraph summary in the Devin session confirming PR URL, files changed, and next recommended test area.
````

---

## Playbook B — `configure-hyperexecute`

### Name
```
configure-hyperexecute
```

### Description
```
Generates a hyperexecute.yaml + CI workflow for a target repo and opens a PR.
Validates locally against LambdaTest before opening the PR.
```

### Parameters

| Name | Type | Required | Allowed values | Default | Example |
|------|------|----------|----------------|---------|---------|
| `repo_name` | string | yes | — | — | `prompt-management` |
| `repo_number` | string | yes | `2`, `3`, `4`, `5`, `6` | — | `3` |
| `suite_language` | string | yes | `typescript`, `python` | — | `typescript` |
| `execution_mode` | string | yes | `autosplit`, `matrix` | — | `autosplit` |
| `target_concurrency` | number | no | 1-8 | `4` | `4` |

### Procedure

````markdown
# Goal
Wire `{{repo_name}}` (Repo {{repo_number}}) into HyperExecute with `{{execution_mode}}` mode on `{{suite_language}}`, concurrency = `{{target_concurrency}}`.

# Steps

## 1. Load conventions
Read these Knowledge entries:
- `hyperexecute: when and how to configure`
- `hyperexecute: execution modes`
- `hyperexecute: CI integration`
- `qa-automation repos in scope`

## 2. Clone repos
- Clone `{{repo_name}}`.
- Also clone `qa-automation` for the yaml templates under `skills/hyperexecute-runner/assets/templates/`.

## 3. Pick template
- `suite_language=typescript`, `execution_mode=autosplit` → `hyperexecute-autosplit-ts.yaml`
- `suite_language=typescript`, `execution_mode=matrix` → `hyperexecute-matrix-ts.yaml`
- `suite_language=python`, `execution_mode=autosplit` → `hyperexecute-autosplit-py.yaml`
- `suite_language=python`, `execution_mode=matrix` → `hyperexecute-matrix-py.yaml` (Repo 5 live-LLM smoke only; confirm with user before using)

## 4. Adapt the template
- Copy the chosen template into `{{repo_name}}/hyperexecute.yaml`.
- Update:
  - `testDiscovery.command` to point at this repo's test folder.
  - `concurrency` to `{{target_concurrency}}`.
  - `env:` block to list only this repo's required env vars (drop the rest).
- Validate yaml with `yamllint hyperexecute.yaml` (install if missing).

## 5. Add the CI workflow
- Copy `qa-automation/skills/hyperexecute-runner/assets/templates/github-actions.yml` into `{{repo_name}}/.github/workflows/playwright-hyperexecute.yml`.
- Remove jobs that don't apply to this repo (keep only the one matching `{{execution_mode}}` and `{{suite_language}}`).
- Update env-var bindings to match this repo.

## 6. Document required secrets (CHECKPOINT)
Produce a markdown checklist of every secret the workflow expects:
- `LT_USERNAME`, `LT_ACCESS_KEY`
- All service URLs and API tokens referenced
- Any additional credentials

**STOP and post the checklist to the session. Wait for the human to confirm secrets are added to GitHub Secrets (or equivalent) before continuing.**

## 7. Validate locally
After human confirms secrets:
- Download HyperExecute CLI: `curl -L https://downloads.lambdatest.com/hyperexecute/linux/hyperexecute -o hyperexecute && chmod +x hyperexecute`
- Run: `./hyperexecute --user $LT_USERNAME --key $LT_ACCESS_KEY --config hyperexecute.yaml --verbose`
- If red, read `hyperexecute: troubleshooting`, fix, re-run. Do not skip this gate.

## 8. Open the PR
Title: `ci: run Playwright on HyperExecute (Repo {{repo_number}})`

PR description must include:
- Mode chosen and why (matrix vs autosplit)
- Lane count and expected wall-clock time
- Link to the successful local HyperExecute run
- Updated README section "Running tests on HyperExecute"
- The secrets checklist

## 9. Watch the first CI run
After the PR merges (or on the PR itself if branches run CI):
- Confirm the workflow runs green on HyperExecute.
- Verify artifacts (Playwright report, traces, JUnit XML) are uploaded.
- Post the run URL and summary to the session.
````

---

## Quick reference — per-repo invocation prompts

Once both Playbooks exist, run them per repo in this order. **Run authoring first, get PR merged, then HyperExecute.**

### Repo 3 — Prompt Management

```
@author-playwright-tests
repo_name: prompt-management
repo_number: 3
test_type: api
feature_area: prompt CRUD operations (create, read, update, delete) including validation of required fields and 400 responses for malformed payloads
```

```
@configure-hyperexecute
repo_name: prompt-management
repo_number: 3
suite_language: typescript
execution_mode: autosplit
target_concurrency: 4
```

### Repo 4 — Dashboard Service

```
@author-playwright-tests
repo_name: dashboard-service
repo_number: 4
test_type: api
feature_area: data aggregation endpoint, including Mongo read-back verification that aggregated rows landed in the `dashboard.events` collection within 10 seconds
```

```
@configure-hyperexecute
repo_name: dashboard-service
repo_number: 4
suite_language: typescript
execution_mode: autosplit
target_concurrency: 4
```

### Repo 2 — Ingestion Pipeline

```
@author-playwright-tests
repo_name: ingestion-pipeline
repo_number: 2
test_type: api
feature_area: ingestion endpoint contract — happy path payload acceptance, malformed payload rejection with 400, and contract assertions on the shape of the AI Service response that ingestion consumes
```

```
@configure-hyperexecute
repo_name: ingestion-pipeline
repo_number: 2
suite_language: typescript
execution_mode: autosplit
target_concurrency: 4
```

### Repo 6 — Dashboard Web

```
@author-playwright-tests
repo_name: dashboard-web
repo_number: 6
test_type: ui
feature_area: dashboard load, date-range filtering, and results table rendering. Include one accessibility check (no a11y violations on the dashboard page).
```

```
@configure-hyperexecute
repo_name: dashboard-web
repo_number: 6
suite_language: typescript
execution_mode: matrix
target_concurrency: 3
```

### Repo 5 — AI Service

```
@author-playwright-tests
repo_name: ai-service
repo_number: 5
test_type: ai_contract
feature_area: summarize endpoint — response shape contract, prompt-id regression snapshot, PII redaction policy, and the documented error envelope when the requested prompt is missing
```

```
@configure-hyperexecute
repo_name: ai-service
repo_number: 5
suite_language: python
execution_mode: autosplit
target_concurrency: 4
```

Optional, nightly only — add later for live-LLM smoke:

```
@configure-hyperexecute
repo_name: ai-service
repo_number: 5
suite_language: python
execution_mode: matrix
target_concurrency: 1
```
