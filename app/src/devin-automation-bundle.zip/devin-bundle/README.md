# Devin Onboarding & Run Guide — Playwright Test Automation

This guide takes you from "two `.skill` files in a folder" to "Devin is generating Playwright tests and HyperExecute configs across 5 repos, one repo at a time." Every step has a copy-paste prompt.

## Scope

**5 repos in scope** (Repo 1 / Autosys batch job is excluded):

| Repo | Name | Tech | Test Type | Language |
|------|------|------|-----------|----------|
| Repo 2 | Ingestion Pipeline | Java | API / integration | TypeScript |
| Repo 3 | Prompt Management | Service (CRUD) | API | TypeScript |
| Repo 4 | Dashboard Service | Backend + MongoDB | API + Mongo assertions | TypeScript |
| Repo 5 | AI Service | Python + Google ADK | AI/LLM contract | Python |
| Repo 6 | Dashboard Web | ReactJS | UI / E2E | TypeScript |

**Tools used end-to-end:**
- **Devin** — orchestrates the work via Playbooks and Knowledge
- **Playwright** — the test framework (TypeScript + Python)
- **HyperExecute (LambdaTest)** — distributed test execution
- **GitHub Actions** (or Jenkins/GitLab) — CI orchestration

## What's in this delivery

| File | Purpose |
|------|---------|
| `playwright-test-author.skill` | Test authoring skill — packaged for install |
| `hyperexecute-runner.skill` | HyperExecute config & execution skill — packaged for install |
| `playwright-test-author/` | Unpacked skill folder (use this to extract Knowledge entries for Devin) |
| `hyperexecute-runner/` | Unpacked skill folder (same purpose) |
| `README.md` | This document |

---

# PART 1 — One-Time Setup (~90 min total)

## Step 1.1 — Stage a shared `qa-automation` repo (~20 min)

Devin Playbooks reference templates by path, so the templates need to live in a real repo Devin can clone.

1. Create a new repo named **`qa-automation`** in your VCS (GitHub/GitLab/Bitbucket).
2. Inside it, create this structure:
   ```
   qa-automation/
   ├── README.md
   ├── skills/
   │   ├── playwright-test-author/   ← copy contents of the unpacked skill folder
   │   └── hyperexecute-runner/      ← copy contents of the unpacked skill folder
   ├── ts/                            ← TypeScript Playwright project root (empty for now)
   └── py/                            ← Python pytest project root (empty for now)
   ```
3. Copy the contents of both unpacked skill folders into `qa-automation/skills/`.
4. Commit and push.
5. In Devin: **Settings → Repositories → Add Repo** → grant access to `qa-automation`.

Add a top-level `qa-automation/devin.md` so Devin knows the repo's purpose:

```markdown
# qa-automation

This repo holds the shared Playwright framework, HyperExecute configs, and skill
templates used by the test authoring and HyperExecute Playbooks. Two Playbooks
reference paths in this repo:

- `author-playwright-tests` reads templates from
  `skills/playwright-test-author/assets/templates/`
- `configure-hyperexecute` reads yaml templates from
  `skills/hyperexecute-runner/assets/templates/`

Do not move these paths without also updating the Playbooks.
```

## Step 1.2 — Upload Knowledge entries to Devin (~30 min)

Devin Knowledge UI: **Settings → Knowledge → New Knowledge**.

Create **9 entries**, copying the content from the markdown files in the unpacked skill folders. Use the **exact titles** in the table — the Playbooks reference them by name.

| # | Knowledge Title | Source File | Trigger Setting |
|---|----------------|-------------|----------------|
| 1 | `playwright: when and how to author tests` | `playwright-test-author/SKILL.md` | Always |
| 2 | `playwright: TypeScript UI tests (Repo 6)` | `playwright-test-author/references/typescript-ui-tests.md` | Keyword: ui, dashboard web, react, repo 6, e2e |
| 3 | `playwright: TypeScript API tests (Repos 2, 3, 4)` | `playwright-test-author/references/typescript-api-tests.md` | Keyword: api, ingestion, prompt management, dashboard service, repo 2, repo 3, repo 4 |
| 4 | `playwright: Python AI contract tests (Repo 5)` | `playwright-test-author/references/python-ai-contract-tests.md` | Keyword: ai service, adk, llm, repo 5, contract |
| 5 | `hyperexecute: when and how to configure` | `hyperexecute-runner/SKILL.md` | Always |
| 6 | `hyperexecute: execution modes` | `hyperexecute-runner/references/execution-modes.md` | Keyword: matrix, auto-split, hyperexecute |
| 7 | `hyperexecute: CI integration` | `hyperexecute-runner/references/ci-integration.md` | Keyword: github actions, jenkins, gitlab, ci, pipeline |
| 8 | `hyperexecute: troubleshooting` | `hyperexecute-runner/references/troubleshooting.md` | Keyword: timeout, fail, error, hyperexecute |
| 9 | `qa-automation repos in scope` | (paste the table below) | Always |

**For Knowledge #9**, paste this text:

```markdown
# Repos in scope for test automation

| Repo | Name | Suite Language | Test Type |
|------|------|----------------|-----------|
| Repo 2 | Ingestion Pipeline (Java) | TypeScript | API |
| Repo 3 | Prompt Management | TypeScript | API (CRUD) |
| Repo 4 | Dashboard Service | TypeScript | API + Mongo assertion |
| Repo 5 | AI Service (Python + Google ADK) | Python | AI/LLM contract |
| Repo 6 | Dashboard Web (ReactJS) | TypeScript | UI / E2E |

Repo 1 (Autosys batch job) is explicitly out of scope.
```

## Step 1.3 — Create the two Playbooks (~30 min)

Devin Playbooks UI: **Settings → Playbooks → New Playbook**.

### Playbook A — `author-playwright-tests`

**Name:** `author-playwright-tests`

**Description:**
```
Authors Playwright test cases for a target repo. Picks language and patterns
based on repo number. Opens a PR with new tests plus any required helpers.
```

**Parameters:**
- `repo_name` (string, required) — e.g. `prompt-management`
- `repo_number` (string, required, values: 2|3|4|5|6)
- `test_type` (string, required, values: ui|api|ai_contract)
- `feature_area` (string, required) — e.g. `prompt CRUD operations`

**Procedure (paste as markdown):**

```markdown
# Goal
Add high-quality Playwright tests to `{{repo_name}}` (Repo {{repo_number}}) covering `{{feature_area}}`.

# Steps

## 1. Load conventions
Read these Knowledge entries:
- `playwright: when and how to author tests`
- `qa-automation repos in scope`

Based on `{{test_type}}`, also read:
- if `ui` → `playwright: TypeScript UI tests (Repo 6)`
- if `api` → `playwright: TypeScript API tests (Repos 2, 3, 4)`
- if `ai_contract` → `playwright: Python AI contract tests (Repo 5)`

## 2. Clone repos
- Clone `{{repo_name}}`.
- Also clone `qa-automation` for the templates under `skills/playwright-test-author/assets/templates/`.

## 3. Inspect existing tests
- Find the existing test folder in `{{repo_name}}` (commonly `tests/`, `__tests__/`, `e2e/`, or a top-level `qa/`).
- Read 1-2 existing test files to match style. If there are none, follow the folder layout in the SKILL.md.

## 4. Propose test cases (CHECKPOINT)
List 3-5 highest-value test cases for `{{feature_area}}`. Each case must include:
- The behavior under test, in user-visible terms.
- The expected status / assertions.
- Any setup data and teardown needed.

**STOP and post the list to the session for human approval before continuing.**

## 5. Generate tests
After approval:
- Copy the matching template from `qa-automation/skills/playwright-test-author/assets/templates/` into the target test folder.
- Adapt to the proposed test cases.
- Add or extend the Page Object Model (UI) or Service Object (API) — do not inline locators or raw `request.post`.
- For Repo 5 (AI contract): mock the LLM at the adapter boundary; assert on shape and policy, NOT on response text.
- For Repo 4 (Dashboard Service): include at least one Mongo read-back assertion using `expect.poll`.

## 6. Run locally
Run the new tests inside the repo's dev container or local environment.
- TypeScript: `npx playwright test path/to/spec.ts --project=<project>`
- Python: `pytest path/to/test_file.py -v`

Iterate until green.

## 7. Open a PR
Title: `test: {{test_type}} coverage for {{feature_area}} (Repo {{repo_number}})`

PR description must include:
- Files added/modified
- Helpers introduced (POMs, service objects, fixtures)
- Local run output (pass count, duration)
- Required env vars (listed; no values)
- Cleanup behavior (what gets created and removed per test)

## 8. Final summary
Post a one-paragraph summary in the Devin session confirming PR URL, files changed, and next recommended test area.
```

### Playbook B — `configure-hyperexecute`

**Name:** `configure-hyperexecute`

**Description:**
```
Generates a hyperexecute.yaml + CI workflow for a target repo and opens a PR.
Validates locally against LambdaTest before opening the PR.
```

**Parameters:**
- `repo_name` (string, required)
- `repo_number` (string, required, values: 2|3|4|5|6)
- `suite_language` (string, required, values: typescript|python)
- `execution_mode` (string, required, values: autosplit|matrix)
- `target_concurrency` (number, default: 4)

**Procedure (paste as markdown):**

```markdown
# Goal
Wire `{{repo_name}}` (Repo {{repo_number}}) into HyperExecute with `{{execution_mode}}` mode on `{{suite_language}}`, concurrency = `{{target_concurrency}}`.

# Steps

## 1. Load conventions
Read these Knowledge entries:
- `hyperexecute: when and how to configure`
- `hyperexecute: execution modes`
- `hyperexecute: CI integration`
- `qa-automation repos in scope`

## 2. Clone repos
- Clone `{{repo_name}}`.
- Also clone `qa-automation` for the yaml templates under `skills/hyperexecute-runner/assets/templates/`.

## 3. Pick template
- `suite_language=typescript`, `execution_mode=autosplit` → `hyperexecute-autosplit-ts.yaml`
- `suite_language=typescript`, `execution_mode=matrix` → `hyperexecute-matrix-ts.yaml`
- `suite_language=python`, `execution_mode=autosplit` → `hyperexecute-autosplit-py.yaml`
- `suite_language=python`, `execution_mode=matrix` → `hyperexecute-matrix-py.yaml` (Repo 5 live-LLM smoke only; confirm with user before using)

## 4. Adapt the template
- Copy the chosen template into `{{repo_name}}/hyperexecute.yaml`.
- Update:
  - `testDiscovery.command` to point at this repo's test folder.
  - `concurrency` to `{{target_concurrency}}`.
  - `env:` block to list only this repo's required env vars (drop the rest).
- Validate yaml with `yamllint hyperexecute.yaml` (install if missing).

## 5. Add the CI workflow
- Copy `qa-automation/skills/hyperexecute-runner/assets/templates/github-actions.yml` into `{{repo_name}}/.github/workflows/playwright-hyperexecute.yml`.
- Remove jobs that don't apply to this repo (keep only the one matching `{{execution_mode}}` and `{{suite_language}}`).
- Update env-var bindings to match this repo.

## 6. Document required secrets (CHECKPOINT)
Produce a markdown checklist of every secret the workflow expects:
- `LT_USERNAME`, `LT_ACCESS_KEY`
- All service URLs and API tokens referenced
- Any additional credentials

**STOP and post the checklist to the session. Wait for the human to confirm secrets are added to GitHub Secrets (or equivalent) before continuing.**

## 7. Validate locally
After human confirms secrets:
- Download HyperExecute CLI: `curl -L https://downloads.lambdatest.com/hyperexecute/linux/hyperexecute -o hyperexecute && chmod +x hyperexecute`
- Run: `./hyperexecute --user $LT_USERNAME --key $LT_ACCESS_KEY --config hyperexecute.yaml --verbose`
- If red, read `hyperexecute: troubleshooting`, fix, re-run. Do not skip this gate.

## 8. Open the PR
Title: `ci: run Playwright on HyperExecute (Repo {{repo_number}})`

PR description must include:
- Mode chosen and why (matrix vs autosplit)
- Lane count and expected wall-clock time
- Link to the successful local HyperExecute run
- Updated README section "Running tests on HyperExecute"
- The secrets checklist

## 9. Watch the first CI run
After the PR merges (or on the PR itself if branches run CI):
- Confirm the workflow runs green on HyperExecute.
- Verify artifacts (Playwright report, traces, JUnit XML) are uploaded.
- Post the run URL and summary to the session.
```

---

# PART 2 — Per-Repo Run Plan

Run repos **sequentially**, smallest first. Each repo needs **two Devin sessions** — one per Playbook. Wait for quality gates between repos.

## Run order

| Order | Repo | Why this order |
|-------|------|---------------|
| 1 | Repo 3 — Prompt Management | Smallest API surface — fastest loop to validate Playbooks |
| 2 | Repo 4 — Dashboard Service | API + Mongo, tests the assertion patterns |
| 3 | Repo 2 — Ingestion Pipeline | Java backend, integrates with AI Service |
| 4 | Repo 6 — Dashboard Web | UI tests, cross-browser matrix |
| 5 | Repo 5 — AI Service | Special handling (LLM mocking, contract tests) |

## Repo-by-repo prompts

For each repo, run the **Authoring session first**, get the PR merged, then run the **HyperExecute session**.

### Repo 3 — Prompt Management

**Session 1 — Authoring.** New Devin session, target = `prompt-management` repo:

```
@author-playwright-tests

repo_name: prompt-management
repo_number: 3
test_type: api
feature_area: prompt CRUD operations (create, read, update, delete) including validation of required fields and 400 responses for malformed payloads
```

**Session 2 — HyperExecute.** New Devin session, target = `prompt-management` repo:

```
@configure-hyperexecute

repo_name: prompt-management
repo_number: 3
suite_language: typescript
execution_mode: autosplit
target_concurrency: 4
```

### Repo 4 — Dashboard Service

**Session 1 — Authoring:**

```
@author-playwright-tests

repo_name: dashboard-service
repo_number: 4
test_type: api
feature_area: data aggregation endpoint, including Mongo read-back verification that aggregated rows landed in the `dashboard.events` collection within 10 seconds
```

**Session 2 — HyperExecute:**

```
@configure-hyperexecute

repo_name: dashboard-service
repo_number: 4
suite_language: typescript
execution_mode: autosplit
target_concurrency: 4
```

### Repo 2 — Ingestion Pipeline

**Session 1 — Authoring:**

```
@author-playwright-tests

repo_name: ingestion-pipeline
repo_number: 2
test_type: api
feature_area: ingestion endpoint contract — happy path payload acceptance, malformed payload rejection with 400, and contract assertions on the shape of the AI Service response that ingestion consumes
```

**Session 2 — HyperExecute:**

```
@configure-hyperexecute

repo_name: ingestion-pipeline
repo_number: 2
suite_language: typescript
execution_mode: autosplit
target_concurrency: 4
```

### Repo 6 — Dashboard Web

**Session 1 — Authoring:**

```
@author-playwright-tests

repo_name: dashboard-web
repo_number: 6
test_type: ui
feature_area: dashboard load, date-range filtering, and results table rendering. Include one accessibility check (no a11y violations on the dashboard page).
```

**Session 2 — HyperExecute (matrix for cross-browser):**

```
@configure-hyperexecute

repo_name: dashboard-web
repo_number: 6
suite_language: typescript
execution_mode: matrix
target_concurrency: 3
```

### Repo 5 — AI Service

**Session 1 — Authoring:**

```
@author-playwright-tests

repo_name: ai-service
repo_number: 5
test_type: ai_contract
feature_area: summarize endpoint — response shape contract, prompt-id regression snapshot, PII redaction policy, and the documented error envelope when the requested prompt is missing
```

**Session 2 — HyperExecute (autosplit for mocked contract):**

```
@configure-hyperexecute

repo_name: ai-service
repo_number: 5
suite_language: python
execution_mode: autosplit
target_concurrency: 4
```

*(Optional, nightly only — add later)* a second HyperExecute config for the live-LLM smoke:
```
@configure-hyperexecute

repo_name: ai-service
repo_number: 5
suite_language: python
execution_mode: matrix
target_concurrency: 1
```

---

# PART 3 — Quality Gates Between Repos

Do not move to repo N+1 until repo N has cleared every gate:

| Gate | How to verify |
|------|---------------|
| Authoring PR merged to `main` | GitHub/GitLab |
| HyperExecute PR merged to `main` | GitHub/GitLab |
| At least one PR-triggered HyperExecute run green | LambdaTest dashboard or CI run page |
| Artifacts downloadable | Playwright HTML report + traces from HyperExecute artifact bundle |
| Cleanup verified | Run the auth test twice; confirm no leftover test data in the target service |
| Nightly cron entry exists | GitHub Actions schedule or Jenkins job exists for `0 2 * * *` |

If a gate fails, **fix in repo N before starting repo N+1** — the patterns propagate, and you want them right.

---

# PART 4 — After All 5 Repos

| # | Activity | Notes |
|---|----------|-------|
| 1 | Add an **Octane integration Playbook** | Pushes the JUnit XML output from HyperExecute to Octane and creates defects on failure. I can build this skill on request. |
| 2 | Schedule a **monthly skill-drift review** | New Devin session that reads each Knowledge entry, runs a sample test on a repo, and reports stale advice. |
| 3 | Add a **flaky-test triage Playbook** | Nightly job that scans HyperExecute retry counts, opens issues on tests with >2% flake rate. |
| 4 | Promote `qa-automation` to a versioned internal package | So changes to skill templates ripple through repos via a controlled bump. |

---

# Appendix A — Devin Onboarding Tips

| Tip | Why |
|-----|-----|
| Run sessions in series, not parallel, for the first pass | Devin learns from each repo; patterns crystallize. Parallel = wasted iteration. |
| Keep the first feature area small (1 endpoint, 1 page) | Faster feedback on whether the Playbook is correctly tuned. |
| Add a `devin.md` per target repo | Document the dev-loop commands and where tests go. Saves Devin from guessing. |
| Tag Knowledge entries consistently | Easier for Devin to retrieve the right one. |
| After repo 1, do a 10-min retro before repo 2 | If the Playbook needed manual nudging, update the procedure — don't keep nudging. |

# Appendix B — Required Devin Permissions / Secrets

Devin needs:
- Read/write access to each of the 5 target repos
- Read access to `qa-automation`
- Org-level secrets for: `LT_USERNAME`, `LT_ACCESS_KEY`, service URLs, service tokens

Add these in **Devin → Settings → Secrets** so they're available in every session, or scope to specific repos as your security policy allows.

# Appendix C — How to update the skills later

The skills are version-controlled in `qa-automation/skills/`. To make a change:

1. Edit the relevant `SKILL.md` or reference file in `qa-automation`.
2. Open a PR. Get a review from someone who has run a test session recently.
3. After merge, re-upload the changed Knowledge entries in Devin (it doesn't auto-sync from VCS).
4. Optionally re-package: `python -m scripts.package_skill skills/playwright-test-author` and store the `.skill` files in `qa-automation/releases/` for Claude Code users.

---

**You're ready.** Start with Repo 3 — Prompt Management, Session 1. Good luck.
