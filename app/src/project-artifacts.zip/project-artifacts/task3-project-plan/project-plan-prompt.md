# Task 3 - Prompt: Create 2-Week Integration Project Plan

## For: Project Manager / Tech Lead

## Prerequisites
- `information.md` from ALL 5 repos (Task 1 complete)
- `integration-gaps.md` from ALL 5 repos (Task 2 complete)

## How to Use This Prompt

1. Collect all `information.md` and `integration-gaps.md` files from all 5 repos
2. Open Claude Code in any workspace
3. Copy the prompt below and run it with all files provided
4. Review and share the project plan with the team

---

## Prompt

```
I am the Project Manager / Tech Lead for a 5-person team. We have 2 weeks (10 working days) to complete the integration of our 5-microservices system. Each team member owns one repository. I have the `information.md` and `integration-gaps.md` from all 5 services.

## Team
- **Member 1**: Dashboard Web (ReactJS)
- **Member 2**: Dashboard Service (Java)
- **Member 3**: Prompt Management (Java)
- **Member 4**: QA-AI Service (Python - Google ADK + Gemini Pro)
- **Member 5**: Ingestion Service (Node.js - CRITICAL)

## System Architecture
- Event-driven architecture using Kafka
- MongoDB for data persistence
- Microservices communicating via REST APIs and Kafka topics

## Input Files
- Dashboard Web information.md: [paste or reference]
- Dashboard Web integration-gaps.md: [paste or reference]
- Dashboard Service information.md: [paste or reference]
- Dashboard Service integration-gaps.md: [paste or reference]
- Prompt Management information.md: [paste or reference]
- Prompt Management integration-gaps.md: [paste or reference]
- QA-AI Service information.md: [paste or reference]
- QA-AI Service integration-gaps.md: [paste or reference]
- Ingestion Service information.md: [paste or reference]
- Ingestion Service integration-gaps.md: [paste or reference]

---

Generate a comprehensive `project-plan.md` with the following:

## 1. Executive Summary
- Total number of integration gaps across all services
- Number of critical/blocking gaps
- Risk assessment for 2-week timeline
- Key dependencies and critical path

## 2. Integration Dependency Map
Create a dependency graph showing which integrations must be completed before others:

```
Ingestion Service (Kafka output)
    -> QA-AI Service (consume + process)
        -> Dashboard Service (normalize)
            -> Dashboard Web (display)

Prompt Management (CRUD API + Kafka events)
    -> QA-AI Service (fetch prompts)
    -> Dashboard Service (proxy CRUD)
        -> Dashboard Web (manage prompts)
```

Identify the CRITICAL PATH (longest dependency chain that determines minimum time).

## 3. Shared Contracts (Must Agree FIRST - Day 1)
List all shared contracts that teams must agree on before coding:
- Kafka topic names (exact strings)
- Kafka message schemas (JSON schemas)
- REST API contracts (OpenAPI/Swagger)
- MongoDB collection schemas
- Authentication token format
- Error response format
- Pagination format

Create a table:
| Contract | Between Services | Format | Owner (Who Defines) | Status |
|---|---|---|---|---|

## 4. Sprint Plan: Week 1 (Days 1-5)

### Day 1 (Monday) - Contract Agreement Day
- Morning standup: Review all integration-gaps.md together
- Tasks for each team member:
  | Member | Task | Deliverable | Dependencies | Done Criteria |
  |---|---|---|---|---|
- End of day: ALL shared contracts finalized and documented

### Day 2 - Foundation Day
- Per-member task breakdown:
  | Member | Task | Deliverable | Dependencies | Done Criteria |
  |---|---|---|---|---|
- Focus: Infrastructure setup (Kafka topics, MongoDB collections, API stubs)

### Day 3 - Core Integration Day 1
  | Member | Task | Deliverable | Dependencies | Done Criteria |
  |---|---|---|---|---|
- Focus: Ingestion -> QA-AI pipeline (most critical)
- Focus: Prompt Management API completion

### Day 4 - Core Integration Day 2
  | Member | Task | Deliverable | Dependencies | Done Criteria |
  |---|---|---|---|---|
- Focus: QA-AI -> Dashboard Service pipeline
- Focus: Dashboard Service -> Web API alignment

### Day 5 (Friday) - Week 1 Integration Test
  | Member | Task | Deliverable | Dependencies | Done Criteria |
  |---|---|---|---|---|
- Focus: End-to-end smoke test of critical path
- Week 1 retrospective: What's blocked? What needs adjustment?

## 5. Sprint Plan: Week 2 (Days 6-10)

### Day 6 (Monday) - Address Week 1 Gaps
  | Member | Task | Deliverable | Dependencies | Done Criteria |
  |---|---|---|---|---|

### Day 7 - Feature Completion
  | Member | Task | Deliverable | Dependencies | Done Criteria |
  |---|---|---|---|---|

### Day 8 - Integration Testing
  | Member | Task | Deliverable | Dependencies | Done Criteria |
  |---|---|---|---|---|

### Day 9 - Bug Fixing & Stabilization
  | Member | Task | Deliverable | Dependencies | Done Criteria |
  |---|---|---|---|---|

### Day 10 (Friday) - Final Validation & Demo
  | Member | Task | Deliverable | Dependencies | Done Criteria |
  |---|---|---|---|---|

## 6. Per-Member Task Backlog (Prioritized)

### Member 1 - Dashboard Web (ReactJS)
| Priority | Task | Depends On | Day | Effort (hours) | Status |
|---|---|---|---|---|---|
| P0 | ... | ... | ... | ... | Not Started |

### Member 2 - Dashboard Service (Java)
| Priority | Task | Depends On | Day | Effort (hours) | Status |
|---|---|---|---|---|---|

### Member 3 - Prompt Management (Java)
| Priority | Task | Depends On | Day | Effort (hours) | Status |
|---|---|---|---|---|---|

### Member 4 - QA-AI Service (Python)
| Priority | Task | Depends On | Day | Effort (hours) | Status |
|---|---|---|---|---|---|

### Member 5 - Ingestion Service (Node.js)
| Priority | Task | Depends On | Day | Effort (hours) | Status |
|---|---|---|---|---|---|

## 7. Critical Path Analysis
- Identify the longest chain of dependent tasks
- Calculate minimum time to complete
- Identify tasks that can be parallelized
- Flag any risks where 2-week timeline is tight

## 8. Risk Register
| Risk | Probability | Impact | Mitigation | Owner |
|---|---|---|---|---|

Include risks like:
- Kafka schema disagreements taking too long
- Ingestion Service datasource connectors not ready
- Google ADK/Gemini Pro rate limits or access issues
- MongoDB index performance issues
- CORS/Auth issues between services
- Team member availability/blockers

## 9. Daily Standup Template
Each team member should answer:
1. What integration task did I complete yesterday?
2. What integration task am I working on today?
3. What's blocking me? (include which team member needs to help)
4. Am I on track for my Day X deliverables?

## 10. Integration Testing Checklist

### Scenario 1: Ingestion -> QA -> Dashboard (Critical Path)
- [ ] Ingestion Service publishes data to Kafka
- [ ] QA-AI Service consumes and stores data
- [ ] Question submitted through Dashboard Web
- [ ] Dashboard Service forwards to QA-AI Service
- [ ] QA-AI retrieves context and generates answer
- [ ] Answer published to Kafka / returned via API
- [ ] Dashboard Service normalizes response
- [ ] Dashboard Web displays answer
- [ ] Human review workflow works

### Scenario 2: Prompt Management Flow
- [ ] Create prompt via Dashboard Web
- [ ] Dashboard Service proxies to Prompt Management
- [ ] Prompt stored with version
- [ ] QA-AI Service fetches active prompt
- [ ] Prompt used in answer generation

### Scenario 3: Full Review Cycle
- [ ] Question asked
- [ ] AI answer generated
- [ ] Answer appears in QA Review dashboard
- [ ] Reviewer approves/rejects
- [ ] Status updated across all services

## 11. Communication Plan
- **Daily standups**: 15 min, 9:00 AM
- **Slack channel**: #integration-sprint
- **Blocking issues**: Immediate Slack DM to dependent team member
- **Contract changes**: Must be agreed by all affected parties before implementation
- **End-of-day updates**: Each member posts progress in Slack

## 12. Definition of Done (for the Sprint)
The integration is complete when:
- [ ] All Kafka topics created and producing/consuming correctly
- [ ] All REST API contracts implemented and tested
- [ ] End-to-end flow works: Ingest -> AI Answer -> Dashboard Display
- [ ] Prompt management CRUD works through the full stack
- [ ] Human review workflow works end-to-end
- [ ] All services deploy and start correctly together (docker-compose or K8s)
- [ ] No critical or high-severity integration gaps remain
- [ ] Integration tests pass
- [ ] Demo-ready

Output the complete `project-plan.md` file.
```

---

## Expected Output Location
`project-plan.md` (shared team artifact)

## Estimated Time
30-60 minutes to generate, then team review needed
