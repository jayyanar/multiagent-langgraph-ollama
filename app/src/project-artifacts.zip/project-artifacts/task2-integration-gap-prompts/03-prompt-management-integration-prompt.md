# Task 2 - Prompt: Identify Integration Gaps for Prompt Management Service (Java)

## Owner: Team Member 3 (Prompt Management)

## Prerequisites
- `information.md` from ALL 5 repos must be generated first (Task 1)

## How to Use This Prompt

1. Collect all 5 `information.md` files
2. Open Claude Code inside the **Prompt Management** repository
3. Copy the prompt below and run it
4. Review the generated `integration-gaps.md`

---

## Prompt

```
I am the owner of the Prompt Management Service (Java). This service handles prompt lifecycle (CRUD + versioning) and is consumed by Dashboard Service (for UI) and QA-AI Service (for AI answer generation). I have the `information.md` from all 5 services.

Here are the information.md files:
- Dashboard Web: [paste or reference path]
- Dashboard Service: [paste or reference path]
- Prompt Management: [paste or reference path]
- QA-AI Service: [paste or reference path]
- Ingestion Service: [paste or reference path]

Perform the following analysis and generate `integration-gaps.md`:

## 1. Prompt Management <-> Dashboard Service Integration

### API Endpoint Validation
For EACH endpoint Dashboard Service calls on me:
- Do I expose this endpoint?
- Does my request format match what Dashboard Service sends?
- Does my response format match what Dashboard Service expects?
- Field-by-field comparison: names, types, formats

### CRUD Completeness
- Create: Can Dashboard Service create prompts through me? Request/response aligned?
- Read: Can it list/search/get prompts? Pagination compatible?
- Update: Can it update prompts? Versioning behavior clear?
- Delete: Soft delete vs hard delete aligned?

### Version Management
- Can Dashboard Service get version history?
- Can it activate/deactivate specific versions?
- Is version rollback supported and properly exposed?

### Missing APIs
- Endpoints Dashboard Service needs but I don't have
- Endpoints I have that Dashboard Service doesn't consume yet

## 2. Prompt Management <-> QA-AI Service Integration (CRITICAL)

### Prompt Retrieval Contract
- How does QA-AI Service fetch prompts from me?
  - Direct API call: endpoint, params, response format
  - Via Kafka events?
  - Both?
- Does the endpoint I expose match what QA-AI Service calls?
- Does my response format match what QA-AI Service expects?

### Prompt Template Contract
- Am I returning prompt templates with variable placeholders?
- Does QA-AI Service understand my placeholder format (e.g., {{variable}}, {variable}, $variable)?
- Am I returning all metadata QA-AI needs (category, version, status)?

### Active Prompt Selection
- How does QA-AI Service know which prompt version to use?
- Do I have an endpoint to get "active" prompt by category/name?
- Is the prompt selection logic aligned between services?

### Prompt Update Notification
- When a prompt is updated/activated, does QA-AI Service get notified?
- Via Kafka event? If so:
  - Topic name match?
  - Event payload schema match?
  - Does QA-AI consume this topic?
- Does QA-AI need to invalidate its prompt cache?

### Variable Substitution
- Who resolves prompt variables - me or QA-AI Service?
- Is this agreed upon and consistent?

## 3. Prompt Management <-> Dashboard Web (Indirect via Dashboard Service)
- Are all prompt features accessible through the full chain (Web -> Dashboard Service -> Me)?
- Is any prompt data lost or not normalized in the chain?
- Can the UI display all prompt metadata I provide?

## 4. Kafka Integration Gaps

### Events I Publish
- For each event type I publish (PROMPT_CREATED, UPDATED, VERSION_ACTIVATED, etc.):
  - Topic name: Does it match what consumers expect?
  - Schema: Does it match what consumers parse?
  - Is anyone actually consuming these events?

### Events I Consume (if any)
- Am I consuming any events from other services?
- Topic and schema alignment

### Cross-Service Topic Table
| My Topic Name | What I Publish | Who Should Consume | Their Topic Config | Match? | Schema Match? |
|---|---|---|---|---|---|

## 5. MongoDB Gaps
- If Dashboard Service reads my MongoDB directly (instead of API), are schemas aligned?
- Collection naming conflicts?
- Do other services need read access to my collections?

## 6. Data Model Compatibility
- Compare my Prompt entity with:
  - Dashboard Service's DTO for prompts
  - QA-AI Service's prompt model
  - Dashboard Web's TypeScript interface for prompts
- Identify ALL mismatches: field names, types, missing fields, extra fields

## 7. Configuration Gaps
- Service URL configurations (are other services configured to reach me?)
- Port, context path, API version path alignment
- Auth mechanism alignment

## 8. Integration Gap Report

| # | Gap Description | Integration Partner | Severity | Blocking? | My Action Items | Needs From Partner | Estimated Effort |
|---|---|---|---|---|---|---|---|

## 9. My Action Items (Prompt Management Owner)
- [ ] New endpoints to create
- [ ] Existing endpoints to modify
- [ ] Kafka producer changes
- [ ] Data model changes
- [ ] Configuration updates
- [ ] Documentation to provide

## 10. Requests to Each Team
- **Dashboard Service team**: [specific requests]
- **QA-AI Service team**: [specific requests]
- **Dashboard Web team**: [specific requests]
- **Ingestion Service team**: [specific requests, if any]

Output the complete `integration-gaps.md` file.
```

---

## Expected Output Location
`<repo-root>/integration-gaps.md`
