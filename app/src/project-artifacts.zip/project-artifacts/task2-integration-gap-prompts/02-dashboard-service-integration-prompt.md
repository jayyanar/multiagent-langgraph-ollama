# Task 2 - Prompt: Identify Integration Gaps for Dashboard Service (Java)

## Owner: Team Member 2 (Dashboard Service)

## Prerequisites
- `information.md` from ALL 5 repos must be generated first (Task 1)

## How to Use This Prompt

1. Collect all 5 `information.md` files
2. Open Claude Code inside the **Dashboard Service** repository
3. Copy the prompt below and run it
4. Review the generated `integration-gaps.md`

---

## Prompt

```
I am the owner of the Dashboard Service (Java). This service is the central hub that normalizes responses from Prompt Management, QA-AI Service, and Ingestion Service for the Dashboard Web UI. I have the `information.md` files from all 5 services. Analyze them to identify ALL pending integration items.

Here are the information.md files:
- Dashboard Web: [paste or reference path]
- Dashboard Service: [paste or reference path]
- Prompt Management: [paste or reference path]
- QA-AI Service: [paste or reference path]
- Ingestion Service: [paste or reference path]

Perform the following analysis and generate `integration-gaps.md`:

## 1. Dashboard Service <-> Dashboard Web API Contract Analysis

### Endpoint-by-Endpoint Validation
For EACH endpoint Dashboard Web calls:
- Does my service expose this endpoint?
- Does my response format match what Web expects?
- Am I missing any endpoints that Web needs?
- Field-level comparison: names, types, nullability, formats (dates, enums)
- Pagination format compatibility
- Error response format alignment
- Are there any endpoints I expose that Web doesn't use yet?

### WebSocket/SSE Gap
- Does Web expect real-time updates?
- Do I provide them? Via what mechanism?
- What events should trigger real-time pushes?

## 2. Dashboard Service <-> Prompt Management Integration

### API Client Validation
For EACH endpoint I call on Prompt Management:
- Does the endpoint exist in Prompt Management's information.md?
- Does my request match their expected format?
- Does their response match my parsing/mapping logic?
- Field mismatches (names, types, optional vs required)

### Normalization Logic
- Am I normalizing Prompt Management responses correctly for the Web UI?
- Are there prompt fields I'm not mapping that the UI needs?
- Version information: Am I passing version metadata to the UI?

### Missing Integrations
- Prompt CRUD endpoints I should proxy but don't
- Prompt search/filter capabilities I should expose

## 3. Dashboard Service <-> QA-AI Service Integration

### API Client Validation
For EACH endpoint I call on QA-AI Service:
- Does the endpoint exist?
- Request/response format match?
- Field-level mismatches?

### Response Normalization
- Am I normalizing QA-AI responses correctly?
- Answer format: text, markdown, structured?
- Confidence scores, source references, metadata
- Am I handling streaming responses (if QA-AI streams)?

### Kafka Event Integration
- Do I consume QA-AI response events from Kafka?
- Is the Kafka topic name consistent between what QA-AI produces and what I consume?
- Is the message schema compatible?
- Am I in the correct consumer group?

## 4. Dashboard Service <-> Ingestion Service Integration

### Ingestion Status & Monitoring
- Do I expose ingestion job status to the Web UI?
- Do I call Ingestion Service APIs for job management?
- Endpoint and format validation

### Kafka Event Integration
- Do I consume ingestion status events from Kafka?
- Topic name and schema compatibility?

## 5. Kafka Integration Gaps (CRITICAL)

### Topic Alignment Check
Create a table comparing:
| Topic Name (My Config) | Topic Name (Other Service Config) | Match? | Schema Compatible? | Notes |
|---|---|---|---|---|

### Consumer Group Analysis
- Am I using unique consumer groups?
- Are there consumer group conflicts?
- Offset management strategy alignment

### Schema Compatibility
For each Kafka topic I interact with:
- Compare my message model with the producer/consumer's model
- Identify field mismatches
- Serialization format match (JSON, Avro, Protobuf)?

## 6. MongoDB Gaps
- Am I reading from collections written by other services?
- Schema alignment for shared collections
- Index compatibility

## 7. Configuration & Environment Gaps
- Service URL configuration for all upstream services
- Kafka bootstrap server configuration
- MongoDB connection configuration
- Missing environment variables
- Timeout and retry configuration per upstream service

## 8. Security & Auth Gaps
- JWT/token validation alignment
- Am I passing auth tokens to upstream services correctly?
- Role-based authorization consistency

## 9. Integration Gap Report

| # | Gap Description | Integration Partner | Severity | Blocking? | My Action Items | Needs From Partner | Estimated Effort |
|---|---|---|---|---|---|---|---|

## 10. My Action Items (Dashboard Service Owner)
- [ ] API endpoints to create/modify
- [ ] Upstream client code to write/fix
- [ ] Kafka consumer/producer changes
- [ ] Normalization logic to implement
- [ ] Configuration changes
- [ ] Error handling additions

## 11. Requests to Each Team
- **Dashboard Web team**: [what I need from them]
- **Prompt Management team**: [what I need from them]
- **QA-AI Service team**: [what I need from them]
- **Ingestion Service team**: [what I need from them]

Output the complete `integration-gaps.md` file.
```

---

## Expected Output Location
`<repo-root>/integration-gaps.md`
