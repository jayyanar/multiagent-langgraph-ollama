# Task 2 - Prompt: Identify Integration Gaps for Ingestion Service (Node.js) - CRITICAL

## Owner: Team Member 5 (Ingestion Service)

## Prerequisites
- `information.md` from ALL 5 repos must be generated first (Task 1)

## How to Use This Prompt

1. Collect all 5 `information.md` files
2. Open Claude Code inside the **Ingestion Service** repository
3. Copy the prompt below and run it
4. Review the generated `integration-gaps.md`

---

## Prompt

```
I am the owner of the Ingestion Service (Node.js) - the most critical service in the system. I connect with multiple datasources, perform config-based and node-based data processing, and deliver processed data to QA-AI Service via Kafka. I have the `information.md` from all 5 services.

Here are the information.md files:
- Dashboard Web: [paste or reference path]
- Dashboard Service: [paste or reference path]
- Prompt Management: [paste or reference path]
- QA-AI Service: [paste or reference path]
- Ingestion Service: [paste or reference path]

Perform the following analysis and generate `integration-gaps.md`:

## 1. Ingestion Service <-> QA-AI Service Integration (MOST CRITICAL)

### Kafka Output to QA-AI Service
This is the most important integration. Analyze in extreme detail:

#### Topic Configuration
- Topic name I produce to vs topic name QA-AI consumes from - EXACT MATCH?
- Partition count and strategy alignment
- Retention policy adequate for QA-AI's processing speed?

#### Message Schema (Field-by-Field Comparison)
Compare what I produce with what QA-AI expects to receive:
| Field Name (My Output) | Type | Field Name (QA-AI Expects) | Type | Match? | Issue |
|---|---|---|---|---|---|

- Are there fields I send that QA-AI doesn't use?
- Are there fields QA-AI needs that I don't send?
- Data type mismatches?
- Nesting structure differences?
- Null/optional field handling differences?

#### Document/Chunk Format
- Am I chunking data before sending? Does QA-AI expect chunks or full documents?
- Chunk size: Am I chunking at sizes QA-AI's context window can handle?
- Metadata I include with each chunk vs metadata QA-AI needs:
  - Source identifier
  - Timestamp
  - Document type/category
  - Parent document reference
  - Chunk sequence number
  - Schema version

#### Embedding Data
- Am I generating embeddings? Does QA-AI expect them?
- Embedding model alignment (same model for generation and retrieval?)
- Embedding dimensions match?

#### Delivery Guarantees
- My producer: acks setting (0, 1, all)?
- Message ordering guarantees needed by QA-AI?
- Duplicate message handling?
- Batch size and linger configuration

#### Error Scenarios
- What happens when QA-AI is down? Do I have backpressure handling?
- DLQ (Dead Letter Queue) for failed messages?
- Retry mechanism alignment

## 2. Ingestion Service <-> Dashboard Service Integration

### Job Status Reporting
- Do I expose API endpoints for job status that Dashboard Service calls?
- Endpoint format alignment
- Do I publish job status events to Kafka that Dashboard Service consumes?
- Status event schema compatibility

### Job Management
- Can Dashboard Service trigger/stop/restart ingestion jobs through me?
- API endpoint alignment for job management
- Request/response format compatibility

### Ingestion Monitoring
- Metrics I expose vs what Dashboard Service needs to display
- Progress reporting format
- Error/failure reporting format

## 3. Ingestion Service <-> Prompt Management Integration (if any)
- Do I interact with Prompt Management at all?
- If yes, for what purpose? (pre-processing templates, data categorization?)
- Any missing integrations?

## 4. Ingestion Service <-> Dashboard Web (Indirect)
- Can users see ingestion status in the UI?
- Is the data flow: Me -> Kafka/API -> Dashboard Service -> Dashboard Web complete?
- Missing status information?

## 5. Datasource Connector Gaps
- Which connectors are complete and tested?
- Which are in-progress or missing?
- Are all required datasources for the current project supported?
- Configuration format: Is it documented enough for the team?

## 6. Pipeline & Node Gaps
- Which processing nodes are complete?
- Which transformations are needed but missing?
- Is the output format from my pipeline compatible with QA-AI's input expectations?
- Config-driven pipeline: Can all required workflows be expressed in config?

## 7. Kafka Integration (COMPREHENSIVE)

### Topics I Produce
| Topic Name | Target Consumer | Their Config | Schema Match? | Blocking Issue? |
|---|---|---|---|---|

### Topics I Consume (if any)
| Topic Name | Source Producer | Schema Match? | Issue? |
|---|---|---|---|

### Kafka Configuration Alignment
- Bootstrap servers: Same across all services?
- Serialization format: Same across all services?
- Schema registry: Used? Compatible?

## 8. MongoDB Gaps
- Collections I write to: Does anyone read from them?
- Schema alignment with Dashboard Service (if applicable)
- Job status collection: Format compatible with Dashboard Service?

## 9. Configuration & Environment Gaps
- Datasource credentials management alignment
- Kafka configuration consistency
- MongoDB configuration consistency
- Service discovery for downstream services
- Missing environment variables

## 10. End-to-End Data Flow Validation
Trace the complete flow and identify breaks:
1. Datasource connection -> Extract data -> GAP?
2. Config/node-based processing pipeline -> GAP?
3. Data transformation and enrichment -> GAP?
4. Produce to Kafka topic -> GAP?
5. QA-AI Service consumes -> GAP?
6. QA-AI stores/indexes data -> GAP?
7. QA-AI uses data for answering -> GAP?

For each GAP, describe:
- What's expected
- What's actual
- Impact if not fixed
- Suggested fix

## 11. Integration Gap Report

| # | Gap Description | Integration Partner | Severity | Blocking? | My Action Items | Needs From Partner | Estimated Effort |
|---|---|---|---|---|---|---|---|

## 12. My Action Items (Ingestion Service Owner)
- [ ] Kafka producer schema changes
- [ ] New connectors to build
- [ ] Pipeline node changes
- [ ] API endpoint changes
- [ ] Configuration changes
- [ ] Output format changes for QA-AI compatibility
- [ ] MongoDB schema changes
- [ ] Error handling improvements

## 13. Requests to Each Team
- **QA-AI Service team**: [specific requests - MOST IMPORTANT - agree on data contract]
- **Dashboard Service team**: [specific requests]
- **Dashboard Web team**: [specific requests]
- **Prompt Management team**: [specific requests, if any]

## 14. Shared Contract Proposal
Based on the gaps found, propose a shared data contract for the Ingestion -> QA-AI pipeline:
```json
{
  "proposed_kafka_topic": "...",
  "proposed_message_schema": {
    // Complete schema here
  },
  "proposed_metadata_fields": {
    // Required metadata
  }
}
```

Output the complete `integration-gaps.md` file.
```

---

## Expected Output Location
`<repo-root>/integration-gaps.md`
