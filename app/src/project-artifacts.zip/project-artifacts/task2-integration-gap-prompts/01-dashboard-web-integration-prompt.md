# Task 2 - Prompt: Identify Integration Gaps for Dashboard Web (ReactJS)

## Owner: Team Member 1 (Dashboard Web)

## Prerequisites
- `information.md` from ALL 5 repos must be generated first (Task 1)
- Collect `information.md` from: Dashboard Service, Prompt Management, QA-AI Service, Ingestion Service

## How to Use This Prompt

1. Place all 5 `information.md` files in a temporary folder (or have them accessible)
2. Open Claude Code inside the **Dashboard Web** repository
3. Copy the prompt below and run it, providing paths to all information.md files
4. Review the generated `integration-gaps.md` and share with the team

---

## Prompt

```
I am the owner of the Dashboard Web (ReactJS) service. I have the `information.md` files from all 5 services in our microservices architecture. Analyze them to identify ALL pending integration items between Dashboard Web and every other service.

Here are the information.md files:
- Dashboard Web: [paste or reference path to information.md]
- Dashboard Service: [paste or reference path to information.md]
- Prompt Management: [paste or reference path to information.md]
- QA-AI Service: [paste or reference path to information.md]
- Ingestion Service: [paste or reference path to information.md]

Perform the following analysis and generate `integration-gaps.md`:

## 1. Dashboard Web <-> Dashboard Service Integration Analysis

### API Contract Validation
For EACH API endpoint that Dashboard Web calls on Dashboard Service:
- Does the endpoint exist in Dashboard Service's information.md?
- Does the request payload from Web match what Service expects?
- Does the response structure from Service match what Web expects?
- Are there field name mismatches, type mismatches, or missing fields?
- Are pagination parameters compatible?
- Is the authentication mechanism consistent (same token format, header name)?

### Missing Endpoints
- APIs that Web needs but Dashboard Service doesn't expose
- APIs that Dashboard Service exposes but Web doesn't consume (potential missing features)

### Real-time Updates
- Does Web expect WebSocket/SSE for real-time updates?
- Does Dashboard Service support WebSocket/SSE?
- Is there a gap in how real-time data flows?

### Error Handling Alignment
- Does Web handle all error codes that Service returns?
- Are error response formats consistent?

## 2. Dashboard Web <-> Prompt Management Integration (via Dashboard Service)
- Can the Web UI perform all prompt CRUD operations?
- Does the prompt data model in Web match what Prompt Management returns?
- Is prompt versioning properly reflected in the UI?
- Can users preview/test prompts from the UI?

## 3. Dashboard Web <-> QA-AI Service Integration (via Dashboard Service)
- Can the Web UI display AI-generated answers correctly?
- Does the answer response model match between QA-AI Service output and what Web expects?
- Can users review, approve, or reject AI answers?
- Is the review workflow complete end-to-end?

## 4. Dashboard Web <-> Ingestion Service Integration (via Dashboard Service)
- Can the Web UI show ingestion job status?
- Can users trigger or monitor ingestion from the UI?
- Is ingestion status properly normalized by Dashboard Service for the UI?

## 5. Environment & Configuration Gaps
- Are API base URLs properly configured?
- Are there environment variable mismatches between services?
- CORS configuration: Does Dashboard Service allow requests from Web's origin?

## 6. Authentication & Authorization Gaps
- Is the auth flow complete? (Login -> Token -> API calls -> Token refresh)
- Do role-based permissions align across services?
- Token format consistency

## 7. Generate Integration Gap Report

Create a prioritized table:

| # | Gap Description | Severity (Critical/High/Medium/Low) | Blocking? | My Action Items | Dependency On (Service) | Estimated Effort |
|---|---|---|---|---|---|---|

Categories:
- **Critical**: Integration will fail without this
- **High**: Feature will be incomplete
- **Medium**: Degraded experience
- **Low**: Nice to have

## 8. Action Items for Me (Dashboard Web Owner)
List specific code changes I need to make:
- [ ] API client changes
- [ ] Data model updates
- [ ] New components to build
- [ ] Error handling to add
- [ ] Configuration changes

## 9. Requests to Other Teams
List what I need from each other team member:
- **Dashboard Service team**: [specific requests]
- **Prompt Management team**: [specific requests]
- **QA-AI Service team**: [specific requests]
- **Ingestion Service team**: [specific requests]

Output the complete `integration-gaps.md` file.
```

---

## Expected Output Location
`<repo-root>/integration-gaps.md`
