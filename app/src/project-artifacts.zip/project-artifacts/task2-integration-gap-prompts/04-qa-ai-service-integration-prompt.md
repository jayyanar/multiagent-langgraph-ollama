# Task 2 - Prompt: Identify Integration Gaps for QA-AI Service (Python)

## Owner: Team Member 4 (QA-AI Service)

## Prerequisites
- `information.md` from ALL 5 repos must be generated first (Task 1)

## How to Use This Prompt

1. Collect all 5 `information.md` files
2. Open Claude Code inside the **QA-AI Service** repository
3. Copy the prompt below and run it
4. Review the generated `integration-gaps.md`

---

## Prompt

```
I am the owner of the QA-AI Service (Python) that uses Google ADK and Gemini Pro to answer questions. My service is the AI brain of the system. I consume data from Ingestion Service and prompts from Prompt Management, and my responses are displayed through Dashboard Service -> Dashboard Web. I have the `information.md` from all 5 services.

Here are the information.md files:
- Dashboard Web: [paste or reference path]
- Dashboard Service: [paste or reference path]
- Prompt Management: [paste or reference path]
- QA-AI Service: [paste or reference path]
- Ingestion Service: [paste or reference path]

Perform the following analysis and generate `integration-gaps.md`:

## 1. QA-AI Service <-> Ingestion Service Integration (MOST CRITICAL)

### Kafka Data Ingestion
- Topic names: Does my consumer topic config match Ingestion Service's producer topic config?
- Consumer group: Am I using the correct consumer group?
- Message schema: Compare field-by-field:
  - What Ingestion Service produces (from their information.md)
  - What I expect to receive (from my information.md)
  - Identify EVERY mismatch: field names, types, nesting, optional vs required
- Serialization format: JSON vs Avro vs Protobuf alignment
- Message key format: Am I handling their key format correctly?

### Data Processing Pipeline
- When I receive ingested data:
  - Do I store it? Where? In what format?
  - Do I generate embeddings? From which fields?
  - Is the storage schema compatible with my retrieval logic?
- Data freshness: How quickly do I process new ingested data?
- Batch vs streaming: Am I processing messages one-by-one or in batches?

### Document/Chunk Format
- Ingestion Service output format vs my expected input format:
  - Document structure (title, content, metadata, source)
  - Chunk format (if pre-chunked by Ingestion Service)
  - Metadata fields I expect but Ingestion Service may not provide
  - Embedding format (if Ingestion Service provides embeddings)

### Missing Data
- Data I need for question answering that Ingestion Service doesn't provide
- Data Ingestion Service provides that I don't process or store
- Context enrichment data gaps

## 2. QA-AI Service <-> Prompt Management Integration (CRITICAL)

### Prompt Fetching
- API endpoint I call: Does it exist in Prompt Management's information.md?
- Request format alignment (how I request a prompt vs what they expect)
- Response format alignment (what they return vs what I parse)

### Prompt Template Processing
- Placeholder format: Does my substitution logic match their placeholder format?
  - My expected format: {{variable}} or {variable} or $variable?
  - Their format?
- Variables I need to substitute: Are they documented in the prompt metadata?
- System prompt vs user prompt: Is the separation clear?

### Prompt Caching
- Do I cache prompts? For how long?
- When Prompt Management updates a prompt:
  - Am I notified? Via Kafka event?
  - Topic name and schema alignment for prompt update events?
  - Do I invalidate my cache?

### Prompt Selection
- How do I select the right prompt for a question?
  - By ID? By category? By name?
  - Does Prompt Management support my selection criteria?
  - Can I get the "active" version easily?

## 3. QA-AI Service <-> Dashboard Service Integration

### Response Delivery
- How does Dashboard Service get my answers?
  - Via Kafka event? Topic name, schema match?
  - Via direct API call? Endpoint alignment?
  - Both?

### Response Schema
- My answer response format vs what Dashboard Service expects:
  - Answer text format (plain text, markdown, HTML?)
  - Confidence score format
  - Source references format
  - Metadata format
  - Token usage info
- Streaming: Do I stream answers? Does Dashboard Service handle streams?

### QA Session Management
- Who manages sessions/conversations? Me or Dashboard Service?
- Session ID format alignment
- Conversation history: Who stores it? Format?

### Review Workflow
- When a human reviews my answer:
  - How am I notified? (Kafka event? API callback?)
  - Do I receive feedback for model improvement?
  - Review result schema alignment

## 4. QA-AI Service <-> Dashboard Web (Indirect)
- Does the final answer displayed in Web UI match what I generate?
- Is any data lost through the Dashboard Service normalization?
- Are confidence scores, sources, and metadata displayed correctly?

## 5. Kafka Integration Gaps (CRITICAL)

### Topics I Consume
| My Topic Config | Expected Producer | Their Topic Config | Match? | Schema Match? | Issue |
|---|---|---|---|---|---|

### Topics I Produce
| My Topic Config | Expected Consumer | Their Topic Config | Match? | Schema Match? | Issue |
|---|---|---|---|---|---|

### Consumer Group Conflicts
- Am I sharing consumer groups with any other service inadvertently?
- Could this cause message loss?

## 6. Google ADK / Gemini Pro Gaps
- Are there any integration gaps related to:
  - Prompt size limits vs what I'm constructing?
  - Response format expectations?
  - Rate limiting considerations?
  - Token counting alignment?

## 7. MongoDB Gaps
- Collections I write to: Are other services reading from them?
- Schema alignment with Dashboard Service (if it reads my collections)
- Shared collections: Any conflict?

## 8. Data Flow End-to-End Validation
Trace the complete flow and identify breaks:
1. Ingestion Service ingests data -> (Kafka) -> I receive it -> GAP?
2. I store/index the data -> GAP?
3. Question arrives (from Dashboard Service API) -> GAP?
4. I fetch prompt from Prompt Management -> GAP?
5. I retrieve relevant context from stored data -> GAP?
6. I construct LLM prompt and call Gemini Pro -> GAP?
7. I format response and publish/return -> GAP?
8. Dashboard Service receives and normalizes -> GAP?
9. Dashboard Web displays -> GAP?

## 9. Integration Gap Report

| # | Gap Description | Integration Partner | Severity | Blocking? | My Action Items | Needs From Partner | Estimated Effort |
|---|---|---|---|---|---|---|---|

## 10. My Action Items (QA-AI Service Owner)
- [ ] Kafka consumer changes
- [ ] Kafka producer changes
- [ ] Prompt fetching/caching implementation
- [ ] Data model changes
- [ ] API endpoint changes
- [ ] Response format changes
- [ ] Document processing pipeline changes

## 11. Requests to Each Team
- **Ingestion Service team**: [specific requests - MOST IMPORTANT]
- **Prompt Management team**: [specific requests]
- **Dashboard Service team**: [specific requests]
- **Dashboard Web team**: [specific requests]

Output the complete `integration-gaps.md` file.
```

---

## Expected Output Location
`<repo-root>/integration-gaps.md`
