# Task 1 - Prompt: Generate information.md for Ingestion Service (Node.js) - CRITICAL SERVICE

## Owner: Team Member 5 (Ingestion Service)

## How to Use This Prompt

1. Open Claude Code (or any AI assistant) inside the **Ingestion Service** repository root
2. Copy the prompt below and run it
3. Review the generated `information.md` and commit it to the repo

---

## Prompt

```
I need you to thoroughly analyze this Node.js-based Ingestion Service repository and generate a comprehensive `information.md` file at the repository root. This is a CRITICAL service that connects with multiple datasources, performs config-based and node-based development, and shares responses to the QA-AI Service. This document will be used by other teams for integration.

This is the most complex service in the system. Be extremely thorough.

Analyze the entire codebase and produce the following sections:

## 1. Service Overview
- Service name, purpose, and business context
- Tech stack (Node.js version, framework - Express/NestJS/Fastify, TypeScript or JavaScript)
- Core responsibility: Multi-datasource ingestion with config-driven and node-based processing pipelines
- Why this is critical: It feeds data to QA-AI Service for question answering

## 2. Architecture
- Project structure (directories and their purposes)
- High-level data flow: Datasource -> Connector -> Pipeline -> Processing -> Output to QA-AI Service
- Config-based development pattern:
  - How configurations define data pipelines
  - Configuration schema and format (JSON/YAML)
  - How to add new datasource via config without code changes
- Node-based development pattern:
  - What are "nodes"? (processing steps, transformations)
  - How nodes are chained/composed
  - Node interface/contract
  - Available node types and their purposes
  - How to create custom nodes
- Plugin/connector architecture

## 3. Datasource Connectors (CRITICAL)
- List ALL supported datasource types:
  - Databases (PostgreSQL, MySQL, MongoDB, etc.)
  - File sources (S3, local filesystem, FTP)
  - APIs (REST, GraphQL, SOAP)
  - Message queues (Kafka, RabbitMQ, SQS)
  - Cloud services (AWS, GCP, Azure specific)
  - Other (Elasticsearch, Redis, etc.)
- For EACH connector:
  - Configuration schema (connection string, auth, options)
  - Data extraction method (query, scan, API call)
  - Pagination/batching strategy
  - Error handling and retry logic
  - Rate limiting
  - Connection pooling

## 4. Processing Pipeline (CRITICAL)
- Pipeline stages (in order):
  1. Data extraction from source
  2. Data validation
  3. Data transformation
  4. Data enrichment
  5. Data normalization
  6. Output/delivery to QA-AI Service
- For each stage:
  - Available processors/nodes
  - Configuration options
  - Input/output data format
- Pipeline orchestration:
  - Sequential vs parallel processing
  - Error handling per stage
  - Pipeline state management
  - Resume/retry capabilities

## 5. Configuration Schema (CRITICAL)
- Complete configuration file format with examples:
  - Datasource configuration
  - Pipeline/node configuration
  - Scheduling configuration
  - Output configuration
- How to define a new ingestion job via config
- Config validation rules
- Hot reload of configurations (if supported)

## 6. REST API Endpoints
- List ALL endpoints:
  - **Ingestion Job Management**: Create, start, stop, status, delete jobs
  - **Datasource Management**: CRUD for datasource configurations
  - **Pipeline Management**: CRUD for pipeline configurations
  - **Monitoring**: Health, metrics, job status, pipeline status
  - **Manual Trigger**: Endpoints to manually trigger ingestion
- For each endpoint: URL, method, request/response schema

## 7. Output to QA-AI Service (CRITICAL)
- How processed data is delivered to QA-AI Service:
  - Kafka topics used: Topic name, message schema, partitioning strategy
  - Direct API calls (if any): Endpoint, method, payload
- Output data schema:
  - Document/chunk format
  - Metadata included (source, timestamp, schema, version)
  - Embedding data (if embeddings are generated here)
- Delivery guarantees (at-least-once, exactly-once)
- Backpressure handling
- Batch vs streaming delivery

## 8. Kafka Integration (CRITICAL)
- **Produces to** (list each topic):
  - Topic name
  - Message key format
  - Message value schema (complete field-by-field)
  - Partition strategy
  - When messages are produced (per document? per batch? per job completion?)
- **Consumes from** (if any):
  - Topic name, consumer group, message schema
  - Processing logic
- Kafka configuration (bootstrap servers, producer settings)
- Error handling (DLQ, retry topics)

## 9. MongoDB Integration
- Database name and all collections
- Document schemas:
  - Ingestion job status/history collection
  - Datasource configuration collection
  - Pipeline configuration collection
  - Processed data collection (if stored before Kafka)
  - Error/failure log collection
- Indexes and query patterns

## 10. Scheduling & Triggers
- How ingestion jobs are scheduled (cron, interval, event-driven)
- Scheduling library used (node-cron, Bull, Agenda, etc.)
- Manual trigger mechanism
- Event-driven triggers (webhook, Kafka event)

## 11. Data Models
- List ALL key models/interfaces:
  - Datasource configuration model
  - Pipeline/node configuration model
  - Ingestion job model
  - Processing node input/output interfaces
  - Kafka message models (outbound to QA-AI)
  - Raw data model (from sources)
  - Processed data model (output format)

## 12. Error Handling & Resilience
- Per-source error handling
- Pipeline stage failure handling
- Retry strategies (exponential backoff, max retries)
- Dead letter handling
- Alerting/notification on failures
- Data validation errors

## 13. Monitoring & Observability
- Health check endpoints
- Metrics exposed (Prometheus, CloudWatch, etc.)
- Logging strategy
- Job status tracking
- Pipeline execution monitoring

## 14. Configuration & Environment
- All environment variables with descriptions
- Configuration files
- Secrets management (datasource credentials, API keys)
- Profile-specific settings

## 15. Build & Deployment
- Dependencies (`package.json`)
- Build and start commands
- Docker configuration
- Required infrastructure
- CI/CD pipeline

## 16. Current Status & Known Issues
- Datasource connectors: which are complete, which are in-progress
- Pipeline nodes: which are complete, which are in-progress
- Known bugs or tech debt
- TODO/FIXME items
- Missing features
- Performance bottlenecks
- Hardcoded values

## 17. Integration Touchpoints Summary

**APIs Exposed:**
| Endpoint | Method | Purpose | Called By | Status | Notes |
|---|---|---|---|---|---|

**Kafka Topics Produced (Output):**
| Topic | Message Schema | Consumed By | Purpose | Status | Notes |
|---|---|---|---|---|---|

**Kafka Topics Consumed (Input):**
| Topic | Producer | Message Schema | Purpose | Status | Notes |
|---|---|---|---|---|---|

**Datasource Connectors:**
| Datasource Type | Config Schema | Status | Notes |
|---|---|---|---|

**Processing Nodes:**
| Node Type | Input Format | Output Format | Purpose | Status | Notes |
|---|---|---|---|---|---|

Scan the ENTIRE codebase very thoroughly including:
- `package.json` for dependencies
- All source files (JS/TS)
- Configuration files and examples
- Docker files
- Test files (especially integration tests)
- Any `docs/`, `examples/`, `config/` directories
- Connector/plugin directories
- Pipeline/node directories

This service is the most critical piece. Be extremely thorough and do NOT skip any files.

Output the complete `information.md` file.
```

---

## Expected Output Location
`<repo-root>/information.md`

## Estimated Time
30-45 minutes (largest and most complex service)

## Validation Checklist
- [ ] All datasource connectors listed with configuration schemas
- [ ] Processing pipeline fully documented (stages, nodes, flow)
- [ ] Config-based development pattern explained with examples
- [ ] Node-based development pattern explained with interface contracts
- [ ] Output to QA-AI Service fully documented (Kafka topics, schemas)
- [ ] All API endpoints documented
- [ ] Kafka integration complete (topics, schemas, consumer groups)
- [ ] MongoDB collections and schemas documented
- [ ] Scheduling mechanism documented
- [ ] Error handling and resilience documented
- [ ] All environment variables and config listed
