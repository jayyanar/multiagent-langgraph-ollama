# Task 1 - Prompt: Generate information.md for Prompt Management Service (Java)

## Owner: Team Member 3 (Prompt Management)

## How to Use This Prompt

1. Open Claude Code (or any AI assistant) inside the **Prompt Management** repository root
2. Copy the prompt below and run it
3. Review the generated `information.md` and commit it to the repo

---

## Prompt

```
I need you to thoroughly analyze this Java-based Prompt Management Service repository and generate a comprehensive `information.md` file at the repository root. This service handles all prompt management including versioning and CRUD operations. This document will be used by other teams for integration.

Analyze the entire codebase and produce the following sections:

## 1. Service Overview
- Service name, purpose, and business context
- Tech stack (Java version, Spring Boot version, build tool)
- Core responsibility: Prompt lifecycle management (Create, Read, Update, Delete, Version)

## 2. Architecture
- Package structure and layering
- Prompt versioning strategy (how versions are tracked, immutability, rollback)
- Prompt template engine (if any - variable substitution, template syntax)
- Multi-tenancy support (if any)

## 3. REST API Endpoints (CRITICAL for Integration)
- List ALL CRUD endpoints:
  - **Create Prompt**: URL, method, request body schema (prompt text, metadata, tags, category)
  - **Read Prompt(s)**: URL, method, query params (filters, search, pagination), response schema
  - **Update Prompt**: URL, method, request body schema, versioning behavior on update
  - **Delete Prompt**: URL, method, soft delete vs hard delete
  - **Version Management**:
    - Get all versions of a prompt
    - Get specific version
    - Activate/deactivate a version
    - Rollback to previous version
  - **Prompt Retrieval for AI Service**:
    - How QA-AI Service fetches the active prompt (endpoint, params, response)
    - Bulk prompt retrieval if supported
- Response format (envelope, error format, pagination)
- Authentication/Authorization per endpoint

## 4. Prompt Data Model (CRITICAL)
- Complete Prompt entity schema:
  - All fields with types (id, name, text, version, category, tags, variables, metadata, timestamps)
  - Version tracking fields
  - Status/lifecycle fields (draft, active, archived, deprecated)
- Prompt variable/placeholder schema (how dynamic values are defined in prompts)
- Prompt category/tag taxonomy
- Audit trail (who changed what, when)

## 5. Kafka Integration
- Topics this service:
  - **Produces to**: Topic name, event type (PROMPT_CREATED, PROMPT_UPDATED, PROMPT_VERSION_ACTIVATED, etc.), payload schema
  - **Consumes from**: Any topics consumed
- When are events published (on every CRUD? Only on activation?)
- Event schema for each event type

## 6. MongoDB Integration
- Database name and collection names
- Document schema for prompts collection (with all fields, types, indexes)
- Version storage strategy (separate collection? Embedded array? Version field?)
- Indexes defined (for search, lookup performance)
- Any aggregation queries

## 7. Integration with QA-AI Service (CRITICAL)
- How does QA-AI Service fetch prompts?
  - Direct API call? Kafka event-driven sync? Cached locally?
- What is the contract for prompt retrieval?
  - Request format
  - Response format (prompt text with variables resolved? raw template?)
- Variable substitution: Does this service resolve variables or does QA-AI Service?
- Prompt selection logic (by category? by ID? latest active version?)

## 8. Integration with Dashboard Service
- How does Dashboard Service interact with prompts?
- CRUD operations exposed for the dashboard
- Prompt preview/testing endpoints (if any)
- Bulk operations support

## 9. Search & Filtering
- How are prompts searched (full-text search, tag-based, category-based)?
- Filter capabilities
- Sorting options
- Pagination implementation

## 10. Configuration
- All application configuration with descriptions
- Environment variables
- Profile-specific settings

## 11. Security
- Authentication mechanism
- Authorization (who can create/edit/delete/view prompts? Role-based?)
- API key management if applicable

## 12. Build & Deployment
- Build commands
- Docker configuration
- Health check endpoints
- Required infrastructure

## 13. Current Status & Known Issues
- Features complete vs in-progress
- Known bugs or tech debt
- TODO/FIXME items
- Missing integrations or placeholder implementations

## 14. Integration Touchpoints Summary

**APIs Exposed:**
| Endpoint | Method | Purpose | Consumed By | Status | Notes |
|---|---|---|---|---|---|

**Kafka Events Published:**
| Topic | Event Type | Payload Schema | Consumed By | Status | Notes |
|---|---|---|---|---|---|

**Kafka Events Consumed:**
| Topic | Event Type | Producer | Processing Logic | Status | Notes |
|---|---|---|---|---|---|

Scan the entire codebase including:
- `pom.xml` / `build.gradle`
- All Java source files
- Configuration files
- Test files (especially integration tests showing expected contracts)
- Docker files
- Migration scripts if any

Output the complete `information.md` file.
```

---

## Expected Output Location
`<repo-root>/information.md`

## Estimated Time
15-30 minutes

## Validation Checklist
- [ ] All CRUD endpoints documented with schemas
- [ ] Prompt data model fully documented with all fields
- [ ] Versioning strategy clearly explained
- [ ] Kafka events listed with schemas
- [ ] Integration contract with QA-AI Service documented
- [ ] Integration contract with Dashboard Service documented
- [ ] MongoDB schema and indexes documented
- [ ] Search/filter capabilities listed
