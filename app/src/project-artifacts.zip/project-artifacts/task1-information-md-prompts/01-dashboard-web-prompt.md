# Task 1 - Prompt: Generate information.md for Dashboard Web (ReactJS)

## Owner: Team Member 1 (Dashboard Web)

## How to Use This Prompt

1. Open Claude Code (or any AI assistant) inside the **Dashboard Web** repository root
2. Copy the prompt below and run it
3. Review the generated `information.md` and commit it to the repo

---

## Prompt

```
I need you to thoroughly analyze this ReactJS repository and generate a comprehensive `information.md` file at the repository root. This document will be used by other teams to understand this service for integration purposes.

Analyze the entire codebase and produce the following sections:

## 1. Service Overview
- Service name, purpose, and business context
- Tech stack (React version, state management library, UI framework, build tool)
- Target users (QA Reviewers, Human Reviewers, Admins)

## 2. Architecture
- Component hierarchy and folder structure
- State management approach (Redux/Context/Zustand etc.)
- Routing structure (list all routes with their purpose)
- Authentication & authorization mechanism (login flow, token management, role-based access)

## 3. API Dependencies (CRITICAL for Integration)
- List ALL API endpoints this UI calls, grouped by feature:
  - Endpoint URL pattern (e.g., `/api/v1/reviews`)
  - HTTP method (GET/POST/PUT/DELETE)
  - Request payload structure (with field types)
  - Expected response structure (with field types)
  - Which backend service this call targets (Dashboard Service, Prompt Management, QA-AI Service, Ingestion Service)
- How API base URLs are configured (env variables, config files)
- Authentication headers sent with requests (JWT, API Key, etc.)

## 4. Kafka Integration
- Does the UI consume any Kafka events directly (e.g., via WebSocket/SSE)?
- List all real-time/streaming features and how they receive updates
- Event types the UI listens for and their payload structure

## 5. MongoDB Dependencies
- Does the UI read from MongoDB directly or only through backend APIs?
- Any client-side caching or local storage schemas

## 6. Key Features & Screens
- List every major screen/page with:
  - Purpose
  - Data it displays
  - Actions users can perform
  - APIs called on that screen
- QA Review workflow (step by step)
- Human Review workflow (step by step)
- AI Response review and approval flow

## 7. Data Models & Types
- List all TypeScript interfaces/types or PropTypes that represent:
  - API request/response objects
  - Shared data models (Review, Question, Answer, Prompt, User, etc.)
  - Kafka event payloads consumed

## 8. Environment Configuration
- All environment variables with descriptions
- Configuration files and their purposes
- Feature flags if any

## 9. Build & Deployment
- Build commands and output
- Docker configuration if present
- CI/CD pipeline summary
- Deployment target (S3, CloudFront, Kubernetes, etc.)

## 10. Current Status & Known Issues
- Features that are complete vs in-progress
- Known bugs or tech debt
- Missing integrations or TODO items found in code (search for TODO, FIXME, HACK, PLACEHOLDER)
- Hardcoded values that should be configurable

## 11. Integration Touchpoints Summary
Create a table:
| Dependency Service | Integration Type | Endpoint/Topic | Status (Working/Partial/Not Started) | Notes |
|---|---|---|---|---|

Scan the entire codebase. Do NOT skip any files. Look at:
- `package.json` for dependencies
- `src/` for all components, services, hooks, utils
- `.env*` files for configuration
- `docker*` files for deployment config
- `README.md` for existing documentation
- Any `api/`, `services/`, `hooks/` directories for API calls
- Any `types/`, `models/`, `interfaces/` for data structures
- Any `config/` directory
- Test files for integration expectations

Output the complete `information.md` file.
```

---

## Expected Output Location
`<repo-root>/information.md`

## Estimated Time
15-30 minutes (depending on repo size)

## Validation Checklist
- [ ] All API endpoints are listed with request/response structures
- [ ] All environment variables are documented
- [ ] Integration touchpoints table is complete
- [ ] All screens and features are listed
- [ ] Kafka event consumption (if any) is documented
- [ ] Known TODOs and issues are captured
