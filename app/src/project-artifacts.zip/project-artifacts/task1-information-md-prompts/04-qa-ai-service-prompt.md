# Task 1 - Prompt: Generate information.md for QA-AI Service (Python)

## Owner: Team Member 4 (QA-AI Service)

## How to Use This Prompt

1. Open Claude Code (or any AI assistant) inside the **QA-AI Service** repository root
2. Copy the prompt below and run it
3. Review the generated `information.md` and commit it to the repo

---

## Prompt

```
I need you to thoroughly analyze this Python-based QA-AI Service repository and generate a comprehensive `information.md` file at the repository root. This service uses Google ADK and Gemini Pro model to answer questions using document information and data from the Ingestion Service. This document will be used by other teams for integration.

Analyze the entire codebase and produce the following sections:

## 1. Service Overview
- Service name, purpose, and business context
- Tech stack (Python version, web framework - FastAPI/Flask/Django, Google ADK version)
- AI/ML stack (Gemini Pro model, Google ADK, any vector DB, embedding model)
- Core responsibility: Answer questions using AI with context from documents and ingested data

## 2. Architecture
- Project structure (directories and their purposes)
- Request processing pipeline (from question receipt to answer generation)
- AI/LLM orchestration flow:
  1. Receive question
  2. Fetch relevant prompt from Prompt Management Service
  3. Retrieve context from documents / Ingestion Service data
  4. Construct LLM prompt (prompt template + context + question)
  5. Call Gemini Pro via Google ADK
  6. Process and format response
  7. Publish response event
- RAG (Retrieval Augmented Generation) architecture if applicable
- Agent architecture (if using Google ADK agents/tools)

## 3. REST API Endpoints (CRITICAL)
- List ALL endpoints:
  - **Question/Answer endpoint**: URL, method, request body (question text, context params, session info), response body (answer, confidence, sources, metadata)
  - **Health/Status endpoints**
  - **Document management endpoints** (if any)
  - **Session/conversation endpoints** (if maintaining chat history)
- Response format and error handling
- Async vs sync processing model
- Streaming support (if answers are streamed)

## 4. Google ADK & Gemini Pro Integration (CRITICAL)
- How Google ADK is configured and initialized
- Gemini Pro model configuration:
  - Model name/version used
  - Temperature, top_p, top_k, max_tokens settings
  - Safety settings
  - System instructions
- ADK Agent setup (if using agent framework):
  - Agent definition and tools
  - Tool definitions and their purposes
  - Agent orchestration flow
- Prompt construction:
  - How prompts are built (template + context + question)
  - How prompt templates are fetched from Prompt Management Service
  - Variable substitution logic
  - Context window management (how much context is included)
- Token usage tracking and limits

## 5. Ingestion Service Integration (CRITICAL)
- How does this service receive data from Ingestion Service?
  - Via Kafka events? Direct API calls? Both?
- Kafka topics consumed from Ingestion Service:
  - Topic names
  - Message payload schema (document chunks, metadata, embeddings)
  - Processing logic on receipt
- Data storage after ingestion:
  - Where is ingested data stored? (MongoDB, Vector DB, in-memory)
  - Document/chunk schema
  - Indexing strategy
- How ingested data is used during question answering:
  - Retrieval mechanism (vector search, keyword search, hybrid)
  - Relevance scoring
  - Context assembly from retrieved chunks

## 6. Prompt Management Service Integration (CRITICAL)
- How prompts are fetched:
  - API endpoint called
  - Caching strategy for prompts
  - Prompt refresh/invalidation logic
- How prompt templates are used:
  - Variable substitution process
  - Multiple prompt types (system prompt, user prompt, context prompt)

## 7. Kafka Integration (CRITICAL)
- **Consumes from** (list each topic):
  - Topic name, consumer group, message schema
  - Processing logic for each message type
  - Topics from Ingestion Service (ingested data events)
  - Topics from Prompt Management (prompt update events, if any)
- **Produces to** (list each topic):
  - Topic name, message key, message value schema
  - When events are produced (on answer generated, on error, etc.)
  - Event types: QA_RESPONSE_GENERATED, QA_PROCESSING_STARTED, QA_ERROR, etc.
- Consumer configuration (group ID, offset strategy, concurrency)
- Error handling (DLQ, retries)

## 8. MongoDB Integration
- Database name and collections
- Document schemas:
  - QA session/conversation collection
  - Document/context storage collection
  - Response history collection
  - Any analytics/metrics collection
- Indexes and query patterns

## 9. Document Processing
- How documents are processed and stored
- Chunking strategy (chunk size, overlap)
- Embedding generation (model used, dimensions)
- Vector storage (if using vector DB - which one, configuration)

## 10. Data Models
- List ALL key data classes/models:
  - Question request model
  - Answer response model
  - Document/chunk model
  - Kafka event models (inbound and outbound)
  - Ingestion payload model (what this service expects from Ingestion Service)
  - Prompt template model

## 11. Configuration
- All configuration settings (config files, env variables)
- Google Cloud / ADK configuration
- Kafka configuration
- MongoDB configuration
- Model parameters configuration
- Feature flags

## 12. Error Handling & Resilience
- How LLM failures are handled (timeout, rate limit, model errors)
- Fallback strategies
- Retry logic for upstream services
- Circuit breakers

## 13. Build & Deployment
- Dependencies (`requirements.txt` / `pyproject.toml` / `Pipfile`)
- Docker configuration
- Health check endpoints
- Required infrastructure (Google Cloud credentials, Kafka, MongoDB, Vector DB)

## 14. Current Status & Known Issues
- Features complete vs in-progress
- Known bugs or tech debt
- TODO/FIXME items
- Missing integrations
- Hardcoded values

## 15. Integration Touchpoints Summary

**APIs Exposed:**
| Endpoint | Method | Purpose | Called By | Status | Notes |
|---|---|---|---|---|---|

**APIs Called (Upstream):**
| Target Service | Endpoint | Method | Purpose | Status | Notes |
|---|---|---|---|---|---|

**Kafka Topics Consumed:**
| Topic | Producer Service | Payload Schema | Purpose | Status | Notes |
|---|---|---|---|---|---|

**Kafka Topics Produced:**
| Topic | Payload Schema | Consumed By | Purpose | Status | Notes |
|---|---|---|---|---|---|

Scan the entire codebase including:
- `requirements.txt` / `pyproject.toml` / `setup.py`
- All Python source files
- Configuration files (`.env`, `config.py`, `settings.py`)
- Docker files
- Test files
- Any `docs/` directory

Output the complete `information.md` file.
```

---

## Expected Output Location
`<repo-root>/information.md`

## Estimated Time
20-40 minutes

## Validation Checklist
- [ ] Google ADK and Gemini Pro configuration fully documented
- [ ] Ingestion Service integration (Kafka topics, payload schemas) documented
- [ ] Prompt Management integration documented
- [ ] All Kafka topics (consume and produce) listed with schemas
- [ ] Question-Answer pipeline fully described
- [ ] Document processing and retrieval mechanism explained
- [ ] MongoDB collections and schemas documented
- [ ] All API endpoints documented with request/response schemas
