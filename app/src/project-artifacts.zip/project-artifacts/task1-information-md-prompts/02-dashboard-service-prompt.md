# Task 1 - Prompt: Generate information.md for Dashboard Service (Java)

## Owner: Team Member 2 (Dashboard Service)

## How to Use This Prompt

1. Open Claude Code (or any AI assistant) inside the **Dashboard Service** repository root
2. Copy the prompt below and run it
3. Review the generated `information.md` and commit it to the repo

---

## Prompt

```
I need you to thoroughly analyze this Java-based Dashboard Service repository and generate a comprehensive `information.md` file at the repository root. This service normalizes all responses for the Dashboard Web UI. This document will be used by other teams for integration.

Analyze the entire codebase and produce the following sections:

## 1. Service Overview
- Service name, purpose, and business context
- Tech stack (Java version, Spring Boot version, build tool - Maven/Gradle)
- Role: Normalizes responses from other services for Dashboard Web UI consumption

## 2. Architecture
- Package structure and layering (Controller, Service, Repository, Model, DTO, Config)
- Design patterns used (e.g., Strategy, Factory, Adapter for normalization)
- How response normalization works (transformation pipeline, mapping logic)
- Error handling strategy (global exception handler, error response format)

## 3. REST API Endpoints (CRITICAL for Integration)
- List ALL endpoints exposed by this service:
  - Full URL path (e.g., `/api/v1/dashboard/reviews`)
  - HTTP method
  - Request parameters (path params, query params, request body with field types)
  - Response body structure (with field types, including pagination format)
  - Authentication/Authorization required
  - Which upstream service data is fetched from
- API versioning strategy
- Response envelope format (standard wrapper for all responses)
- Pagination format and parameters

## 4. Upstream Service Dependencies (CRITICAL)
- For EACH upstream service this service calls:
  - Service name (Prompt Management, QA-AI Service, Ingestion Service)
  - Endpoints called (URL, method, payload)
  - How service URLs are configured (config files, service discovery, env vars)
  - Circuit breaker / retry configuration
  - Timeout settings
  - Fallback behavior when upstream is unavailable

## 5. Kafka Integration (CRITICAL)
- List ALL Kafka topics this service:
  - **Produces to**: Topic name, message key format, message value schema, when it produces
  - **Consumes from**: Topic name, consumer group, message value schema, processing logic
- Kafka configuration (bootstrap servers, serializers, consumer group settings)
- Error handling for Kafka (DLQ, retry topics, error logging)
- Event flow diagrams (which events trigger which downstream actions)

## 6. MongoDB Integration
- Database name and all collection names
- Document schemas for each collection (field names, types, indexes)
- Repository interfaces and custom queries
- Read vs Write operations per collection
- Any aggregation pipelines

## 7. Data Models & DTOs
- List ALL:
  - Entity/Document classes (MongoDB documents)
  - DTOs (Data Transfer Objects) for API responses
  - DTOs for upstream service responses
  - Kafka message payload classes
  - Request/Response wrapper classes
- Show the mapping/transformation between upstream response -> normalized DTO -> API response

## 8. Normalization Logic (KEY FEATURE)
- How does this service normalize responses from different sources?
- Mapping rules between different service response formats
- Data transformation pipeline
- Any enrichment logic (combining data from multiple services)
- Caching strategy for normalized data

## 9. Configuration
- All `application.yml` / `application.properties` settings with descriptions
- Profile-specific configurations (dev, staging, prod)
- Environment variables
- External configuration sources (Config Server, Vault, etc.)

## 10. Security
- Authentication mechanism (JWT validation, OAuth2, API keys)
- Authorization rules (role-based access, endpoint-level security)
- CORS configuration
- Security filter chain

## 11. Build & Deployment
- Build commands (Maven/Gradle)
- Docker configuration
- Health check endpoints (`/actuator/health`)
- CI/CD pipeline summary
- Required infrastructure (MongoDB, Kafka, upstream services)

## 12. Current Status & Known Issues
- Features complete vs in-progress
- Known bugs or tech debt
- TODO/FIXME items in code
- Missing integrations or placeholder implementations
- Hardcoded values that should be configurable

## 13. Integration Touchpoints Summary
Create two tables:

**Downstream (APIs exposed to Dashboard Web):**
| Endpoint | Method | Purpose | Status | Notes |
|---|---|---|---|---|

**Upstream (APIs called to other services):**
| Target Service | Endpoint | Method | Purpose | Status | Notes |
|---|---|---|---|---|---|

**Kafka Topics:**
| Topic Name | Direction (Produce/Consume) | Payload Schema | Purpose | Status | Notes |
|---|---|---|---|---|---|

Scan the entire codebase. Look at:
- `pom.xml` / `build.gradle` for dependencies
- `src/main/java/` for all packages
- `src/main/resources/` for configuration
- `src/test/` for integration tests
- `Dockerfile` / `docker-compose.yml`
- Any `docs/` or `README.md`

Output the complete `information.md` file.
```

---

## Expected Output Location
`<repo-root>/information.md`

## Estimated Time
15-30 minutes

## Validation Checklist
- [ ] All REST endpoints documented with request/response schemas
- [ ] All upstream service dependencies listed with endpoints
- [ ] All Kafka topics listed (produce and consume) with schemas
- [ ] MongoDB collections and schemas documented
- [ ] Normalization logic explained
- [ ] Configuration and environment variables listed
- [ ] Integration touchpoints tables are complete
