# Agentic QA - Integration Project Artifacts

## Overview
This package contains **prompts and instructions** for 3 tasks to complete the integration of 5 microservices within a 2-week sprint.

## System Architecture

```
                    +------------------+
                    | Dashboard Web    |
                    | (ReactJS)        |
                    +--------+---------+
                             |
                             | REST APIs
                             v
                    +------------------+
                    | Dashboard Service|
                    | (Java)           |
                    +--------+---------+
                             |
              +--------------+--------------+
              |              |              |
              v              v              v
    +-----------+   +-----------+   +----------------+
    |  Prompt   |   |  QA-AI    |   |  Ingestion     |
    |  Mgmt     |   |  Service  |   |  Service       |
    |  (Java)   |   |  (Python) |   |  (Node.js)     |
    +-----------+   +-----+-----+   +-------+--------+
         |                |                  |
         +------+---------+------------------+
                |                   |
         +------v------+    +------v------+
         |   Kafka     |    |  MongoDB    |
         +-------------+    +-------------+
```

## How to Use These Artifacts

### Execution Order (IMPORTANT)

```
Task 1 (Day 1)          Task 2 (Day 1-2)         Task 3 (Day 2)
Each member runs     ->  Each member runs      ->  PM/Lead runs
their prompt in         their prompt with          with ALL files
their own repo          ALL information.md         from Task 1 & 2
                        files collected
```

### Step-by-Step

1. **Task 1 - Generate information.md** (Parallel - All 5 members simultaneously)
   - Each team member opens their repo in Claude Code
   - Runs the prompt from `task1-information-md-prompts/`
   - Reviews and commits the generated `information.md`
   - Shares `information.md` with the team (Slack/shared drive)

2. **Task 2 - Identify Integration Gaps** (Parallel - after ALL Task 1 complete)
   - Collect all 5 `information.md` files
   - Each team member runs their prompt from `task2-integration-gap-prompts/`
   - Reviews and commits the generated `integration-gaps.md`
   - Shares `integration-gaps.md` with the team

3. **Task 3 - Create Project Plan** (Sequential - PM/Lead runs this)
   - Collect all `information.md` and `integration-gaps.md` files (10 files total)
   - Run the prompt from `task3-project-plan/`
   - Review the generated `project-plan.md` with the team
   - Kick off the 2-week sprint

## File Structure

```
project-artifacts/
|-- README.md                              (this file)
|
|-- task1-information-md-prompts/          (Task 1: Generate information.md)
|   |-- 01-dashboard-web-prompt.md         (Member 1 - ReactJS)
|   |-- 02-dashboard-service-prompt.md     (Member 2 - Java)
|   |-- 03-prompt-management-prompt.md     (Member 3 - Java)
|   |-- 04-qa-ai-service-prompt.md         (Member 4 - Python)
|   |-- 05-ingestion-service-prompt.md     (Member 5 - Node.js)
|
|-- task2-integration-gap-prompts/         (Task 2: Find integration gaps)
|   |-- 01-dashboard-web-integration-prompt.md
|   |-- 02-dashboard-service-integration-prompt.md
|   |-- 03-prompt-management-integration-prompt.md
|   |-- 04-qa-ai-service-integration-prompt.md
|   |-- 05-ingestion-service-integration-prompt.md
|
|-- task3-project-plan/                    (Task 3: 2-week project plan)
|   |-- project-plan-prompt.md
```

## Team Assignment

| Member | Service | Tech Stack | Task 1 Prompt | Task 2 Prompt |
|--------|---------|------------|---------------|---------------|
| 1 | Dashboard Web | ReactJS | 01-dashboard-web | 01-dashboard-web-integration |
| 2 | Dashboard Service | Java | 02-dashboard-service | 02-dashboard-service-integration |
| 3 | Prompt Management | Java | 03-prompt-management | 03-prompt-management-integration |
| 4 | QA-AI Service | Python (Google ADK + Gemini Pro) | 04-qa-ai-service | 04-qa-ai-service-integration |
| 5 | Ingestion Service | Node.js (CRITICAL) | 05-ingestion-service | 05-ingestion-service-integration |

## Key Integration Points

| From | To | Mechanism | Priority |
|------|----|-----------|----------|
| Ingestion Service | QA-AI Service | Kafka | CRITICAL |
| Prompt Management | QA-AI Service | REST API + Kafka | HIGH |
| QA-AI Service | Dashboard Service | Kafka + REST API | HIGH |
| Dashboard Service | Dashboard Web | REST API | HIGH |
| Prompt Management | Dashboard Service | REST API | MEDIUM |
| Ingestion Service | Dashboard Service | Kafka (status) | MEDIUM |
