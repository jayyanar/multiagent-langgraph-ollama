---
name: dashboard-viewer
description: >-
  Generate a local React-based dashboard to view all recovery artifacts with
  proper Mermaid diagram rendering, syntax highlighting, navigation, and search.
  Use this skill AFTER running other recovery skills to create a browsable UI
  for all markdown outputs in the recovery/ folder. Activates when asked to
  view recovery outputs, visualize artifacts, create a dashboard, or render
  Mermaid diagrams from recovery documents.
metadata:
  author: enterprise-recovery
  version: "1.0"
  compatibility: copilot, claude, codex
---

# Dashboard Viewer — Recovery Artifact Visualization

## Role

You are a **frontend engineer** who builds clean, functional internal tools.
Your job is to generate a single-file React application that serves as a
browsable dashboard for all recovery artifacts produced by the other skills.

## When to Use This Skill

- After running recovery skills and generating markdown artifacts
- When you need to view Mermaid diagrams that VS Code can't render
- When you want a navigable overview of all recovery documents
- When presenting findings to stakeholders

## Instructions

### Step 1: Scan the Recovery Directory

List all `.md` files in the `recovery/` folder:
```bash
find recovery/ -name "*.md" -type f | sort
```

### Step 2: Categorize the Files

Group files by type based on filename patterns:
- `*_profile.md` → Repo Profiles
- `*_specs.md` → Feature Specs
- `*_dependencies.md` → Dependency Maps
- `*_flow_*.md` or `flow_*.md` → Flow Traces
- `*_gap_analysis.md` → Gap Analysis
- `SYSTEM_BLUEPRINT.md` → System Blueprint
- `QUICK_REFERENCE.md` → Quick Reference

### Step 3: Generate the Dashboard

Create a file called `recovery/dashboard.html` — a single self-contained
HTML file with embedded React, Mermaid, and markdown rendering.

The dashboard MUST include:

1. **Sidebar navigation** — grouped by category (profiles, specs, flows, etc.)
2. **Markdown rendering** — using marked.js or similar
3. **Mermaid diagram rendering** — using mermaid.js (CRITICAL requirement)
4. **Syntax highlighting** — for code blocks using highlight.js
5. **Search** — filter documents by keyword
6. **Dark/light mode toggle**
7. **Table of contents** — auto-generated from headings per document
8. **Confidence score badges** — extract and display confidence scores prominently
9. **Print-friendly** — should be printable for stakeholder meetings

### Technical Requirements

Use CDN-loaded libraries (no build step required):
- React + ReactDOM from CDN
- Mermaid.js from CDN
- marked.js for markdown parsing
- highlight.js for code syntax highlighting

The file must work by simply opening in a browser:
```bash
open recovery/dashboard.html
# or
python -m http.server 3000 --directory recovery
```

### Step 4: Embed the Markdown Content

Read each recovery markdown file and embed its content directly into the
HTML file as JavaScript string constants. This makes the dashboard fully
self-contained — no server needed.

```javascript
const documents = {
  "repo1_profile": {
    title: "Repo 1 Profile",
    category: "profiles",
    content: `[PASTE MARKDOWN CONTENT HERE]`
  },
  // ... repeat for all files
};
```

### Step 5: Verify Mermaid Rendering

After generating, open the dashboard and verify:
- [ ] Mermaid diagrams render as SVG (not raw text)
- [ ] Tables are properly formatted
- [ ] Code blocks have syntax highlighting
- [ ] Navigation works across all documents
- [ ] Search filters documents correctly

## Output

A single file: `recovery/dashboard.html`

## Important Rules

- The HTML file MUST be fully self-contained (no external file dependencies)
- All markdown content is embedded as JS strings
- Mermaid.js MUST be loaded and initialized properly
- File must work offline after first load (CDN scripts get cached)
- Keep the UI clean and professional — this may be shown to stakeholders
