---
name: capability-mapper
description: >-
  Map enterprise capability definitions to actual features implemented across
  multiple repositories. Takes three inputs: (1) a capability list (Excel/CSV
  or document), (2) an architecture diagram or description, and (3) one or more
  code repositories. Scans all repos to discover which features exist, then maps
  them to capabilities, identifies gaps, and produces a Capability-to-Feature
  Traceability Matrix with implementation status per repo. Use this skill for
  capability gap analysis, feature discovery, portfolio-level audit, or when
  inheriting a multi-repo system and needing to understand what's built vs planned.
  Activates when asked to map capabilities to features, discover what's built,
  assess feature coverage, or do capability gap analysis.
metadata:
  author: enterprise-recovery
  version: "1.0"
  compatibility: copilot, claude, codex
---

# Capability Mapper — Capability-to-Feature Discovery & Gap Analysis

## Role

You are an **enterprise architect and product strategist** who bridges the gap
between business capability planning and technical implementation. You think in
three layers simultaneously:

1. **Capability Layer** — What the business NEEDS (from capability list)
2. **Architecture Layer** — How the system is DESIGNED (from architecture diagram)
3. **Implementation Layer** — What is actually BUILT (from code repos)

Your job is to map across all three layers, find gaps, and produce a complete
traceability matrix that shows exactly where each capability stands.

## When to Use This Skill

- You have a capability list and need to know what's actually built
- You're inheriting a multi-repo system and need a portfolio-level view
- You need a gap analysis between planned capabilities and implementation
- You're preparing a stakeholder readout on delivery status
- Run this AFTER `repo-profiler` has been run on all repos

## Prerequisites

Three inputs required:

1. **Capability List** — Excel/CSV or document with capabilities defined.
   Expected columns or fields:
   - Capability ID or Name
   - Description
   - Current Status (if available)
   - Priority / Importance

2. **Architecture Diagram** — Image, document, or text description showing:
   - System components and their relationships
   - Service boundaries
   - Data flows
   - Technology stack per component

3. **Code Repositories** — One or more repos to scan. Ideally, `repo-profiler`
   outputs already exist in `recovery/` for each repo.

## Instructions

---

### STAGE 1: Parse and Structure the Capability Model

#### 1.1 — Load the Capability List

```bash
# Find capability files
find . -type f \( -name "*.xlsx" -o -name "*.csv" -o -name "*.md" -o -name "*.docx" \) | \
  grep -i "capabil\|feature\|roadmap\|foundational" | head -5
```

Read the file and normalize into a structured table. If the capability list
is provided verbally or in an image, transcribe it exactly.

#### 1.2 — Decompose Each Capability into Expected Features

For EACH capability, break it down into concrete, discoverable features that
SHOULD exist in code. This is the critical translation step.

Think: "If this capability is fully implemented, what code artifacts would I
expect to find?"

```markdown
# Capability Decomposition

## CAP-01: [Capability Name]
- **Description**: [from source]
- **Architecture Component**: [which part of architecture diagram this maps to]
- **Expected Features**:
  - F01.1: [feature] — Expected in: [repo/component]
  - F01.2: [feature] — Expected in: [repo/component]
  - F01.3: [feature] — Expected in: [repo/component]
- **Expected Code Signals** (what to search for):
  - Libraries: [specific packages that indicate this capability]
  - Patterns: [code patterns, class names, function names]
  - Files: [expected file names or paths]
  - Configs: [configuration entries]
  - APIs: [expected endpoints]
  - Data: [expected models, schemas, tables]
```

#### 1.3 — Map Capabilities to Architecture Components

Using the architecture diagram, assign each capability to one or more
architecture components:

```markdown
# Capability-to-Architecture Mapping

| Capability | Architecture Component(s) | Expected Repo(s) |
|-----------|--------------------------|-------------------|
| [cap name] | [component from diagram] | [which repo(s)] |
```

This creates the "expected state" — what SHOULD exist and WHERE.

**Save to**: `recovery/capability_model.md`

---

### STAGE 2: Architecture Diagram Analysis

#### 2.1 — Parse the Architecture Diagram

If an image is provided, extract and document:

1. **System pillars / swim lanes** — major groupings
2. **Components per pillar** — services, databases, agents, UIs
3. **Data flows** — arrows showing how data moves between components
4. **Technology annotations** — specific tech mentioned (Neo4j, Kafka, MongoDB, etc.)
5. **Status annotations** — any "In Prod", "In Dev", "TBD" labels
6. **Integration points** — MCP servers, APIs, message queues
7. **Feedback loops** — HITL, accuracy checks, validation gates

#### 2.2 — Reconstruct as Structured Text

```markdown
# Architecture Model

## System Pillars

### Pillar 1: [Name]
- **Status**: [In Prod / In Dev / TBD]
- **Purpose**: [what this pillar does]
- **Components**:
  | Component | Type | Technology | Status |
  |-----------|------|-----------|--------|
  | [name] | [Service/DB/Agent/UI] | [tech] | [status] |
- **Data Flow**: [describe inputs → processing → outputs]
- **Integration Points**: [APIs, queues, shared data]

### Pillar 2: [Name]
[same structure]

## Cross-Pillar Flows
| Flow | From | To | Mechanism | Data |
|------|------|----|-----------|------|
| [flow name] | [pillar/component] | [pillar/component] | [API/Kafka/DB] | [what's passed] |

## Technology Stack (consolidated)
| Technology | Usage | Component(s) |
|-----------|-------|--------------|
| [tech] | [purpose] | [where used] |
```

#### 2.3 — Map Architecture to Repos

Based on `repo-profiler` outputs (if available) or manual analysis, map each
architecture component to its implementing repository:

```markdown
# Architecture-to-Repo Mapping

| Architecture Component | Repo | Evidence | Confidence |
|-----------------------|------|----------|------------|
| [component] | [repo-name] | [how we know] | [HIGH/MED/LOW] |
| [component] | NOT FOUND | — | — |
```

**Save to**: `recovery/architecture_model.md`

---

### STAGE 3: Multi-Repo Feature Discovery

> **Goal**: Scan ALL repositories to discover every implemented feature,
> then match discoveries to expected features from the capability model.

#### 3.1 — Load Existing Repo Profiles

If `repo-profiler` has been run, load outputs:
```bash
ls recovery/*_profile.md 2>/dev/null
```

If not available, run a quick reconnaissance per repo (use repo-profiler patterns).

#### 3.2 — Feature Discovery Scans (per repo)

For each repository, run targeted scans based on the expected code signals
from Stage 1.2. Organize scans by capability.

**For each capability, search across all repos:**

```bash
# Template — adapt search terms per capability
# Search for capability-specific code patterns

# API endpoints (feature surfaces)
grep -rn "@app\.\|@router\.\|@api_view\|path(" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -30

# Service/business logic classes
grep -rn "class.*Service\|class.*Manager\|class.*Handler\|class.*Engine\|class.*Pipeline" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -20

# Agent definitions (for ADK-based capabilities)
grep -rn "Agent(\|LlmAgent\|SequentialAgent\|root_agent\|sub_agents" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -15

# MCP server/tool definitions
grep -rn "mcp\|MCP\|tool\(\|@tool\|FunctionTool\|Server(" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -15

# Data models / schemas
grep -rn "class.*Model\|class.*Schema\|class.*Base\)\|BaseModel\|Table(" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -20

# UI pages/routes (Next.js or React)
find . -path "*/pages/*" -o -path "*/app/*" -name "page.tsx" | sort | head -20

# Database/storage operations
grep -rn "neo4j\|Neo4j\|kafka\|Kafka\|mongo\|MongoDB\|redis\|Redis" \
  --include="*.py" --include="*.ts" --include="*.tsx" . | \
  grep -v node_modules | grep -v __pycache__ | head -15

# Configuration / feature flags
grep -rn "FEATURE_\|feature_flag\|toggle\|enable_\|disable_" \
  --include="*.py" --include="*.env*" --include="*.yaml" . | \
  grep -v __pycache__ | grep -v .venv | head -10

# Tests (reveal intended functionality)
find . -type f \( -name "test_*" -o -name "*_test.py" -o -name "*.test.ts" \) \
  -not -path '*/__pycache__/*' -not -path '*/.venv/*' | head -20

# README and docs (often describe features)
find . -name "README.md" -not -path '*/node_modules/*' | head -5
```

#### 3.3 — Capability-Specific Deep Scans

For each capability in your list, run targeted searches. Below are
scan templates for common enterprise capability types — adapt based
on your actual capability list:

**Agent Library / Reusable Components:**
```bash
grep -rn "class.*Agent\|def.*agent\|agent.*registry\|skill\|Skill\|domain.*agent" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -20
find . -type d -name "agents" -o -name "skills" -o -name "library" | head -10
```

**Observability / Monitoring Pipeline:**
```bash
grep -rn "metrics\|monitor\|observe\|insight\|telemetry\|prometheus\|grafana\|dashboard" \
  --include="*.py" --include="*.ts" . | grep -v __pycache__ | grep -v .venv | head -20
```

**Orchestration Engine:**
```bash
grep -rn "orchestrat\|pipeline\|workflow\|dag\|deterministic\|sequence\|step.*engine" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -20
```

**Ingestion / Data Pipeline:**
```bash
grep -rn "ingest\|extract\|transform\|load\|ETL\|pipeline\|SKAN\|skan\|parser\|scraper" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -20
```

**Code Generation / Studio:**
```bash
grep -rn "generat\|template\|scaffold\|codegen\|code.*gen\|render.*code\|studio" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -15
```

**HITL / User Interface:**
```bash
grep -rn "review\|approve\|reject\|human.*loop\|manual\|validate\|HITL\|hitl" \
  --include="*.py" --include="*.ts" --include="*.tsx" . | \
  grep -v __pycache__ | grep -v .venv | grep -v node_modules | head -20
find . -path "*/pages/*" -o -path "*/app/*" -o -path "*/views/*" | \
  grep -v node_modules | grep -v __pycache__ | head -15
```

**MCP / Data Integration:**
```bash
grep -rn "MCP\|mcp\|connector\|integration\|adapter\|SharePoint\|sharepoint\|ECM\|ecm" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -20
find . -type f -name "*.py" -path "*mcp*" -o -path "*connector*" -o -path "*integration*" | head -10
```

**QA / Deterministic Pipeline:**
```bash
grep -rn "qa\|QA\|quality\|accuracy\|validation\|deterministic\|assert\|verify\|check.*result" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | grep -v test | head -20
```

#### 3.4 — Build the Feature Inventory

Compile ALL discovered features across all repos:

```markdown
# Feature Inventory (Discovered from Code)

## Repo: [repo-1-name]

### Discovered Features
| Feature ID | Feature Name | Type | Evidence | Files |
|-----------|-------------|------|----------|-------|
| DF-R1-01 | [name] | [API/Service/Agent/UI/Pipeline] | [what was found] | [file paths] |
| DF-R1-02 | [name] | [type] | [evidence] | [files] |

### Discovered Technologies
| Technology | Usage | Files |
|-----------|-------|-------|
| [tech] | [what for] | [where] |

## Repo: [repo-2-name]
[same structure]

## Cross-Repo Features
| Feature | Repos Involved | Type | Description |
|---------|---------------|------|-------------|
| [feature] | [repo list] | [cross-cutting] | [how it spans repos] |
```

**Save to**: `recovery/feature_inventory.md`

---

### STAGE 4: Capability-to-Feature Mapping (The Core Output)

> **Goal**: Match every discovered feature to a capability, and identify
> which capabilities have gaps.

#### 4.1 — Build the Traceability Matrix

For each capability, evaluate:

| Status | Meaning |
|--------|---------|
| **FULLY IMPLEMENTED** | All expected features found and functional |
| **PARTIALLY IMPLEMENTED** | Some features found, others missing |
| **STUB / SCAFFOLDED** | Code structure exists but not functional |
| **NOT IMPLEMENTED** | No code evidence found |
| **OVER-IMPLEMENTED** | More features than expected (scope creep or undocumented) |
| **CANNOT DETERMINE** | Ambiguous — needs manual review |

```markdown
# Capability-to-Feature Traceability Matrix
> System: [system name]
> Repos Scanned: [list of repos]
> Date: [date]

## Executive Summary

| Metric | Count |
|--------|-------|
| Total Capabilities | [N] |
| Fully Implemented | [N] ([X]%) |
| Partially Implemented | [N] ([X]%) |
| Not Implemented | [N] ([X]%) |
| Stub / Scaffolded | [N] ([X]%) |

## Coverage by Architecture Pillar

| Pillar | Capabilities | Implemented | Partial | Not Started |
|--------|-------------|-------------|---------|-------------|
| [pillar 1] | [N] | [N] | [N] | [N] |
| [pillar 2] | [N] | [N] | [N] | [N] |

## Visual Coverage Map
```
CAP-01 Re-Usable Agent Library    [██░░░░░░░░] 20% — Partial
CAP-02 Observe to Insights        [░░░░░░░░░░]  0% — Not Started
CAP-03 Orchestration Engine        [████░░░░░░] 40% — Partial
CAP-04 SKAN Pipeline               [████████░░] 80% — Mostly Done
CAP-05 Code Generator Studio       [██░░░░░░░░] 20% — Stub
CAP-06 HITL UI                     [██████░░░░] 60% — Partial
CAP-07 MCP / Data Integration      [██████████] 100% — Complete
CAP-08 QA Deterministic Pipeline   [████░░░░░░] 40% — Partial
```

---

## Detailed Mapping

### CAP-01: [Capability Name]

**Description**: [from capability list]
**Architecture Component**: [from architecture diagram]
**Expected Repo(s)**: [where this should live]
**Status**: [FULLY | PARTIALLY | NOT | STUB]
**Overall Completion**: [X]%

#### Expected vs Found Features

| Expected Feature | Status | Repo | Evidence (file:line) | Notes |
|-----------------|--------|------|---------------------|-------|
| [feature 1] | FOUND | [repo] | `path/file.py:42` | [notes] |
| [feature 2] | PARTIAL | [repo] | `path/file.py:88` | [what's missing] |
| [feature 3] | NOT FOUND | — | — | [no evidence] |
| [feature 4] | STUB | [repo] | `path/file.py:10` | [has TODO/pass] |

#### Discovered but Unexpected Features
| Feature | Repo | Evidence | Possible Capability |
|---------|------|----------|-------------------|
| [feature] | [repo] | [file:line] | [which cap it might belong to] |

#### Technology Alignment
| Expected (from arch) | Found | Match? |
|---------------------|-------|--------|
| [expected tech] | [actual tech or "not found"] | [YES/NO/PARTIAL] |

#### Gap Summary
- **Missing**: [list what's not built]
- **Incomplete**: [list what's partially built]
- **Blocked by**: [dependencies on other capabilities]
- **Estimated effort to complete**: [S/M/L/XL]

---

### CAP-02: [Next Capability]
[same structure for EVERY capability]
```

**Save to**: `recovery/capability_traceability_matrix.md`

---

### STAGE 5: Gap Analysis Report

> **Goal**: Synthesize all findings into an actionable gap analysis
> with prioritized remediation.

```markdown
# Capability Gap Analysis Report
> System: [system name]
> Date: [date]

## 1. Portfolio Health Score

Overall Capability Delivery: [X]%

```mermaid
pie title Capability Implementation Status
    "Fully Implemented" : [N]
    "Partially Implemented" : [N]
    "Stub / Scaffolded" : [N]
    "Not Started" : [N]
```

## 2. Architecture Coverage

```mermaid
graph TB
    subgraph "Pillar 1: [Name] — [X]% Complete"
        A[Component A ✅]
        B[Component B ⚠️]
        C[Component C ❌]
    end
    subgraph "Pillar 2: [Name] — [X]% Complete"
        D[Component D ✅]
        E[Component E ❌]
    end
    A --> D
    B --> E
```

## 3. Critical Gaps (Must Fix)

| # | Capability | Gap | Business Impact | Effort | Priority |
|---|-----------|-----|-----------------|--------|----------|
| 1 | [cap] | [what's missing] | [impact] | [effort] | P0 |
| 2 | [cap] | [what's missing] | [impact] | [effort] | P0 |

## 4. Partial Implementations (Needs Completion)

| # | Capability | What Exists | What's Missing | Effort | Priority |
|---|-----------|------------|----------------|--------|----------|
| 1 | [cap] | [built parts] | [missing parts] | [effort] | P1 |

## 5. Undocumented Features (Found but No Capability)

| Feature | Repo | Description | Suggested Capability |
|---------|------|-------------|---------------------|
| [feature] | [repo] | [what it does] | [where it might belong] |

## 6. Dependency Chain

Show which capabilities block other capabilities:

```mermaid
graph LR
    CAP01[CAP-01: Agent Library] --> CAP03[CAP-03: Orchestration]
    CAP04[CAP-04: SKAN Pipeline] --> CAP01
    CAP07[CAP-07: MCP Integration] --> CAP03
    CAP03 --> CAP08[CAP-08: QA Pipeline]
    CAP06[CAP-06: HITL UI] --> CAP05[CAP-05: Code Generator]
```

## 7. Repo Contribution Matrix

Which repos contribute to which capabilities:

| Repo | CAP-01 | CAP-02 | CAP-03 | CAP-04 | CAP-05 | CAP-06 | CAP-07 | CAP-08 |
|------|--------|--------|--------|--------|--------|--------|--------|--------|
| repo-1 | ✅ | — | ⚠️ | ✅ | — | — | — | — |
| repo-2 | — | — | — | — | ⚠️ | ✅ | — | — |
| repo-3 | — | ❌ | ✅ | — | — | — | ✅ | ⚠️ |
| repo-4 | — | — | — | — | — | — | — | — |
| repo-5 | ⚠️ | — | — | — | — | ⚠️ | ⚠️ | — |

Legend: ✅ = Primary, ⚠️ = Partial/Supporting, ❌ = Expected but missing, — = Not applicable

## 8. Recommended Delivery Sequence

Based on dependencies and gaps:

### Wave 1: Foundation Capabilities (unblocks everything else)
| Capability | Current | Target | Effort | Repos Involved |
|-----------|---------|--------|--------|---------------|
| [cap] | [X]% | 100% | [days] | [repos] |

### Wave 2: Core Capabilities
[same format]

### Wave 3: Advanced Capabilities
[same format]

## 9. Risk Assessment

| Risk | Severity | Affected Capabilities | Mitigation |
|------|----------|----------------------|------------|
| [risk] | [HIGH/MED/LOW] | [caps] | [action] |

## 10. Stakeholder Summary

**For Engineering**: [2-3 sentences on what to build next]
**For Product**: [2-3 sentences on delivery status vs plan]
**For Leadership**: [2-3 sentences on overall health and timeline]
```

**Save to**: `recovery/capability_gap_analysis.md`

---

### STAGE 6: Generate Per-Capability Task Backlogs

> **Goal**: For each capability that has gaps, produce a concrete task
> list that developers can execute.

```markdown
# Capability Remediation Tasks
> Generated from: Capability Gap Analysis

## CAP-[XX]: [Capability Name]
**Current completion**: [X]%
**Target**: 100%
**Estimated total effort**: [X days]

### Task Backlog

#### TASK-CAP[XX]-001: [Task Title]
- **Type**: [New Feature | Complete Partial | Fix | Refactor]
- **Repo**: [target repo]
- **Priority**: [P0/P1/P2]
- **Effort**: [Small <1hr | Medium 1-4hr | Large 4-8hr | XL >8hr]
- **Blocked by**: [other tasks or capabilities, or "none"]
- **Description**: [what needs to be built or fixed]
- **Expected files**:
  | File | Action | Purpose |
  |------|--------|---------|
  | [path] | CREATE / MODIFY | [what to do] |
- **Acceptance Criteria**:
  - [ ] [criterion 1]
  - [ ] [criterion 2]
- **Architecture reference**: [which arch component this implements]

#### TASK-CAP[XX]-002: [Next Task]
[same structure]
```

**Save to**: `recovery/capability_tasks.md`

---

## Complete Output List

This skill produces 5 documents:

| # | Document | Purpose | Filename |
|---|----------|---------|----------|
| 1 | Capability Model | Decomposed capabilities with expected features | `capability_model.md` |
| 2 | Architecture Model | Structured representation of architecture diagram | `architecture_model.md` |
| 3 | Feature Inventory | All features discovered across all repos | `feature_inventory.md` |
| 4 | Traceability Matrix | Capability → Feature mapping with status | `capability_traceability_matrix.md` |
| 5 | Gap Analysis Report | Gaps, dependencies, risks, delivery sequence | `capability_gap_analysis.md` |
| 6 | Task Backlogs | Per-capability remediation tasks | `capability_tasks.md` |

## Important Rules

- ALWAYS decompose capabilities into concrete, searchable features BEFORE scanning code.
- ALWAYS map capabilities to architecture components BEFORE scanning repos.
- Search ALL repos for each capability — features may be split across repos.
- Report UNDOCUMENTED features (found in code but not in any capability) — these often represent scope creep or informal work.
- Include the Architecture Pillar status (Prod/Dev/TBD) in all outputs.
- Use Mermaid diagrams for architecture visualization and dependency chains.
- The Repo Contribution Matrix is CRITICAL for stakeholder communication — always produce it.
- When a capability is "TBD" in the source, still search repos — there may be early work.
- Flag capabilities that BLOCK other capabilities in the dependency chain.
- Save ALL outputs to the `recovery/` folder.
- Cross-reference with `repo-profiler` outputs when available.
- When scanning, search for both the EXACT terms from the capability list AND related synonyms — developers may have used different naming.
