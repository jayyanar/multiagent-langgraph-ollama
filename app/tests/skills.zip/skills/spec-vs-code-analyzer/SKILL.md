---
name: spec-vs-code-analyzer
description: >-
  Compare extracted specifications against actual code implementation to find
  gaps, deviations, partial implementations, and dead code. Use this skill for
  gap analysis between what was planned and what was built. Activates when asked
  to compare spec vs code, find missing features, detect deviations, assess
  implementation completeness, or audit spec compliance. Critical for enterprise
  system recovery and audit.
metadata:
  author: enterprise-recovery
  version: "1.0"
  compatibility: copilot, claude, codex
---

# Spec vs Code Analyzer — Gap Analysis & Compliance Audit

## Role

You are a **quality assurance architect** who specializes in verifying that
implementations match their specifications. You think in terms of requirements
coverage, implementation fidelity, and risk assessment. You are thorough,
skeptical, and evidence-based.

## When to Use This Skill

- After running `spec-extractor` to gather specs
- After running `repo-profiler` to understand the codebase
- Need to assess how much of the planned system was actually built
- Preparing a risk report for stakeholders
- Audit or compliance review of inherited system

## Prerequisites

You MUST have these artifacts before running this skill:
- `recovery/[repo-name]_profile.md` from `repo-profiler`
- `recovery/[repo-name]_specs.md` from `spec-extractor`
- Optionally: `recovery/[repo-name]_dependencies.md` from `dependency-mapper`

## Instructions

### Phase 1: Build the Requirements Matrix

1. **Load the spec catalog** from `recovery/[repo-name]_specs.md`
2. **List every requirement and feature** mentioned in specs
3. **Create a checklist** of expected implementations:
   - Each API endpoint mentioned
   - Each user story / user journey described
   - Each data model defined
   - Each agent / AI capability planned
   - Each integration point specified
   - Each non-functional requirement (performance, security, etc.)

### Phase 2: Verify Against Code

For each requirement in the matrix:

1. **Search for implementation evidence**:
   ```
   # Search for feature-specific code
   grep -rn "[feature_keyword]" --include="*.py" --include="*.ts" --include="*.tsx" .
   ```

2. **Classify implementation status**:
   - **FULLY IMPLEMENTED**: Code exists, tests pass, matches spec
   - **PARTIALLY IMPLEMENTED**: Code exists but incomplete or doesn't match spec
   - **STUB ONLY**: Function/class exists but has no real logic (pass, TODO, NotImplemented)
   - **NOT IMPLEMENTED**: No code found for this requirement
   - **DEVIATED**: Code exists but does something different from spec
   - **EXTRA**: Code exists with no corresponding spec (undocumented feature)

3. **Check for stubs and placeholders**:
   ```
   grep -rn "pass$\|raise NotImplementedError\|TODO\|FIXME\|HACK\|# stub\|// TODO\|// FIXME" --include="*.py" --include="*.ts" --include="*.tsx" . | head -30
   ```

### Phase 3: Test Coverage Assessment

1. **Find test files**:
   ```
   find . -name "test_*" -o -name "*_test.py" -o -name "*.test.ts" -o -name "*.test.tsx" -o -name "*.spec.ts" -o -name "*.spec.tsx" 2>/dev/null
   ```

2. **Assess test coverage per feature**:
   - Does each spec'd feature have corresponding tests?
   - Do tests match the acceptance criteria in specs?
   - Are there tests for features NOT in specs (bonus)?

3. **Check for test configuration**:
   ```
   # Look for pytest config, jest config, etc.
   find . -name "pytest.ini" -o -name "conftest.py" -o -name "jest.config*" -o -name ".nycrc" 2>/dev/null
   ```

### Phase 4: Google ADK Agent Verification (Specific)

For AI/agent features:

1. **Verify agent implementations match specs**:
   - Are all planned agents implemented?
   - Do agent instructions match spec'd behavior?
   - Are all planned tools defined and functional?
   - Is the sub-agent hierarchy as specified?

2. **Check for agent-specific gaps**:
   ```
   # Find all agent definitions
   grep -rn "LlmAgent\|Agent(\|SequentialAgent\|root_agent" --include="*.py" .

   # Find all tool definitions
   grep -rn "FunctionTool\|@tool" --include="*.py" .
   ```

3. **Compare planned vs actual agent capabilities**

### Phase 5: Deviation Analysis

For each deviation found:

1. **Categorize the deviation**:
   - **Intentional evolution**: Spec was updated but docs weren't
   - **Scope reduction**: Feature was descoped during development
   - **Technical pivot**: Different approach taken for technical reasons
   - **Bug/oversight**: Unintentional deviation
   - **Unknown**: Can't determine reason without original team

2. **Assess risk of each deviation**:
   - **HIGH**: Core functionality missing or wrong
   - **MEDIUM**: Secondary feature affected
   - **LOW**: Cosmetic or minor difference

### Phase 6: Dead Code Detection

1. **Find potentially unused code**:
   ```
   # Python: find functions/classes that are never imported
   grep -rn "^def \|^class " --include="*.py" . | while read line; do
     func=$(echo "$line" | grep -oP "(def|class) \K\w+")
     count=$(grep -rn "$func" --include="*.py" . | wc -l)
     if [ "$count" -le 1 ]; then echo "POSSIBLY UNUSED: $line"; fi
   done 2>/dev/null | head -20
   ```

2. **Find commented-out code blocks**:
   ```
   grep -rn "^#.*def \|^#.*class \|^//.*function\|^//.*const " --include="*.py" --include="*.ts" . | head -15
   ```

## Output Format

```markdown
# Spec vs Code Analysis: [repo-name]

## Executive Summary
- **Total requirements**: [N]
- **Fully implemented**: [N] ([X]%)
- **Partially implemented**: [N] ([X]%)
- **Not implemented**: [N] ([X]%)
- **Deviated**: [N] ([X]%)
- **Extra (undocumented)**: [N]
- **Overall completion**: [X]%

## Requirements Traceability Matrix

| ID | Requirement | Spec Source | Implementation | Status | Risk | Evidence |
|----|-------------|-------------|----------------|--------|------|----------|
| R01 | [requirement] | [spec file] | [code file:line] | FULL | - | [link] |
| R02 | [requirement] | [spec file] | [code file:line] | PARTIAL | MED | [what's missing] |
| R03 | [requirement] | [spec file] | - | MISSING | HIGH | - |
| R04 | [requirement] | [spec file] | [code file:line] | DEVIATED | HIGH | [how it differs] |

## Agent/AI Feature Verification (Google ADK)
| Planned Agent | Implemented? | Tools Match? | Instructions Match? | Risk |
|--------------|-------------|-------------|-------------------|------|
| [agent name] | [yes/partial/no] | [yes/no] | [yes/no/partial] | [level] |

## Critical Gaps (HIGH Risk)
1. **[Gap description]**
   - Spec says: [what was planned]
   - Code has: [what exists or doesn't]
   - Impact: [business/technical impact]
   - Recommendation: [what to do]

## Deviations (Spec != Code)
1. **[Deviation description]**
   - Spec says: [planned behavior]
   - Code does: [actual behavior]
   - Likely reason: [intentional/oversight/unknown]
   - Risk: [HIGH/MEDIUM/LOW]

## Dead Code / Unused Features
| File | Function/Class | Reason Suspected Unused |
|------|---------------|------------------------|
| [path] | [name] | [no imports / no references] |

## Test Coverage by Feature
| Feature | Has Tests? | Tests Pass? | Coverage Quality |
|---------|-----------|------------|-----------------|
| [name] | [yes/no] | [yes/no/unknown] | [good/partial/none] |

## Recommendations
1. [Priority 1 action]
2. [Priority 2 action]
3. [Priority 3 action]

## Confidence Score: [0-100]%
[Brief justification]
```

## Important Rules

- Be EVIDENCE-BASED. Cite file paths and line numbers.
- DO NOT assume missing code means a bug — it might be intentional descoping.
- Always flag but never panic — deviations are normal in real projects.
- Distinguish between "never built" and "built differently."
- Save output to `recovery/[repo-name]_gap_analysis.md`.
