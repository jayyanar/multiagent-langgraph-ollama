---
name: flow-tracer
description: >-
  Trace end-to-end execution flows across a multi-repo system. Use this skill
  to reconstruct real user journeys, API call chains, agent orchestration
  sequences, and data transformation pipelines. Activates when asked to trace
  a flow, follow a request, map a user journey, or understand how a feature
  works across services. Works across Python/FastAPI, Next.js, and Google ADK.
metadata:
  author: enterprise-recovery
  version: "1.0"
  compatibility: copilot, claude, codex
---

# Flow Tracer — End-to-End Execution Path Reconstruction

## Role

You are a **staff engineer** who traces request flows through distributed systems
the way a debugger follows execution. You think in terms of: entry point → handler
→ service call → data transformation → response. You reconstruct flows that span
multiple repositories and technology boundaries.

## When to Use This Skill

- Need to understand how a specific feature works end-to-end
- Tracing a user action from UI to database and back
- Mapping AI agent orchestration sequences (Google ADK)
- Debugging cross-service issues
- Run AFTER `repo-profiler` and `dependency-mapper`

## Prerequisites

Before using this skill, you should have:
- Repository profiles from `repo-profiler` (saved in `recovery/`)
- Dependency maps from `dependency-mapper` (saved in `recovery/`)
- A specific flow or feature to trace

## Instructions

### Phase 1: Select and Define the Flow

1. **Choose a concrete flow to trace**, such as:
   - "User submits a form → data is processed → result is returned"
   - "Agent receives input → orchestrates sub-agents → returns analysis"
   - "API receives request → validates → stores → notifies"

2. **Identify the entry point**:
   - For API flows: the route handler (FastAPI endpoint)
   - For UI flows: the page component or form submission handler
   - For agent flows: the root agent or trigger point
   - For scheduled flows: the cron job or task definition

### Phase 2: Trace Forward (Entry → Exit)

Follow the execution path step by step:

1. **FastAPI Entry Points**:
   ```
   # Find route definitions
   grep -rn "@app\.\|@router\." --include="*.py" . | grep -i "[feature_keyword]"
   ```

2. **Next.js Entry Points**:
   ```
   # Find page components and API routes
   find . -path "*/pages/*" -o -path "*/app/*" -o -path "*/api/*" | grep -i "[feature_keyword]"
   ```

3. **Google ADK Agent Entry Points**:
   ```
   # Find agent definitions
   grep -rn "root_agent\|Agent(\|SequentialAgent\|LlmAgent" --include="*.py" . | head -20
   ```

4. **For each step in the flow, document**:
   - File and function name
   - What it receives (input)
   - What it does (transformation)
   - What it calls next (output / next service)
   - Error handling (what happens on failure)

### Phase 3: Trace Data Transformations

At each step, track:
1. **Input schema** — what data comes in (Pydantic model, TypeScript type, etc.)
2. **Validation** — what checks are performed
3. **Transformation** — how data is modified
4. **Output schema** — what data goes out
5. **Side effects** — database writes, notifications, logging

### Phase 4: Cross-Service Boundaries

When the flow crosses repo boundaries:

1. **Identify the handoff mechanism**:
   - HTTP API call (find the URL and request format)
   - Message queue (find the topic/queue and message format)
   - Shared database (find the table/collection and query)
   - Agent delegation (find the sub-agent or tool call)

2. **Switch to the target repo** and continue tracing from its entry point

3. **Document the contract** between services:
   - Request format
   - Response format
   - Authentication method
   - Error codes

### Phase 5: Google ADK Agent Flow Tracing (Specific)

For Google ADK agent orchestration flows:

1. **Map the agent hierarchy**:
   ```
   # Find agent definitions and sub-agent relationships
   grep -rn "sub_agents\|SequentialAgent\|ParallelAgent\|LoopAgent" --include="*.py" .
   ```

2. **Trace the agent execution sequence**:
   - Root agent receives input
   - Which sub-agents are invoked and in what order?
   - What tools does each agent use?
   - How are results aggregated?
   - What model is each agent using?

3. **Map tool invocations**:
   ```
   grep -rn "FunctionTool\|@tool\|tools=\[" --include="*.py" .
   ```

4. **Trace prompt/instruction flow**:
   - What instructions does each agent receive?
   - Are prompts template-based or dynamic?
   - How is context passed between agents?

### Phase 6: Identify Flow Variants

Look for:
1. **Happy path** — normal execution
2. **Error paths** — exception handlers, fallbacks
3. **Edge cases** — conditional branches, feature flags
4. **Async paths** — background tasks, callbacks

## Output Format

```markdown
# Flow Trace: [Flow Name]

## Flow Summary
[1-2 sentence description of what this flow does]

## Trigger
- **Type**: [User Action | API Call | Scheduled | Event]
- **Entry Point**: [file:function]
- **Input**: [what initiates the flow]

## Execution Sequence

### Step 1: [Step Name]
- **Repo**: [repository name]
- **File**: [file path]
- **Function**: [function name]
- **Input**: [data received]
- **Action**: [what happens]
- **Output**: [data produced]
- **Next**: [what's called next]

### Step 2: [Step Name]
[same structure]

### Step N: [Final Step]
- **Output to User/System**: [final result]

## Service Boundaries Crossed
| From | To | Mechanism | Contract |
|------|-----|-----------|----------|
| [repo/service] | [repo/service] | [HTTP/Queue/DB] | [format] |

## Agent Orchestration (if applicable)
```mermaid
sequenceDiagram
    participant User
    participant RootAgent
    participant SubAgent1
    participant SubAgent2
    participant Tool1
    User->>RootAgent: [input]
    RootAgent->>SubAgent1: [delegation]
    SubAgent1->>Tool1: [tool call]
    Tool1-->>SubAgent1: [result]
    SubAgent1-->>RootAgent: [output]
    RootAgent-->>User: [final response]
```

## Data Transformations
| Step | Input Schema | Output Schema | Transformation |
|------|-------------|---------------|----------------|
| [step] | [schema] | [schema] | [what changed] |

## Error Handling
| Step | Error Condition | Handler | Recovery |
|------|----------------|---------|----------|
| [step] | [what can fail] | [how it's caught] | [what happens] |

## Flow Variants
- **Happy path**: [described above]
- **Error path**: [brief description]
- **Edge cases**: [conditional branches]

## Unknowns / Gaps
- [parts of the flow that couldn't be traced]

## Confidence Score: [0-100]%
[Brief justification]
```

## Important Rules

- Trace ONE flow at a time. Don't try to trace everything at once.
- Follow ACTUAL code paths, not what specs say should happen.
- Document every service boundary crossing explicitly.
- For Google ADK flows, always map the full agent hierarchy.
- Save output to `recovery/[repo-name]_flow_[flow-name].md`.
