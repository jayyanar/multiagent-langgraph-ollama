# System Recovery Pipeline — Orchestration Guide

> **Purpose**: Step-by-step instructions for using the 6 Agent Skills to
> reverse-engineer a multi-repo system when the original team is unavailable.
>
> **Stack**: Python/FastAPI + Next.js + Google ADK
> **Tool**: GitHub Copilot Agent Mode (VS Code) with Opus model

---

## Setup

### 1. Install the Skills

Copy the entire `skills/` folder into your workspace:

```
# Option A: Project-level (recommended for team use)
cp -r skills/ .github/skills/

# Option B: Personal-level (your machine only)
cp -r skills/ ~/.copilot/skills/
```

### 2. Create the Output Directory

```bash
mkdir -p recovery
```

All skill outputs will be saved here, and downstream skills read from here.

### 3. Verify Skills Are Loaded

In VS Code, open Copilot Agent Mode and type:
```
/repo-profiler
```
If the skill is found, you're ready. If not, check that the directory names
match the `name:` field in each SKILL.md.

---

## Pipeline Execution

### Run Order (This Matters)

```
Phase 1 (per repo, parallelizable):
  repo-profiler → spec-extractor → dependency-mapper

Phase 2 (cross-repo, sequential):
  flow-tracer → spec-vs-code-analyzer

Phase 3 (synthesis):
  doc-generator
```

---

### Phase 1: Per-Repository Analysis

Run these three skills against EACH of your 5 repos. You can run them in
parallel across repos, but within each repo run them in order.

#### Step 1.1: Repo Profiler

Open the repo in VS Code. In Copilot Agent Mode:

```
/repo-profiler

Analyze this repository. The original team has left the company.
Save output to recovery/[repo-name]_profile.md
```

**Expected output**: `recovery/[repo-name]_profile.md`
**Time**: ~2-5 minutes per repo

#### Step 1.2: Spec Extractor

Same repo, same VS Code window:

```
/spec-extractor

Extract all spec-driven development artifacts from this repository.
Use the repo profile from recovery/[repo-name]_profile.md for context.
Save output to recovery/[repo-name]_specs.md
```

**Expected output**: `recovery/[repo-name]_specs.md`
**Time**: ~3-5 minutes per repo

#### Step 1.3: Dependency Mapper

Same repo, same VS Code window:

```
/dependency-mapper

Map all dependencies for this repository — internal modules,
external services, data stores, and AI/agent connections.
Use the repo profile from recovery/[repo-name]_profile.md for context.
Save output to recovery/[repo-name]_dependencies.md
```

**Expected output**: `recovery/[repo-name]_dependencies.md`
**Time**: ~3-5 minutes per repo

#### Phase 1 Checkpoint

After running Phase 1 on all 5 repos, you should have 15 files:

```
recovery/
  repo1_profile.md
  repo1_specs.md
  repo1_dependencies.md
  repo2_profile.md
  repo2_specs.md
  repo2_dependencies.md
  ... (same for repos 3, 4, 5)
```

**Quick validation**: Open each file and check the Confidence Score.
Anything below 50% means you should re-run with more specific prompts.

---

### Phase 2: Cross-Repository Analysis

Now you need cross-repo context. The best approach is to have all
recovery files accessible in a single workspace.

#### Step 2.1: Flow Tracer

Pick 2-3 core user flows to trace. Good candidates:
- The main user-facing workflow (e.g., "user submits request → gets result")
- The primary AI/agent flow (e.g., "agent receives input → orchestrates → responds")
- A data pipeline flow (e.g., "data ingested → processed → stored")

```
/flow-tracer

Trace the following flow end-to-end across all repositories:
[describe the flow in 1-2 sentences]

Use the recovery artifacts in recovery/ for context.
Save output to recovery/flow_[flow-name].md
```

**Repeat for each flow you want to trace.**
**Expected output**: `recovery/flow_[name].md` (one per flow)
**Time**: ~5-10 minutes per flow

#### Step 2.2: Spec vs Code Analyzer

Run this against each repo that has specs:

```
/spec-vs-code-analyzer

Compare the specs in recovery/[repo-name]_specs.md against the
actual code implementation in this repository.
Use recovery/[repo-name]_profile.md for structural context.
Save output to recovery/[repo-name]_gap_analysis.md
```

**Expected output**: `recovery/[repo-name]_gap_analysis.md`
**Time**: ~5-8 minutes per repo

---

### Phase 3: Synthesis

#### Step 3.1: Doc Generator (Final Step)

With all artifacts gathered:

```
/doc-generator

Synthesize all recovery artifacts in recovery/ into a comprehensive
system blueprint. Read every file in recovery/ before generating.

Produce:
1. SYSTEM_BLUEPRINT.md — full enterprise documentation
2. QUICK_REFERENCE.md — one-page summary

Save to recovery/
```

**Expected output**:
- `recovery/SYSTEM_BLUEPRINT.md`
- `recovery/QUICK_REFERENCE.md`

**Time**: ~10-15 minutes

---

## Timeline Estimate

| Phase | Scope | Time per Repo | Total (5 repos) |
|-------|-------|---------------|-----------------|
| Phase 1 | Per-repo analysis | 10-15 min | 50-75 min (or 15 min parallel) |
| Phase 2 | Cross-repo flows | 10-20 min | 30-50 min |
| Phase 2 | Gap analysis | 5-8 min | 25-40 min |
| Phase 3 | Synthesis | N/A | 10-15 min |
| **Total** | | | **~2-3 hours** |

If you run Phase 1 in parallel across repos (5 VS Code windows),
you can finish Phase 1 in ~15 minutes.

---

## Tips for Best Results

### Prompt Engineering

When invoking a skill, always:
1. **State the context**: "The original team has left"
2. **Reference prior outputs**: "Use recovery/[file] for context"
3. **Be specific about output**: "Save to recovery/[filename].md"

### Handling Large Repos

If a repo is too large for single-pass analysis:
1. Ask Copilot to focus on a specific directory first
2. Run the skill multiple times on different modules
3. Merge outputs manually or with doc-generator

### When Confidence Is Low

If a skill returns a confidence score below 50%:
1. Re-run with more specific focus areas
2. Try different search patterns
3. Check if important files are in unusual locations
4. Note the low confidence for stakeholder communication

### Google ADK Specifics

For repos with Google ADK agents:
- Always run flow-tracer specifically on agent flows
- Pay attention to sub-agent hierarchies
- Map tool definitions carefully — these define agent capabilities
- Check for shared prompt templates across agents

---

## After Recovery: Next Steps

1. **Validate by running the system** — docs are theory, runtime is truth
2. **Share SYSTEM_BLUEPRINT.md with stakeholders** for review
3. **Prioritize gaps** from gap analysis for remediation
4. **Set up proper documentation** going forward using these skills as templates
5. **Version-control all recovery artifacts** in a dedicated repo or branch
