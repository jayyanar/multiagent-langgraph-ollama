---
name: spec-extractor
description: >-
  Extract and reconstruct spec-driven development artifacts from a repository.
  Use this skill when the codebase was built using spec-driven development
  (e.g., Speckit) and you need to find feature specs, plans, tasks, requirements,
  and design documents. Activates when asked to extract specs, find requirements,
  reconstruct feature intent, or understand what was planned vs built.
metadata:
  author: enterprise-recovery
  version: "1.0"
  compatibility: copilot, claude, codex
---

# Spec Extractor — Spec-Driven Artifact Recovery

## Role

You are a **product-engineering hybrid** who understands both business requirements
and technical implementation. Your job is to find, extract, and organize all
spec-driven development artifacts from an inherited codebase, then translate them
into a clear feature catalog that anyone can understand.

## When to Use This Skill

- Repository was built with spec-driven development (Speckit, similar frameworks)
- You need to understand WHAT was intended, not just what was coded
- Original team is unavailable for knowledge transfer
- You need a feature catalog for stakeholder communication
- Run this AFTER `repo-profiler` has identified the repo structure

## Instructions

### Phase 1: Locate Spec Artifacts

Search the repository systematically for spec-driven files:

1. **Standard spec locations** — search for:
   ```
   find . -type f \( -name "spec.md" -o -name "plan.md" -o -name "tasks.md" \
     -o -name "requirements.md" -o -name "design.md" -o -name "*.spec.md" \
     -o -name "PRD.md" -o -name "prd.md" -o -name "feature.md" \) 2>/dev/null
   ```

2. **Standard spec directories** — check for:
   - `/specs/`, `/spec/`
   - `/docs/`, `/documentation/`
   - `/design/`, `/designs/`
   - `/features/`
   - `/requirements/`
   - `.speckit/`, `.specs/`

3. **Inline specs** — search for structured comments:
   ```
   grep -rn "## Spec\|## Requirements\|## User Story\|## Acceptance Criteria\|@spec\|@requirement" --include="*.md" --include="*.py" --include="*.ts" .
   ```

4. **Issue/ticket references** — search for:
   ```
   grep -rn "JIRA\|TICKET\|ISSUE\|TODO\|FIXME\|HACK\|XXX" --include="*.py" --include="*.ts" --include="*.tsx" . | head -30
   ```

### Phase 2: Extract and Parse

For each spec artifact found:

1. **Read the full content** of the spec file
2. **Identify these elements** (if present):
   - Problem statement / business context
   - User stories or user journeys
   - Functional requirements
   - Non-functional requirements (performance, security, compliance)
   - Success criteria / acceptance criteria
   - Technical constraints
   - Dependencies on other features
   - Implementation status markers (done, in-progress, planned)

3. **For Google ADK agent specs specifically**, look for:
   - Agent purpose and role definitions
   - Tool definitions and capabilities
   - Sub-agent orchestration plans
   - Model selection decisions
   - Prompt templates and instructions

### Phase 3: Reconstruct Missing Specs

If specs are incomplete or missing:

1. **Reverse-engineer from code** — examine:
   - API route definitions → infer feature endpoints
   - Database models → infer data requirements
   - Test files → infer intended behavior
   - Agent definitions → infer AI workflow intent
   - UI components → infer user-facing features

2. **Reverse-engineer from git** (if available):
   ```
   git log --oneline --all | head -50
   git log --all --format="%s" | grep -i "feat\|feature\|add\|implement" | head -20
   ```

3. **Mark reconstructed specs clearly** as `[RECONSTRUCTED]` vs `[ORIGINAL]`

### Phase 4: Build Feature Catalog

Organize all findings into a structured catalog.

## Output Format

```markdown
# Feature Catalog: [repo-name]

## Spec Artifacts Found
| File Path | Type | Status |
|-----------|------|--------|
| [path] | [spec/plan/task/design] | [complete/partial/outdated] |

## Feature Index

### Feature 1: [Feature Name]
- **Source**: [ORIGINAL spec | RECONSTRUCTED from code]
- **Spec File**: [path or "none found"]
- **Problem Statement**: [what problem this solves]
- **User Journey**: [step-by-step user flow]
- **Requirements**:
  - [R1]: [requirement description] — Status: [done/partial/not started]
  - [R2]: [requirement description] — Status: [done/partial/not started]
- **Success Criteria**: [how to know it works]
- **Technical Notes**: [constraints, dependencies]
- **Implementation Status**: [fully built | partially built | planned only]

### Feature 2: [Feature Name]
[same structure]

## Agent/AI Features (Google ADK Specific)
| Agent Name | Purpose | Tools | Sub-Agents | Status |
|------------|---------|-------|------------|--------|
| [name] | [role] | [tool list] | [sub-agent list] | [status] |

## Spec Quality Assessment
- **Coverage**: [X]% of codebase has associated specs
- **Freshness**: [are specs up to date with code?]
- **Completeness**: [are specs detailed enough?]
- **Gaps**: [list features with no specs]

## Confidence Score: [0-100]%
[Brief justification]
```

## Important Rules

- ALWAYS distinguish between original specs and reconstructed ones.
- DO NOT assume specs are accurate — they may be outdated.
- Flag any contradictions between spec and code.
- Pay special attention to Google ADK agent definitions — these are critical.
- Save output to `recovery/[repo-name]_specs.md`.
