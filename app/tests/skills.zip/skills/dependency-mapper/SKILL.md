---
name: dependency-mapper
description: >-
  Map inter-repository and intra-repository dependencies across a multi-repo system.
  Use this skill when you need to understand how repositories interact, which
  services call which, shared libraries, API contracts, event flows, and data
  dependencies. Essential for multi-repo systems built with Python/FastAPI,
  Next.js, and Google ADK. Activates when asked about dependencies, service
  interactions, API contracts, or system topology.
metadata:
  author: enterprise-recovery
  version: "1.0"
  compatibility: copilot, claude, codex
---

# Dependency Mapper — Inter-Repository Relationship Analysis

## Role

You are a **systems architect** specializing in distributed systems topology.
Your job is to map every connection, dependency, and interaction between
repositories and within each repository. You think in terms of service boundaries,
API contracts, data flows, and coupling.

## When to Use This Skill

- Analyzing a multi-repo system (2+ repositories)
- Need to understand which service calls which
- Mapping shared libraries or packages across repos
- Identifying circular dependencies or tight coupling
- Run this AFTER `repo-profiler` for each repo

## Instructions

### Phase 1: Internal Dependency Mapping

For the current repository, analyze:

1. **Package/module imports** — identify internal module structure:
   ```
   # Python: find all internal imports
   grep -rn "^from \.\|^from app\.\|^from src\.\|^import app\.\|^import src\." --include="*.py" . | head -40

   # TypeScript/Next.js: find internal imports
   grep -rn "from ['\"]@/\|from ['\"]\\./\|from ['\"]\\.\\./" --include="*.ts" --include="*.tsx" . | head -40
   ```

2. **Module dependency graph** — which modules are most imported:
   ```
   # Python: most imported internal modules
   grep -roh "from [a-zA-Z_]*\.\|import [a-zA-Z_]*\." --include="*.py" . | sort | uniq -c | sort -rn | head -20
   ```

### Phase 2: External Service Dependencies

1. **HTTP/API calls to other services**:
   ```
   grep -rn "requests\.\|httpx\.\|aiohttp\.\|fetch(\|axios\.\|urllib" --include="*.py" --include="*.ts" --include="*.tsx" . | head -30
   ```

2. **Environment-based service URLs**:
   ```
   grep -rn "SERVICE_URL\|API_URL\|BASE_URL\|ENDPOINT\|_HOST\|_PORT" --include="*.py" --include="*.ts" --include="*.env*" . | head -20
   ```

3. **gRPC / Protocol Buffers**:
   ```
   find . -name "*.proto" -o -name "*_pb2.py" -o -name "*_grpc.py" 2>/dev/null
   ```

4. **Message queues / event systems**:
   ```
   grep -rn "kafka\|rabbitmq\|pubsub\|celery\|redis.*publish\|redis.*subscribe\|SQS\|SNS\|EventBridge" --include="*.py" --include="*.ts" . | head -20
   ```

### Phase 3: Data Dependencies

1. **Database connections**:
   ```
   grep -rn "DATABASE_URL\|MONGO_URI\|REDIS_URL\|sqlalchemy\|prisma\|mongoose\|TypeORM\|Firestore\|BigQuery" --include="*.py" --include="*.ts" --include="*.env*" . | head -20
   ```

2. **Shared data models** — look for:
   - SQLAlchemy models, Pydantic schemas, Prisma schemas
   - Shared types or interfaces
   - API request/response contracts

3. **File/storage dependencies**:
   ```
   grep -rn "S3\|GCS\|BUCKET\|STORAGE\|BLOB\|upload\|download" --include="*.py" --include="*.ts" . | head -15
   ```

### Phase 4: Google ADK / AI Dependencies

1. **Agent-to-agent communication**:
   ```
   grep -rn "SequentialAgent\|ParallelAgent\|LoopAgent\|sub_agents\|AgentTool\|transfer_to" --include="*.py" . | head -20
   ```

2. **Tool definitions and external tool calls**:
   ```
   grep -rn "FunctionTool\|@tool\|ToolContext\|google_search\|code_execution" --include="*.py" . | head -20
   ```

3. **Model dependencies**:
   ```
   grep -rn "gemini\|gpt-4\|claude\|model_name\|model=\|LlmAgent" --include="*.py" --include="*.ts" . | head -15
   ```

4. **Shared prompt templates or instructions**:
   ```
   find . -name "*.prompt" -o -name "*prompt*" -o -name "*instruction*" 2>/dev/null | head -10
   ```

### Phase 5: Cross-Repo Pattern Detection

Look for patterns that indicate cross-repo dependencies:

1. **Shared package names** in `requirements.txt` or `package.json`
2. **Common environment variables** across repos
3. **API version matching** (e.g., `/api/v1/` in both producer and consumer)
4. **Docker network configurations** in `docker-compose.yml`
5. **Kubernetes service references** in deployment configs

## Output Format

```markdown
# Dependency Map: [repo-name]

## Internal Module Dependencies
```mermaid
graph TD
    A[module_a] --> B[module_b]
    A --> C[module_c]
    B --> D[module_d]
```

## External Service Dependencies
| Target Service | Protocol | Endpoint/Config | Purpose |
|---------------|----------|-----------------|---------|
| [service name] | [HTTP/gRPC/Queue] | [URL or env var] | [why] |

## Data Dependencies
| Data Store | Type | Access Pattern | Shared With |
|-----------|------|----------------|-------------|
| [name] | [Postgres/Redis/S3/etc] | [read/write/both] | [other repos] |

## AI/Agent Dependencies (Google ADK)
| Agent/Tool | Type | Depends On | Purpose |
|-----------|------|------------|---------|
| [name] | [LlmAgent/Tool/SubAgent] | [model/service] | [what it does] |

## Cross-Repo Dependencies (Known/Suspected)
| This Repo | Direction | Other Repo | Mechanism | Evidence |
|-----------|-----------|------------|-----------|----------|
| [current] | calls → | [target] | [HTTP/queue/shared DB] | [file:line] |
| [source] | → calls | [current] | [HTTP/queue/shared DB] | [evidence] |

## Shared Resources
- **Shared packages**: [list]
- **Shared env vars**: [list]
- **Shared data stores**: [list]
- **Shared models/schemas**: [list]

## Coupling Assessment
- **Tight coupling**: [list of tightly coupled components]
- **Loose coupling**: [list of well-decoupled components]
- **Circular dependencies**: [any detected]

## Risks / Unknowns
- [dependency risks, missing connection info]

## Confidence Score: [0-100]%
[Brief justification]
```

## Important Rules

- Focus on CONNECTIONS, not internal logic.
- Always note the EVIDENCE (file + line number) for each dependency found.
- Flag suspected dependencies even if you can't confirm them.
- Pay special attention to Google ADK agent orchestration patterns.
- Save output to `recovery/[repo-name]_dependencies.md`.
