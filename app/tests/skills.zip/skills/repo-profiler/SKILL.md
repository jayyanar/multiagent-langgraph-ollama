---
name: repo-profiler
description: >-
  Reverse-engineer and profile a repository when the original team is unavailable.
  Use this skill when you need to understand an unfamiliar codebase, identify its
  purpose, tech stack, entry points, core modules, and architecture. Activates
  whenever asked to analyze, profile, or understand a repository. Optimized for
  Python/FastAPI, Next.js, and Google ADK (Agent Development Kit) codebases.
metadata:
  author: enterprise-recovery
  version: "1.0"
  compatibility: copilot, claude, codex
---

# Repo Profiler — Repository Intelligence Extraction

## Role

You are a **principal software architect** performing forensic reverse-engineering
of an inherited codebase. The original development team is no longer available.
Your job is to reconstruct a clear, structured understanding of this repository
WITHOUT diving into line-by-line code analysis.

## When to Use This Skill

- Onboarding to an unfamiliar repository
- The original team has left and no knowledge transfer occurred
- You need a high-level system map before deeper analysis
- First step in a multi-repo recovery effort

## Instructions

### Phase 1: Rapid Reconnaissance (Do This First)

1. **Read these files first** (in priority order):
   - `README.md` or `README.rst`
   - `pyproject.toml`, `package.json`, `requirements.txt`, `poetry.lock`
   - `Dockerfile`, `docker-compose.yml`, `docker-compose.yaml`
   - `.env.example`, `.env.template`
   - `serverless.yml`, `terraform/`, `infra/`, `cdk/`
   - `Makefile`, `justfile`, `taskfile.yml`

2. **Scan directory structure** — run `find . -type f -name "*.py" -o -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" | head -80` to understand file layout.

3. **Identify framework signals**:
   - FastAPI: look for `app = FastAPI()`, `@app.get`, `@app.post`, `APIRouter`
   - Next.js: look for `next.config.js`, `pages/` or `app/` directory, `_app.tsx`
   - Google ADK: look for `agent.py`, `Agent()`, `SequentialAgent`, `LlmAgent`, `adk` imports, `google.adk` references
   - LangChain/LangGraph: look for `StateGraph`, `ChatOpenAI`, chain definitions

### Phase 2: Architecture Identification

1. **Determine repo type** — classify as one of:
   - API Service (FastAPI/Flask/Express)
   - Frontend Application (Next.js/React)
   - AI Agent Layer (Google ADK/LangGraph)
   - Data Processing Pipeline
   - Shared Library / SDK
   - Infrastructure / DevOps

2. **Find entry points**:
   - Python: `main.py`, `app.py`, `server.py`, `__main__.py`, or `uvicorn` references
   - Next.js: `pages/index.tsx`, `app/page.tsx`, `next.config.js`
   - Google ADK: `agent.py`, files with `root_agent` or `Agent()` definitions
   - CLI: `cli.py`, `console_scripts` in `pyproject.toml`

3. **Map core modules** — identify the 5-8 most important directories/files by:
   - Import frequency (most imported = most central)
   - Size and complexity
   - Naming conventions (e.g., `services/`, `routes/`, `models/`, `agents/`)

### Phase 3: Dependency Analysis

1. **Internal dependencies**: Which modules import which?
2. **External dependencies**: Key packages from `requirements.txt` / `package.json`
3. **Infrastructure dependencies**: Databases, queues, cloud services, APIs
4. **Google ADK specifics**: Check for tool definitions, sub-agents, model configs

## Output Format

Generate the output as a structured markdown report with this exact structure:

```markdown
# Repository Profile: [repo-name]

## Summary
[2-3 sentence description of what this repo does and why it exists]

## Classification
- **Type**: [API Service | Frontend | AI Agent | Data Pipeline | Library | Infra]
- **Primary Stack**: [e.g., Python 3.11 + FastAPI 0.100+]
- **Secondary Stack**: [if applicable]
- **Framework**: [FastAPI | Next.js | Google ADK | etc.]

## Entry Points
| Entry Point | Type | Purpose |
|-------------|------|---------|
| [file path] | [API/CLI/Agent/Page] | [what it does] |

## Core Modules
| Module/Directory | Purpose | Key Files |
|-----------------|---------|-----------|
| [path] | [responsibility] | [important files] |

## External Dependencies (Key)
| Package | Purpose | Version |
|---------|---------|---------|
| [name] | [why it's used] | [version] |

## Infrastructure Dependencies
- **Database**: [type + connection details location]
- **Cloud Services**: [AWS/GCP services used]
- **External APIs**: [third-party integrations]
- **Message Queues**: [if any]

## Configuration
- **Environment Variables**: [list from .env.example]
- **Config Files**: [list config locations]

## Risks / Unknowns
- [things that are unclear or potentially problematic]

## Confidence Score: [0-100]%
[Brief justification for the score]
```

## Important Rules

- DO NOT read every file. Focus on structure and signals.
- DO NOT explain code line-by-line.
- DO NOT make assumptions — flag unknowns explicitly.
- ALWAYS check for Google ADK patterns (this is a known stack in this system).
- Save output to `recovery/[repo-name]_profile.md`.
