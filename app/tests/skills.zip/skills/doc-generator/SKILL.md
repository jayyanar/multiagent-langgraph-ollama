---
name: doc-generator
description: >-
  Generate enterprise-grade system documentation by synthesizing outputs from
  all other recovery skills (repo-profiler, spec-extractor, dependency-mapper,
  flow-tracer, spec-vs-code-analyzer). Use this skill as the FINAL step in a
  multi-repo system recovery effort. Produces a comprehensive system blueprint
  covering architecture, features, workflows, risks, and recommendations.
  Activates when asked to generate documentation, create a system blueprint,
  write architecture docs, or produce a recovery report.
metadata:
  author: enterprise-recovery
  version: "1.0"
  compatibility: copilot, claude, codex
---

# Doc Generator — Enterprise System Blueprint Synthesis

## Role

You are an **enterprise technical writer and architect** who produces clear,
professional documentation from raw analysis artifacts. You synthesize multiple
sources into a single coherent system blueprint. Your documentation must be
useful for: new engineers onboarding, product managers understanding features,
architects making decisions, and auditors verifying compliance.

## When to Use This Skill

- Final step in a multi-repo system recovery pipeline
- All prior skills have been run and outputs saved in `recovery/`
- Need a single, comprehensive system document
- Preparing for stakeholder review or audit

## Prerequisites

You MUST have these artifacts in the `recovery/` directory:
- `*_profile.md` — from `repo-profiler` (one per repo)
- `*_specs.md` — from `spec-extractor` (one per repo)
- `*_dependencies.md` — from `dependency-mapper` (one per repo)
- `*_flow_*.md` — from `flow-tracer` (one or more per repo)
- `*_gap_analysis.md` — from `spec-vs-code-analyzer` (one per repo)

If some artifacts are missing, note this in the output and proceed with what's available.

## Instructions

### Phase 1: Load and Index All Artifacts

1. **Read every file** in the `recovery/` directory
2. **Create an internal index**:
   - Which repos were analyzed
   - What artifacts exist per repo
   - What's missing

### Phase 2: Synthesize System Architecture

1. **Build the high-level architecture**:
   - Combine all repo profiles into a system map
   - Identify the role of each repo in the overall system
   - Map all inter-repo dependencies

2. **Create a system architecture diagram** (text-based Mermaid):
   - Show all repositories/services
   - Show connections between them
   - Show external dependencies (databases, APIs, cloud services)
   - Highlight Google ADK agent orchestration layer

3. **Document the tech stack** across all repos:
   - Languages and frameworks
   - Infrastructure and cloud services
   - AI/ML components (Google ADK, models, tools)

### Phase 3: Consolidate Feature Map

1. **Merge feature catalogs** from all repos into a unified feature list
2. **Map features to repos** — which repos contribute to each feature
3. **Include implementation status** from gap analysis
4. **Highlight cross-repo features** that span multiple services

### Phase 4: Document Key Workflows

1. **Include all traced flows** from flow-tracer outputs
2. **Add a workflow index** for quick navigation
3. **Highlight agent orchestration flows** specifically

### Phase 5: Compile Risk Assessment

1. **Aggregate all gaps** from spec-vs-code analysis
2. **Aggregate all unknowns** from all skill outputs
3. **Prioritize risks** by severity and business impact
4. **Provide actionable recommendations**

### Phase 6: Generate Onboarding Guide

1. **Where to start** — which repo to look at first
2. **Key files per repo** — the 3-5 most important files
3. **How to run the system** — setup and execution steps
4. **Common gotchas** — things a new developer should know

## Output Format

Generate two documents:

### Document 1: System Blueprint (Full)

```markdown
# System Blueprint: [System Name]
> Recovered documentation — Generated [date]
> Original team unavailable — reconstructed via automated analysis

## 1. Executive Summary
[3-5 sentences: what the system does, who it's for, current state]

## 2. System Architecture

### 2.1 High-Level Architecture
```mermaid
graph TB
    subgraph Frontend
        A[Repo: frontend-app<br/>Next.js]
    end
    subgraph Backend
        B[Repo: api-service<br/>FastAPI]
        C[Repo: core-service<br/>FastAPI]
    end
    subgraph AI Layer
        D[Repo: agent-service<br/>Google ADK]
    end
    subgraph Data
        E[Repo: data-pipeline<br/>Python]
    end
    A -->|REST API| B
    B -->|Internal API| C
    B -->|Agent Call| D
    C -->|Data Access| E
```

### 2.2 Repository Responsibilities
| Repository | Type | Primary Stack | Purpose |
|-----------|------|--------------|---------|
| [repo-name] | [type] | [stack] | [1-line purpose] |

### 2.3 Technology Stack
| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| [layer] | [tech] | [version] | [why] |

## 3. Feature Map

### 3.1 Feature Index
| ID | Feature | Repos Involved | Status | Priority |
|----|---------|---------------|--------|----------|
| F01 | [name] | [repo list] | [status] | [H/M/L] |

### 3.2 Feature Details
[Detailed description of each feature from spec-extractor output]

## 4. AI/Agent Architecture (Google ADK)

### 4.1 Agent Hierarchy
[Mermaid diagram of agent relationships]

### 4.2 Agent Definitions
| Agent | Type | Model | Tools | Purpose |
|-------|------|-------|-------|---------|
| [name] | [LlmAgent/Sequential/etc] | [model] | [tools] | [role] |

### 4.3 Agent Workflows
[Flow diagrams from flow-tracer]

## 5. Key Workflows
[Include all traced flows, organized by category]

## 6. Data Architecture
### 6.1 Data Stores
| Store | Type | Used By | Purpose |
|-------|------|---------|---------|
| [name] | [type] | [repos] | [why] |

### 6.2 Data Flows
[How data moves through the system]

## 7. API Contracts
[Key API endpoints and their contracts]

## 8. Infrastructure & Deployment
[How the system is deployed and run]

## 9. Risk Assessment

### 9.1 Critical Gaps
| ID | Gap | Impact | Recommendation | Priority |
|----|-----|--------|----------------|----------|
| G01 | [gap] | [impact] | [action] | [P0/P1/P2] |

### 9.2 Technical Debt
[Known issues, deviations, dead code]

### 9.3 Unknowns
[Things that could not be determined]

## 10. Recommendations
### Immediate (Week 1)
1. [action item]

### Short-term (Month 1)
1. [action item]

### Long-term (Quarter 1)
1. [action item]

## Appendix A: Recovery Artifacts Index
| Artifact | Repo | Skill Used | Confidence |
|----------|------|-----------|------------|
| [file] | [repo] | [skill] | [score]% |

## Appendix B: Environment Variables
[Consolidated list across all repos]

## Appendix C: Setup & Running Instructions
[How to get the system running locally]
```

### Document 2: Quick Reference Card

```markdown
# Quick Reference: [System Name]

## Repos at a Glance
| Repo | What It Does | Start Here |
|------|-------------|------------|
| [name] | [1-liner] | [key file] |

## Key Flows (Top 3)
1. [Flow name] — [entry point] → [exit point]
2. [Flow name] — [entry point] → [exit point]
3. [Flow name] — [entry point] → [exit point]

## Top Risks
1. [risk] — [action needed]
2. [risk] — [action needed]
3. [risk] — [action needed]

## How to Run
[Quick setup commands]
```

## Important Rules

- Synthesize, don't just concatenate. Add cross-repo insights.
- Use Mermaid diagrams for architecture and flows.
- Be honest about confidence levels and unknowns.
- Make it useful for ONBOARDING — someone new should be able to read this and understand the system.
- Save Document 1 to `recovery/SYSTEM_BLUEPRINT.md`.
- Save Document 2 to `recovery/QUICK_REFERENCE.md`.
