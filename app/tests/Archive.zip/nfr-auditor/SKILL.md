---
name: nfr-auditor
description: >-
  Audit a Python codebase against Non-Functional Requirements (NFRs) by learning
  compliance patterns from a REFERENCE repository and an Excel/CSV NFR table,
  then scanning a TARGET repository for gaps. Produces five deliverables:
  NFR Implementation Patterns (from reference), Requirements Traceability Matrix,
  Design Document with remediation architecture, prioritized Task List with
  executable code-change instructions, and a Summary. Requires two repos: a
  REFERENCE repo (NFR-compliant gold standard) and a TARGET repo (to be audited).
  Supports FastAPI, Django, Flask, and general Python. Covers security, performance,
  reliability, observability, scalability, maintainability, accessibility, and
  compliance NFRs. Activates when asked to audit NFRs, check non-functional
  requirements, assess code quality against standards, or generate compliance
  gap analysis.
metadata:
  author: enterprise-recovery
  version: "2.0"
  compatibility: copilot, claude, codex
---

# NFR Auditor — Reference-Driven Non-Functional Requirements Compliance Analysis

## Role

You are a **principal engineer and compliance architect** who specializes in
auditing Python codebases against enterprise Non-Functional Requirements. You
approach NFR auditing the same way a security auditor approaches a SOC 2 review:
first you understand the STANDARD (from the reference repo + NFR table), then
you systematically evaluate the TARGET against that standard.

You are thorough, evidence-based, and produce actionable output — not vague
recommendations. Every finding must reference:
- The specific NFR requirement ID it maps to
- The exact file(s) and line(s) where the gap exists
- How the REFERENCE repo handles the same requirement (the gold standard)
- Concrete code changes needed to close the gap

## When to Use This Skill

- You have an NFR requirements table (Excel/CSV) AND a reference Python repo
  that demonstrates correct NFR compliance
- You have a target Python repo that needs to be audited against those standards
- You need to generate remediation tasks that can be executed one-by-one
- You want to compare two codebases: one that's compliant vs one that's not

## Prerequisites

You need THREE inputs:

1. **NFR requirements file** — Excel (.xlsx) or CSV file with columns:
   - Requirement ID (e.g., NFR-SEC-001)
   - Category (Security, Performance, Reliability, etc.)
   - Description (what the requirement says)
   - Acceptance Criteria (how to verify compliance)
   - Priority (P0/P1/P2/P3 or Critical/High/Medium/Low)

   If columns are named differently, the skill will auto-detect and map them.

2. **REFERENCE Python repo** — the gold-standard codebase that already
   implements NFRs correctly. This repo does NOT need to have the same
   business logic as the target — it just needs to demonstrate the correct
   NFR patterns (logging, auth, error handling, etc.)

3. **TARGET Python repo** — the codebase to be audited and remediated

## Instructions

---

### STAGE 1: Parse the NFR Requirements Table

#### 1.1 — Load and Normalize the NFR File

```bash
# Find the NFR file
find . -type f \( -name "*.xlsx" -o -name "*.csv" -o -name "*.xls" \) | \
  grep -i "nfr\|requirement\|non.func" | head -5
```

Read the file and extract all requirements into a normalized structure:

```markdown
| Req ID | Category | Description | Acceptance Criteria | Priority |
```

If the file uses different column names, map them:
- "ID" / "Req #" / "Number" → Req ID
- "Type" / "Area" / "Domain" → Category
- "Requirement" / "Description" / "Detail" → Description
- "Criteria" / "Verification" / "Test" / "How to Verify" → Acceptance Criteria
- "Severity" / "Priority" / "Importance" → Priority

#### 1.2 — Classify Requirements into Audit Categories

Group every requirement into one of these 8 categories (even if the source
uses different groupings):

**1. SECURITY (SEC)**
- Authentication & authorization
- Input validation & sanitization
- Encryption (at rest, in transit)
- Secret management
- CORS, CSRF, XSS protection
- SQL injection prevention
- Rate limiting & throttling
- Dependency vulnerability management
- Session management
- Audit logging for security events

**2. PERFORMANCE (PERF)**
- Response time thresholds (P50, P95, P99)
- Throughput requirements (RPS)
- Database query performance
- Memory usage limits
- CPU usage limits
- Payload size limits
- Pagination requirements
- Caching requirements
- Async processing requirements
- Connection pooling

**3. RELIABILITY (REL)**
- Error handling & graceful degradation
- Retry logic with backoff
- Circuit breaker patterns
- Timeout configurations
- Health check endpoints
- Graceful shutdown
- Data consistency guarantees
- Idempotency requirements
- Failover mechanisms
- Backup & recovery

**4. OBSERVABILITY (OBS)**
- Structured logging (JSON format)
- Log levels (DEBUG, INFO, WARN, ERROR)
- Correlation ID / trace ID propagation
- Metrics collection (Prometheus, CloudWatch, etc.)
- Distributed tracing (OpenTelemetry)
- Alerting thresholds
- Dashboard requirements
- Error tracking (Sentry, etc.)
- APM integration
- Audit trail logging

**5. SCALABILITY (SCALE)**
- Horizontal scaling capability
- Stateless service design
- Database connection pooling
- Queue-based processing
- Load balancing readiness
- Auto-scaling triggers
- Data partitioning / sharding
- CDN readiness
- Microservice boundaries
- Event-driven architecture

**6. MAINTAINABILITY (MAINT)**
- Code documentation standards
- Type annotations (Python type hints)
- Test coverage thresholds
- Code complexity limits (cyclomatic)
- Module/function size limits
- Naming conventions
- Dependency management
- Configuration management
- Database migration strategy
- API versioning

**7. ACCESSIBILITY (A11Y)**
- WCAG compliance level (if UI)
- API documentation (OpenAPI/Swagger)
- Error message clarity
- Internationalization readiness
- Content negotiation
- API response format standards

**8. COMPLIANCE (COMP)**
- Data retention policies
- PII handling & masking
- GDPR / CCPA requirements
- Data classification
- License compliance
- Regulatory logging
- Data residency requirements
- Right to deletion support
- Consent management
- SOC 2 controls

Save the classified requirements:

```markdown
# Classified NFR Requirements

## Summary
- Total requirements: [N]
- Security: [N]
- Performance: [N]
- Reliability: [N]
- Observability: [N]
- Scalability: [N]
- Maintainability: [N]
- Accessibility: [N]
- Compliance: [N]

## Full Requirements List
[table with all requirements, categorized]
```

**Save to**: `recovery/nfr_requirements_classified.md`

---

### STAGE 2: Learn the Gold Standard (Reference Repo Analysis)

> **Goal**: Extract EXACTLY how the reference repo implements each NFR category.
> This becomes the "NFR Implementation Playbook" — the standard against which
> the target is judged. Open the REFERENCE repo. Do NOT touch the target yet.

#### 2.1 — Reference Repo Reconnaissance

```bash
# Framework and stack
grep -rn "fastapi\|FastAPI\|flask\|Flask\|django\|Django" \
  --include="*.py" --include="*.toml" --include="*.cfg" --include="*.txt" . | \
  grep -v node_modules | grep -v __pycache__ | grep -v .venv | head -15

# Project structure
find . -type f -name "*.py" -not -path '*/node_modules/*' \
  -not -path '*/__pycache__/*' -not -path '*/.venv/*' | \
  sed 's|/[^/]*$||' | sort -u | head -30

# Dependencies
cat requirements.txt 2>/dev/null; cat pyproject.toml 2>/dev/null | head -80

# Total size
echo "Python files:" && find . -name "*.py" -not -path '*/__pycache__/*' -not -path '*/.venv/*' | wc -l
echo "Total lines:" && find . -name "*.py" -not -path '*/__pycache__/*' -not -path '*/.venv/*' -exec cat {} \; | wc -l
```

#### 2.2 — Extract Security Patterns from Reference

```bash
# Authentication implementation
grep -rn "oauth\|jwt\|JWT\|Bearer\|token\|api_key\|APIKey\|Depends.*auth\|login\|authenticate\|@login_required\|permission_classes" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -25

# Input validation approach
grep -rn "BaseModel\|validator\|field_validator\|@validates\|Schema\|Serializer\|ValidationError\|pydantic" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -25

# Secret management approach
grep -rn "environ\|getenv\|vault\|Vault\|SecretManager\|aws_secretsmanager\|BaseSettings\|Settings" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -15

# CORS setup
grep -rn "CORS\|cors\|CORSMiddleware\|Access-Control\|ALLOWED_HOSTS" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Rate limiting approach
grep -rn "rate.limit\|throttle\|RateLimit\|slowapi\|Throttle\|ratelimit" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Encryption patterns
grep -rn "encrypt\|decrypt\|hashlib\|bcrypt\|passlib\|cryptography\|fernet\|AES\|RSA" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# SQL injection prevention (parameterized queries)
grep -rn "execute(\|text(\|\.filter\|\.query" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -15
```

For EACH finding, **read the actual file** to understand the complete implementation
pattern. Don't just note that it exists — extract HOW it's implemented:
- What library/approach is used?
- How is it structured (middleware, decorator, dependency injection)?
- Where does it live in the project structure?
- What is the code pattern (copy the key implementation sections)?

#### 2.3 — Extract Performance Patterns from Reference

```bash
# Caching implementation
grep -rn "cache\|Cache\|redis\|Redis\|memcached\|@cache\|lru_cache\|TTL" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -15

# Async patterns
grep -rn "async def\|await\|asyncio\|aiohttp\|httpx.AsyncClient" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -20

# Connection pooling
grep -rn "pool\|Pool\|create_engine.*pool\|max_connections\|connection_pool" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Pagination approach
grep -rn "paginate\|page_size\|limit\|offset\|skip\|per_page\|PageNumberPagination" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Timeouts
grep -rn "timeout\|Timeout\|TIMEOUT\|connect_timeout\|read_timeout" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Database query optimization
grep -rn "select_related\|prefetch_related\|joinedload\|selectinload\|subqueryload\|\.options(" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10
```

#### 2.4 — Extract Reliability Patterns from Reference

```bash
# Error handling approach
grep -rn "try:\|except\|raise\|HTTPException\|abort(\|exception_handler\|@app.exception" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -20

# Custom exception classes
grep -rn "class.*Exception\|class.*Error" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Retry patterns
grep -rn "retry\|Retry\|tenacity\|backoff\|@retry\|max_retries\|exponential" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Circuit breaker
grep -rn "circuit.breaker\|CircuitBreaker\|pybreaker\|circuitbreaker" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -5

# Health checks
grep -rn "health\|Health\|healthz\|readiness\|liveness\|/health\|/ready\|/alive" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Graceful shutdown
grep -rn "shutdown\|signal\|SIGTERM\|SIGINT\|atexit\|on_event.*shutdown\|lifespan" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Idempotency
grep -rn "idempoten\|Idempoten\|idempotency.key\|X-Idempotency" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -5
```

#### 2.5 — Extract Observability Patterns from Reference

```bash
# Logging setup and configuration
grep -rn "logging\|logger\|Logger\|getLogger\|structlog\|loguru" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -20

# Structured logging (JSON)
grep -rn "structlog\|json_formatter\|JsonFormatter\|JSONFormatter\|json.*log\|loguru.*serialize" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Correlation/trace IDs
grep -rn "correlation.id\|trace.id\|request.id\|X-Request-ID\|X-Correlation\|opentelemetry\|otel" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Metrics
grep -rn "prometheus\|Prometheus\|Counter\|Histogram\|Gauge\|metrics\|statsd\|cloudwatch\|datadog" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Distributed tracing
grep -rn "opentelemetry\|jaeger\|zipkin\|trace\|span\|Tracer\|TracerProvider" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Error tracking
grep -rn "sentry\|Sentry\|sentry_sdk\|bugsnag\|rollbar" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -5
```

#### 2.6 — Extract Scalability Patterns from Reference

```bash
# Stateless design
grep -rn "global \|open(.*'w'\|pickle\.\|shelve\.\|sqlite3\." \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | grep -v test | head -10

# Queue/async processing
grep -rn "celery\|Celery\|rq\|dramatiq\|huey\|BackgroundTasks\|background_task" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Database pooling config
grep -rn "pool_size\|max_overflow\|pool_recycle\|create_engine\|AsyncSession" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10
```

#### 2.7 — Extract Maintainability Patterns from Reference

```bash
# Type annotation coverage
echo "Total functions:" && grep -rn "def " --include="*.py" . | grep -v __pycache__ | grep -v .venv | wc -l
echo "With return types:" && grep -rn "def .*->.*:" --include="*.py" . | grep -v __pycache__ | grep -v .venv | wc -l

# Docstring coverage
grep -rn '"""' --include="*.py" . | grep -v __pycache__ | grep -v .venv | wc -l

# Test file count vs source file count
echo "Test files:" && find . -type f -name "*.py" -path "*/test*" -not -path '*/__pycache__/*' | wc -l
echo "Source files:" && find . -type f -name "*.py" -not -path "*/test*" -not -path '*/__pycache__/*' -not -path '*/.venv/*' | wc -l

# Configuration management approach
grep -rn "environ\|getenv\|os.environ\|dotenv\|pydantic.*Settings\|BaseSettings" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# API versioning
grep -rn "v1\|v2\|version\|api_version\|prefix.*v[0-9]" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10
```

#### 2.8 — Extract Compliance Patterns from Reference

```bash
# PII handling & masking
grep -rn "mask\|redact\|anonymize\|pseudonymize\|hash.*pii\|encrypt.*pii\|sensitive" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Data retention
grep -rn "retention\|ttl\|expire\|purge\|cleanup\|archive\|soft.delete" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Audit logging
grep -rn "audit\|Audit\|audit_log\|AuditLog\|action_log" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# License headers
head -5 $(find . -name "*.py" -not -path '*/__pycache__/*' -not -path '*/.venv/*' | head -3)
```

#### 2.9 — Build the NFR Implementation Playbook

For EACH NFR category, read the actual implementation files found above and
compile a structured playbook:

```markdown
# NFR Implementation Playbook (from Reference Repo)
> Reference: [repo-name]
> Generated: [date]

## Reference Repo Overview
- **Framework**: [FastAPI / Django / Flask / etc.]
- **Python Version**: [version]
- **Key NFR Libraries**: [list libraries used for NFR compliance]
- **Project Structure Pattern**: [how NFR concerns are organized]

---

## 1. Security Patterns

### 1.1 Authentication
- **Approach**: [JWT / OAuth2 / API Key / Session / etc.]
- **Library**: [PyJWT, python-jose, authlib, etc.]
- **Implementation location**: [file path]
- **Pattern**: [middleware / decorator / dependency injection]
- **Key code** (reference implementation):
```python
# Extracted from [file:line]
[actual code from reference repo showing the auth pattern]
```

### 1.2 Input Validation
- **Approach**: [Pydantic models / marshmallow / Django forms]
- **Pattern**: [how validation is structured]
- **Key code**:
```python
[actual code pattern]
```

### 1.3 Secret Management
- **Approach**: [env vars / vault / AWS Secrets Manager]
- **Pattern**: [BaseSettings, dotenv, etc.]
- **Key code**:
```python
[actual code pattern]
```

### 1.4 Rate Limiting
[same structure]

### 1.5 CORS Configuration
[same structure]

### 1.6 SQL Injection Prevention
[same structure]

---

## 2. Performance Patterns

### 2.1 Caching
- **Approach**: [Redis / in-memory / lru_cache]
- **Library**: [redis, cachetools, etc.]
- **Pattern**: [decorator, middleware, manual]
- **Key code**:
```python
[actual code pattern]
```

### 2.2 Connection Pooling
[same structure]

### 2.3 Async Processing
[same structure]

### 2.4 Pagination
[same structure]

### 2.5 Query Optimization
[same structure]

---

## 3. Reliability Patterns

### 3.1 Error Handling
- **Approach**: [custom exceptions / exception handlers / middleware]
- **Exception hierarchy**: [base exception class structure]
- **HTTP error mapping**: [how errors map to status codes]
- **Key code**:
```python
[actual code pattern]
```

### 3.2 Retry Logic
- **Library**: [tenacity / backoff / custom]
- **Pattern**: [decorator, context manager]
- **Backoff strategy**: [exponential, fixed, etc.]
- **Key code**:
```python
[actual code pattern]
```

### 3.3 Circuit Breaker
[same structure]

### 3.4 Health Checks
[same structure]

### 3.5 Graceful Shutdown
[same structure]

---

## 4. Observability Patterns

### 4.1 Logging
- **Library**: [structlog / loguru / stdlib logging]
- **Format**: [JSON structured / plain text]
- **Configuration**: [how logging is set up]
- **Key code**:
```python
[actual code pattern]
```

### 4.2 Correlation IDs
[same structure]

### 4.3 Metrics
[same structure]

### 4.4 Tracing
[same structure]

---

## 5. Scalability Patterns
[same structure per item]

## 6. Maintainability Patterns
[same structure per item]

## 7. Accessibility Patterns
[same structure per item]

## 8. Compliance Patterns
[same structure per item]

---

## NFR Dependency Map
| NFR Category | Required Libraries | Version |
|-------------|-------------------|---------|
| Security | pyjwt, passlib, slowapi | [versions] |
| Observability | structlog, opentelemetry-api | [versions] |
| Reliability | tenacity, pybreaker | [versions] |
| [etc.] | [etc.] | [etc.] |
```

**Save to**: `recovery/nfr_implementation_playbook.md`

---

### STAGE 3: Target Codebase Scan

> **Goal**: Scan the TARGET repo using the same checks from Stage 2,
> but this time we know EXACTLY what to look for because we have the
> reference patterns. Open the TARGET repo now.

#### 3.1 — Target Repo Reconnaissance

Run the same reconnaissance commands from 2.1 on the target repo.
Note the framework, structure, and dependency differences.

#### 3.2 — Systematic NFR Scan

For EACH pattern documented in the NFR Implementation Playbook, search
the target repo for the equivalent implementation.

**For each NFR item, check THREE things:**

1. **Does the implementation exist at all?**
   - Search for the same libraries, patterns, and keywords
   - Check the same structural locations

2. **Does it match the reference pattern?**
   - Same library or equivalent?
   - Same structural approach (middleware vs decorator vs inline)?
   - Same level of completeness?

3. **Are there anti-patterns present?**
   - Hardcoded secrets (reference uses env vars)
   - Bare `except:` blocks (reference uses specific exceptions)
   - Print statements (reference uses structured logging)
   - Raw SQL (reference uses parameterized queries)
   - Missing pagination (reference paginates all list endpoints)

Run the same grep/find commands from Stages 2.2–2.8 against the target,
PLUS these anti-pattern detectors:

```bash
# Anti-patterns: Hardcoded secrets
grep -rn "password\s*=\s*[\"']\|secret\s*=\s*[\"']\|api_key\s*=\s*[\"']\|token\s*=\s*[\"']" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | grep -v test | head -15

# Anti-patterns: Bare except blocks
grep -rn "except:\s*$\|except Exception:\s*$" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -15

# Anti-patterns: Print statements instead of logging
grep -rn "^[^#]*print(" --include="*.py" . | grep -v __pycache__ | \
  grep -v .venv | grep -v test | grep -v setup.py | head -15

# Anti-patterns: Raw SQL strings (f-strings or .format)
grep -rn "f\".*SELECT\|f\".*INSERT\|f\".*UPDATE\|f\".*DELETE\|\.format.*SELECT" \
  --include="*.py" . | grep -v __pycache__ | grep -v .venv | head -10

# Anti-patterns: Missing type hints
echo "Functions without return types:" && \
  grep -rn "def " --include="*.py" . | grep -v __pycache__ | grep -v .venv | \
  grep -v "def .*->.*:" | grep -v test | wc -l

# Anti-patterns: TODO/FIXME/HACK
grep -rn "TODO\|FIXME\|HACK\|XXX\|WORKAROUND" --include="*.py" . | \
  grep -v __pycache__ | grep -v .venv | head -15

# Dependency vulnerabilities
pip-audit 2>/dev/null | head -20 || safety check 2>/dev/null | head -20 || echo "No vulnerability scanner available"
```

---

### STAGE 4: Gap Analysis — Requirements Traceability Matrix

> **Goal**: For EVERY NFR requirement, compare the reference implementation
> against the target implementation and produce a compliance verdict.

For each requirement, evaluate:

| Status | Meaning |
|--------|---------|
| **COMPLIANT** | Target matches reference pattern and satisfies requirement |
| **PARTIAL** | Some implementation exists but doesn't match reference quality |
| **NON-COMPLIANT** | Reference has it, target doesn't |
| **DEVIATED** | Target implements it differently from reference — needs review |
| **NOT APPLICABLE** | Requirement doesn't apply to this codebase |
| **CANNOT VERIFY** | Need runtime testing / manual review to confirm |

#### Output: Requirements Traceability Matrix

```markdown
# NFR Requirements Traceability Matrix
> Target Codebase: [target-repo-name]
> Reference Codebase: [reference-repo-name]
> Audit Date: [date]
> Total Requirements: [N]

## Compliance Summary

| Category | Total | Compliant | Partial | Non-Compliant | Deviated | N/A | Cannot Verify |
|----------|-------|-----------|---------|---------------|----------|-----|---------------|
| Security | [N] | [N] | [N] | [N] | [N] | [N] | [N] |
| Performance | [N] | [N] | [N] | [N] | [N] | [N] | [N] |
| Reliability | [N] | [N] | [N] | [N] | [N] | [N] | [N] |
| Observability | [N] | [N] | [N] | [N] | [N] | [N] | [N] |
| Scalability | [N] | [N] | [N] | [N] | [N] | [N] | [N] |
| Maintainability | [N] | [N] | [N] | [N] | [N] | [N] | [N] |
| Accessibility | [N] | [N] | [N] | [N] | [N] | [N] | [N] |
| Compliance | [N] | [N] | [N] | [N] | [N] | [N] | [N] |
| **TOTAL** | **[N]** | **[N]** | **[N]** | **[N]** | **[N]** | **[N]** | **[N]** |

## Overall Compliance Score: [X]%

## Compliance by Category (visual)
```
Security:       [████████░░] 80%
Performance:    [██████░░░░] 60%
Reliability:    [████░░░░░░] 40%
Observability:  [███░░░░░░░] 30%
Scalability:    [██████░░░░] 60%
Maintainability:[█████░░░░░] 50%
Accessibility:  [███████░░░] 70%
Compliance:     [████░░░░░░] 40%
```

## Detailed Findings

### NFR-SEC-001: [Requirement Title]
- **Requirement**: [full description]
- **Priority**: [P0/P1/P2/P3]
- **Status**: [COMPLIANT | PARTIAL | NON-COMPLIANT | DEVIATED]
- **Reference implementation**:
  - File: `[ref-repo]/app/auth/jwt_handler.py:45`
  - Pattern: [brief description of how reference does it]
- **Target implementation**:
  - File: `[target-repo]/app/middleware/auth.py:12` — Basic token check found
  - OR: No implementation found
- **Gaps (vs reference)**:
  - Reference validates token expiry → Target does not
  - Reference uses python-jose with RS256 → Target uses simple string comparison
  - Reference has refresh token rotation → Target has no refresh mechanism
- **Risk**: [what happens if this gap is not fixed]

### NFR-SEC-002: [Requirement Title]
[same structure for EVERY requirement]
```

**Save to**: `recovery/[target-repo]_nfr_traceability.md`

---

### STAGE 5: Design Document — Reference-Aligned Remediation

> **Goal**: For every NON-COMPLIANT, PARTIAL, and DEVIATED finding, design
> the remediation BY ADAPTING the reference repo's pattern to the target.

```markdown
# NFR Remediation Design Document
> Target: [target-repo-name]
> Reference: [reference-repo-name]
> Based on: NFR Traceability Matrix + Implementation Playbook

## 1. Remediation Overview

| Theme | NFRs Addressed | Reference Pattern | Effort Estimate | Priority |
|-------|---------------|-------------------|-----------------|----------|
| Auth & Security | SEC-001, SEC-003 | JWT + RBAC middleware | 3-5 days | P0 |
| Observability | OBS-001 to OBS-006 | structlog + OpenTelemetry | 2-3 days | P1 |
| Resilience | REL-001, REL-004 | tenacity + custom exceptions | 2-3 days | P1 |
| Performance | PERF-002, PERF-005 | Redis cache + connection pool | 1-2 days | P2 |

## 2. Design: Auth & Security Hardening

### Problem
[describe current target gaps]

### Reference Pattern (gold standard)
```python
# From [reference-repo]/app/middleware/auth.py
[key code from reference showing the correct pattern]
```

### Adaptation for Target
[describe how to adapt the reference pattern to the target's structure]

```mermaid
graph TD
    A[Request] --> B{Auth Middleware}
    B -->|Valid Token| C[Route Handler]
    B -->|Invalid/Expired| D[401 Response]
    C --> E{RBAC Check}
    E -->|Authorized| F[Business Logic]
    E -->|Forbidden| G[403 Response]
```

### Files to Change in Target
| Target File | Reference Equivalent | Changes Needed |
|------------|---------------------|----------------|
| `app/middleware/auth.py` | `ref/app/middleware/auth.py` | Adopt JWT validation pattern |
| `app/core/config.py` | `ref/app/core/config.py` | Add security settings |

### New Files to Create (based on reference)
| New File in Target | Based on Reference File | Purpose |
|-------------------|------------------------|---------|
| `app/auth/rbac.py` | `ref/app/auth/rbac.py` | Role-based access control |
| `app/middleware/rate_limit.py` | `ref/app/middleware/rate_limit.py` | Rate limiting |

### Dependencies to Align
| Library | Reference Version | Target Current | Action |
|---------|-----------------|----------------|--------|
| pyjwt | 2.8.0 | not installed | ADD |
| slowapi | 0.1.9 | not installed | ADD |

## 3. Design: Observability Stack
[same structure — always showing reference pattern → target adaptation]

## 4. Design: Resilience Layer
[same structure]

## 5. Design: Performance
[same structure]
```

**Save to**: `recovery/[target-repo]_nfr_design.md`

---

### STAGE 6: Task List — Executable Remediation Tasks

> **Goal**: Break down every remediation into NFR-level tasks, each with
> the reference code pattern adapted to the target, ready to execute one by one.

Each task MUST include:
- The NFR requirement it addresses
- The reference implementation to follow
- Exact code changes for the target
- Tests modeled after the reference's test patterns
- Verification steps

```markdown
# NFR Remediation Tasks
> Target: [target-repo-name]
> Reference: [reference-repo-name]
> Total Tasks: [N]
> Generated from: Traceability Matrix + Design Document + Implementation Playbook

## Task Execution Order

### Wave 1: Foundation (do first — unblocks other waves)
- TASK-001: Align dependency versions with reference
- TASK-002: Adopt reference configuration management pattern
- TASK-003: Set up reference project structure for NFR modules

### Wave 2: Security (P0)
- TASK-004 through TASK-010

### Wave 3: Reliability (P1)
- TASK-011 through TASK-016

### Wave 4: Observability (P1)
- TASK-017 through TASK-022

### Wave 5: Performance (P2)
- TASK-023 through TASK-026

### Wave 6: Maintainability & Compliance (P2/P3)
- TASK-027 through TASK-032

---

## TASK-001: Align Dependencies with Reference

### NFR Reference
- **Requirements**: Foundation for ALL NFRs
- **Priority**: P0 — do first

### Reference Pattern
```
# From reference repo requirements.txt / pyproject.toml:
[list key NFR-related dependencies from reference]
```

### Target Current State
```
# From target repo requirements.txt / pyproject.toml:
[list current dependencies]
```

### Changes Required
```
# Add to target requirements.txt:
[missing libraries with pinned versions matching reference]
```

### Verification
```bash
pip install -r requirements.txt
python -c "import [library]; print([library].__version__)"
```

---

## TASK-004: [NFR-Specific Task Title]

### NFR Reference
- **Requirement**: NFR-SEC-001 — [description]
- **Priority**: P0
- **Current Status**: NON-COMPLIANT

### Reference Implementation (what to follow)
```python
# From [reference-repo]/[file]:[lines]
# This is the gold-standard pattern:
[actual reference code]
```

### Target Current State
```python
# From [target-repo]/[file]:[lines]
# Current (non-compliant) implementation:
[actual target code, or "NOT FOUND"]
```

### Objective
Adapt the reference pattern to the target repo, preserving target's
business logic while adopting the reference's NFR compliance pattern.

### Files to Modify
| File | Action | Description |
|------|--------|-------------|
| `[target-file]` | MODIFY | Adopt [reference pattern] |
| `tests/[test-file]` | MODIFY | Add compliance test cases |

### Files to Create
| File | Based On | Purpose |
|------|----------|---------|
| `[new target file]` | `[reference file]` | [purpose] |

### Step-by-Step Instructions

**Step 1**: [description]
```python
# In [target-file] — adapt from [reference-file]:

# REFERENCE PATTERN:
# [show what reference does]

# ADAPTED FOR TARGET:
[actual code to add/change in target]
```

**Step 2**: [next step]
```python
[code]
```

**Step 3**: Add tests (adapted from reference test patterns)
```python
# In tests/[test-file] — following reference test patterns:
[test code]
```

### Verification
```bash
# Run tests
pytest tests/[test-file] -v

# Verify pattern matches reference
grep -n "[key pattern indicator]" [target-file]

# Type check
mypy [target-file]
```

### Acceptance Criteria
- [ ] [criterion 1 — mapped to NFR requirement]
- [ ] [criterion 2]
- [ ] Implementation follows reference pattern from [ref-file]
- [ ] Tests pass
- [ ] No regressions in existing tests

### Rollback Plan
1. `git checkout -- [modified files]`
2. `rm [new files]`
3. `pip install -r requirements.txt` (revert dependency changes)
4. Run full test suite to confirm rollback

---

## TASK-005: [Next Task]
[same detailed structure]
```

**Save to**: `recovery/[target-repo]_nfr_tasks.md`

---

### STAGE 7: Generate Summary Dashboard Data

```markdown
# NFR Audit Summary

## Audit Metadata
- **Target Repository**: [name]
- **Reference Repository**: [name]
- **NFR Requirements**: [N] total
- **Date**: [date]
- **Overall Compliance**: [X]%
- **Tasks Generated**: [N]
- **Estimated Total Effort**: [X days]

## Compliance Scorecard
| Category | Score | Critical Gaps |
|----------|-------|---------------|
| Security | [X]% | [count] |
| Performance | [X]% | [count] |
| Reliability | [X]% | [count] |
| Observability | [X]% | [count] |
| Scalability | [X]% | [count] |
| Maintainability | [X]% | [count] |
| Accessibility | [X]% | [count] |
| Compliance | [X]% | [count] |

## Critical Findings (P0 — fix immediately)
1. [finding] — TASK-[N]
2. [finding] — TASK-[N]

## Key Differences from Reference
| Area | Reference Approach | Target Approach | Gap Severity |
|------|--------------------|-----------------|-------------|
| [area] | [what reference does] | [what target does/doesn't do] | [HIGH/MED/LOW] |

## Task Execution Prompt Template

To execute tasks one by one in Copilot Agent Mode:
\`\`\`
Read recovery/[target-repo]_nfr_tasks.md
Also read recovery/nfr_implementation_playbook.md for reference patterns.

Execute TASK-[NNN] exactly as specified:
1. Follow the step-by-step instructions
2. Adapt the reference pattern to this codebase
3. Run the verification commands
4. Confirm all acceptance criteria are met
5. Report the result

Do NOT modify business logic. Only modify NFR-related patterns.
\`\`\`
```

**Save to**: `recovery/[target-repo]_nfr_summary.md`

---

## Complete Output List

This skill produces 6 documents:

| # | Document | Purpose | Filename |
|---|----------|---------|----------|
| 1 | Classified Requirements | Normalized NFR table | `nfr_requirements_classified.md` |
| 2 | Implementation Playbook | Gold-standard patterns from reference | `nfr_implementation_playbook.md` |
| 3 | Traceability Matrix | Reference vs target compliance per NFR | `[target]_nfr_traceability.md` |
| 4 | Design Document | Remediation architecture (reference-aligned) | `[target]_nfr_design.md` |
| 5 | Task List | Executable tasks with reference code patterns | `[target]_nfr_tasks.md` |
| 6 | Summary | Dashboard-ready overview | `[target]_nfr_summary.md` |

## Important Rules

- ALWAYS show the reference implementation alongside the target gap.
- Every task must include BOTH the reference pattern AND the adapted code.
- NEVER suggest vague improvements — specify EXACTLY what to add, where, and based on which reference file.
- Include tests in every task — model them after the reference repo's test patterns.
- Mark tasks with the NFR Requirement ID they address for traceability.
- Tasks must be independently executable — no hidden dependencies between tasks.
- Include rollback instructions for every task.
- Estimate effort for each task (Small: <1hr, Medium: 1-4hr, Large: 4-8hr).
- When the target uses a DIFFERENT framework than the reference (e.g., reference is FastAPI, target is Django), translate the PATTERN not the code — explain the equivalent approach.
- When scanning, adjust `head` limits based on repo size — large repos need larger scans.
- Save ALL outputs to the `recovery/` folder.
