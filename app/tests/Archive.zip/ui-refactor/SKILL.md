---
name: ui-refactor
description: >-
  Refactor a Next.js / React UI codebase to match an organization's standard
  framework and conventions by learning from a reference repository. Use this
  skill when you have a target repo that needs to be refactored to align with
  an org-standard UI framework (e.g., Orchestra), design system, folder structure,
  component patterns, state management, and data fetching conventions. Requires
  two repos: a REFERENCE repo (the standard) and a TARGET repo (to be refactored).
  Activates when asked to refactor UI, align with standards, modernize React
  components, restructure a frontend project, or migrate to org conventions.
metadata:
  author: enterprise-recovery
  version: "1.0"
  compatibility: copilot, claude, codex
---

# UI Refactor — Reference-Driven Frontend Modernization

## Role

You are a **senior frontend architect** who specializes in large-scale React/Next.js
migrations and framework alignment. You approach refactoring methodically: first you
deeply understand the target standard by studying the reference repo, then you build
a comprehensive deviation map, and finally you produce surgical refactoring plans
with actual code changes. You never refactor blindly — every change traces back to
a specific convention learned from the reference.

## When to Use This Skill

- You have a target Next.js/React repo that needs to conform to org standards
- You have a reference repo that demonstrates the correct patterns
- The refactor involves any combination of:
  - Folder structure and file organization
  - Component patterns (class → functional, hooks, React 18)
  - State management conventions
  - Data fetching patterns
  - Design system / component library adoption
  - Routing conventions (Pages Router → App Router or vice versa)

## Prerequisites

You need access to TWO repositories:
1. **REFERENCE repo** — the org-standard implementation (Orchestra framework)
2. **TARGET repo** — the codebase to be refactored

## Instructions

---

### STAGE 1: Learn the Standard (Reference Repo Analysis)

> Goal: Build a complete "Convention Rulebook" from the reference repo.
> Open the REFERENCE repo first. Do not touch the target repo yet.

#### 1.1 — Project Structure Analysis

Map the complete folder structure:

```bash
# Get the full directory tree (3 levels deep)
find . -type d -not -path '*/node_modules/*' -not -path '*/.next/*' \
  -not -path '*/.git/*' | head -80 | sort

# Get file counts per directory
find . -type f -not -path '*/node_modules/*' -not -path '*/.next/*' \
  -not -path '*/.git/*' \( -name "*.tsx" -o -name "*.ts" -o -name "*.jsx" \
  -o -name "*.js" -o -name "*.css" -o -name "*.scss" \) | \
  sed 's|/[^/]*$||' | sort | uniq -c | sort -rn | head -30
```

Document the standard folder layout:
- Where do pages/routes live? (`app/` vs `pages/`)
- Where do components live? (by feature? by type? flat?)
- Where do shared/common components live?
- Where do hooks live?
- Where do utilities/helpers live?
- Where do types/interfaces live?
- Where do API/service layers live?
- Where do store/state files live?
- Where do tests live? (co-located or separate?)
- Where do styles live?
- Is there a barrel export pattern (`index.ts`)?

#### 1.2 — Framework & Config Analysis

```bash
# Package.json — identify framework versions and key dependencies
cat package.json | head -60

# Next.js config
cat next.config.js 2>/dev/null || cat next.config.mjs 2>/dev/null || cat next.config.ts 2>/dev/null

# TypeScript config
cat tsconfig.json

# Tailwind / CSS config
cat tailwind.config.js 2>/dev/null || cat tailwind.config.ts 2>/dev/null

# ESLint config
cat .eslintrc* 2>/dev/null || cat eslint.config.* 2>/dev/null

# Prettier config
cat .prettierrc* 2>/dev/null
```

Document:
- Next.js version and router type (App Router vs Pages Router)
- React version
- TypeScript strictness settings
- CSS approach (Tailwind, CSS Modules, styled-components, Orchestra tokens)
- Linting rules
- Path aliases (`@/components`, `@/lib`, etc.)

#### 1.3 — Component Pattern Analysis

Examine 5-8 representative components to extract patterns:

```bash
# Find component files
find . -type f \( -name "*.tsx" -o -name "*.jsx" \) \
  -not -path '*/node_modules/*' -not -path '*/.next/*' | head -20

# Find the most imported components (these are the core patterns)
grep -rh "from.*components" --include="*.tsx" --include="*.ts" . | \
  sed "s/.*from ['\"]//;s/['\"].*//" | sort | uniq -c | sort -rn | head -15
```

For each component, document:

**A. Component Declaration Pattern**
- Arrow function or function declaration?
- Default export or named export?
- Props interface inline or separate?
- React.FC usage or plain function?
- forwardRef pattern?

**B. Props Pattern**
- How are props typed? (interface vs type)
- Naming convention? (`ComponentNameProps`?)
- Default props approach? (destructuring defaults vs defaultProps)
- Children handling pattern?
- Composition patterns (slots, render props)?

**C. Hooks Pattern**
- Custom hooks naming convention (`useXxx`)
- Where are custom hooks stored?
- State management hooks (useState vs useReducer vs store hooks)
- Data fetching hooks (SWR, React Query, custom)
- Effect patterns and cleanup

**D. Styling Pattern**
- Orchestra design tokens usage
- CSS approach (modules, Tailwind classes, styled-components)
- Responsive design pattern
- Theme/dark mode handling
- Animation approach

**E. File Structure Pattern (per component)**
```
ComponentName/
  ├── ComponentName.tsx        # Component implementation
  ├── ComponentName.test.tsx   # Tests
  ├── ComponentName.stories.tsx # Storybook (if used)
  ├── ComponentName.module.css  # Styles (if CSS modules)
  ├── useComponentName.ts      # Component-specific hook
  ├── types.ts                 # Component types
  └── index.ts                 # Barrel export
```
Or is it flat files? Document EXACTLY what the reference uses.

#### 1.4 — State Management Analysis

```bash
# Find state management patterns
grep -rn "createContext\|useContext\|createStore\|useStore\|zustand\|redux\|recoil\|jotai\|Provider" \
  --include="*.ts" --include="*.tsx" . | grep -v node_modules | head -20

# Find data fetching patterns
grep -rn "useSWR\|useQuery\|fetch(\|axios\|getServerSideProps\|getStaticProps\|generateStaticParams\|use server" \
  --include="*.ts" --include="*.tsx" . | grep -v node_modules | head -20
```

Document:
- Global state solution (Context, Zustand, Redux, Jotai, etc.)
- Store structure and naming conventions
- Server state management (SWR, React Query, Server Components)
- Data fetching layer (API client setup, error handling)
- Loading/error state patterns
- Caching strategy

#### 1.5 — Routing & Navigation Analysis

```bash
# App Router patterns
find . -path "*/app/*" -name "page.tsx" -o -name "layout.tsx" -o -name "loading.tsx" \
  -o -name "error.tsx" -o -name "not-found.tsx" | sort | head -20

# OR Pages Router patterns
find . -path "*/pages/*" -name "*.tsx" | sort | head -20

# Navigation patterns
grep -rn "useRouter\|usePathname\|useSearchParams\|Link\|redirect\|useNavigation" \
  --include="*.tsx" --include="*.ts" . | grep -v node_modules | head -15
```

Document:
- Router type (App Router / Pages Router / hybrid)
- Route organization (flat vs nested)
- Layout patterns (shared layouts, nested layouts)
- Loading and error boundary patterns
- Navigation patterns (Link component usage, programmatic navigation)
- Middleware usage
- Route guards / auth patterns

#### 1.6 — Orchestra Framework Specifics

```bash
# Find Orchestra-specific imports and usage
grep -rn "orchestra\|Orchestra\|@orchestra" --include="*.ts" --include="*.tsx" \
  --include="*.js" --include="*.json" . | grep -v node_modules | head -30

# Find design token usage
grep -rn "token\|Token\|theme\|Theme\|design-system\|designSystem" \
  --include="*.ts" --include="*.tsx" --include="*.css" . | \
  grep -v node_modules | head -20
```

Document everything Orchestra-specific:
- Import paths and package names
- Component wrappers or HOCs
- Token/theme system
- Layout primitives
- Form components and validation
- Table/data display components
- Modal/dialog patterns
- Toast/notification patterns
- Any Orchestra-specific hooks or utilities

#### 1.7 — Generate the Convention Rulebook

Compile ALL findings into a structured document:

```markdown
# Convention Rulebook (from Reference Repo)

## 1. Project Structure
[exact folder layout with descriptions]

## 2. Framework Config
[versions, tsconfig, path aliases, etc.]

## 3. Component Conventions
### Declaration: [pattern]
### Props: [pattern]
### Exports: [pattern]
### File structure: [pattern]

## 4. Styling Conventions
[CSS approach, token usage, responsive patterns]

## 5. State Management
[global state, server state, local state patterns]

## 6. Data Fetching
[API client, hooks, error handling, caching]

## 7. Routing
[router type, organization, layouts, guards]

## 8. Orchestra Framework
[specific components, tokens, patterns]

## 9. Testing
[framework, patterns, file locations]

## 10. Code Style
[ESLint rules, Prettier config, naming conventions]
```

**Save to**: `recovery/convention_rulebook.md`

---

### STAGE 2: Analyze the Target (Deviation Mapping)

> Goal: Compare the target repo against every rule in the Convention Rulebook.
> NOW open the TARGET repo.

#### 2.1 — Run the Same Analysis on Target

Repeat Steps 1.1 through 1.6 on the TARGET repo, but this time compare
every finding against the Convention Rulebook.

#### 2.2 — Build a Deviation Report

For EACH convention rule, document:

```markdown
# Deviation Report: [target-repo-name]

## Summary
- Total conventions checked: [N]
- Conforming: [N] (X%)
- Minor deviations: [N] (X%)
- Major deviations: [N] (X%)
- Missing/absent: [N] (X%)

## Deviations by Category

### Folder Structure
| Convention | Reference | Target | Severity | Fix Effort |
|-----------|-----------|--------|----------|------------|
| Component location | src/components/feature/ | components/ (flat) | MAJOR | Medium |
| Hooks location | src/hooks/ | mixed in components | MINOR | Low |

### Component Patterns
| Convention | Reference | Target | Severity | Fix Effort |
|-----------|-----------|--------|----------|------------|
| Declaration | Arrow + named export | Class components (12 files) | MAJOR | High |
| Props typing | Interface + Props suffix | Inline types / any | MAJOR | Medium |

### State Management
[same table format]

### Data Fetching
[same table format]

### Routing
[same table format]

### Orchestra Adoption
[same table format]

### Code Style
[same table format]
```

**Save to**: `recovery/[target-repo]_deviation_report.md`

---

### STAGE 3: Plan the Refactor (Prioritized Migration Plan)

> Goal: Create an actionable, prioritized refactoring plan.

#### 3.1 — Prioritize Deviations

Group deviations into refactoring waves:

**Wave 1 — Foundation (do first, unblocks everything else)**
- Path aliases and tsconfig alignment
- Package.json dependencies (add Orchestra, align React version)
- ESLint/Prettier config alignment
- Folder structure migration

**Wave 2 — Component Modernization**
- Class components → Functional components with hooks
- Props typing alignment
- Export pattern standardization
- File structure per component

**Wave 3 — Framework Alignment**
- Router migration (if Pages → App Router)
- Layout adoption
- Loading/error boundary patterns
- Data fetching pattern migration

**Wave 4 — Design System Adoption**
- Replace custom UI with Orchestra components
- Adopt design tokens
- Align styling approach
- Theme/dark mode integration

**Wave 5 — State & Data Layer**
- State management migration
- API client alignment
- Caching strategy adoption
- Server component patterns (React 18)

#### 3.2 — Generate Per-File Refactoring Tasks

For each file that needs changes:

```markdown
### File: src/components/UserProfile.tsx

**Current state**: Class component, inline styles, direct fetch calls
**Target state**: Functional component, Orchestra tokens, SWR hook

**Changes required**:
1. Convert class → arrow function component
2. Replace this.state → useState hooks
3. Replace componentDidMount → useEffect
4. Replace inline styles → Orchestra design tokens
5. Replace fetch → useSWR with API client
6. Extract UserProfileProps interface
7. Add barrel export in index.ts
8. Move to correct folder: features/user/components/UserProfile/

**Estimated effort**: Medium
**Dependencies**: Wave 1 folder structure must be done first
```

#### 3.3 — Generate the Migration Plan Document

```markdown
# UI Refactoring Plan: [target-repo]
> Based on Convention Rulebook from [reference-repo]
> Generated [date]

## Executive Summary
[2-3 sentences on scope and timeline]

## Migration Waves

### Wave 1: Foundation (Est: X days)
| Task | Files Affected | Effort | Notes |
|------|---------------|--------|-------|
| [task] | [count] | [H/M/L] | [notes] |

### Wave 2: Component Modernization (Est: X days)
[same format]

### Wave 3: Framework Alignment (Est: X days)
[same format]

### Wave 4: Design System Adoption (Est: X days)
[same format]

### Wave 5: State & Data Layer (Est: X days)
[same format]

## File-by-File Change List
[detailed list from 3.2]

## Risk Assessment
| Risk | Mitigation |
|------|-----------|
| Breaking existing functionality | Run tests after each wave |
| Orchestra version mismatch | Pin exact versions from reference |

## Testing Strategy
- Run existing tests after each wave
- Add new tests for migrated components
- Visual regression testing for UI changes
```

**Save to**: `recovery/[target-repo]_refactor_plan.md`

---

### STAGE 4: Execute the Refactor (Guided Code Changes)

> Goal: Produce actual refactored code, wave by wave.

#### 4.1 — For Each File in the Plan

1. **Read the current file** in the target repo
2. **Read the equivalent pattern** from the reference repo (or Convention Rulebook)
3. **Generate the refactored version** that:
   - Preserves ALL existing business logic
   - Changes ONLY the patterns to match the standard
   - Adds proper TypeScript types
   - Uses Orchestra components where applicable
   - Follows the exact import paths from reference

4. **Show a diff** explaining what changed and why:
   ```
   // BEFORE: Class component with inline styles
   // AFTER: Functional component with Orchestra tokens
   // WHY: Convention Rulebook §3 — Component Declaration Pattern
   ```

#### 4.2 — React 18 Specific Migrations

Always check for and apply these React 18 patterns:

**A. Automatic Batching**
- Remove manual batching workarounds (flushSync unless intentional)
- State updates in promises/timeouts are now auto-batched

**B. useTransition / useDeferredValue**
- Identify expensive re-renders and apply useTransition
- Use useDeferredValue for search/filter inputs

**C. Suspense for Data Fetching**
- Replace loading state booleans with Suspense boundaries
- Use React.lazy for code splitting where applicable

**D. Server Components (if App Router)**
- Identify components that don't need interactivity → Server Components
- Add `'use client'` directive only where needed
- Move data fetching to server components

**E. useId for SSR-safe IDs**
- Replace manual ID generation with useId()

**F. Strict Mode Compliance**
- Ensure effects handle double-invocation in development
- Remove unsafe lifecycle methods

#### 4.3 — Validation Checklist (per file)

After refactoring each file, verify:
- [ ] Business logic preserved (no functional changes)
- [ ] TypeScript compiles with no errors
- [ ] Props interface matches usage
- [ ] Imports use correct path aliases
- [ ] Orchestra components used where applicable
- [ ] React 18 patterns applied where beneficial
- [ ] Tests still pass (or updated for new patterns)
- [ ] No unused imports or dead code

---

## Output Format

This skill produces 3 documents:

1. **Convention Rulebook** → `recovery/convention_rulebook.md`
   (The learned standard from the reference repo)

2. **Deviation Report** → `recovery/[target]_deviation_report.md`
   (Gap analysis between target and standard)

3. **Refactoring Plan** → `recovery/[target]_refactor_plan.md`
   (Prioritized migration waves with file-level tasks)

Plus actual refactored code files during Stage 4.

## Important Rules

- NEVER change business logic during refactoring. Pattern changes ONLY.
- ALWAYS trace each change back to a specific Convention Rulebook rule.
- When unsure about a pattern, default to what the reference repo does.
- Preserve ALL existing tests — update them to match new patterns.
- If the reference repo uses Orchestra components, document the exact
  import paths and props so the target can adopt them correctly.
- React 18 migrations should be safe and incremental, not forced.
- Run `npx tsc --noEmit` after each wave to catch type errors.
- Save ALL intermediate outputs to the `recovery/` folder.
