# Agent Workspace UI: design bundle

A three-panel workspace in the style of Claude Code: sessions on the left, conversation in the center, a tabbed context pane (diff, files, terminal, preview, plan) on the right.

## Contents

| File | What it is |
|---|---|
| `DESIGN.md` | The design system: principles, layout, color/type/spacing/motion tokens, component specs, keyboard map, accessibility, voice, implementation notes. Put it at the root of a repo so coding agents read it before building UI. |
| `workspace.html` | Single-file clickable prototype built from `DESIGN.md`. No build step. Open it in a browser (needs internet once for the Inter and JetBrains Mono fonts; falls back to system fonts offline). |
| `README.md` | This file. |

Published prototype (private, owner access only): https://claude.ai/artifact/Tw3i2exeFvgVYv3FyvaPhP

## Prototype features

- Three resizable panes: drag the dividers, use arrow keys on a focused divider (16px steps), double-click to reset. Sizes, open state and the active tab persist in local storage.
- Sessions list with status dots (running, needs input, unread, error), search, and per-session transcripts.
- Transcript with collapsible tool-call groups, a permission card (Allow, Allow always, Deny), a composer that sends on Enter and becomes Stop while a run is active, and a "Jump to latest" pill.
- Context pane with Diff, Files, Terminal, Preview (mock upload) and Plan tabs.
- Light and dark themes with a toggle; follows the OS setting by default.
- Below 1100px the context pane becomes a drawer; below 800px the sessions pane does too.

## Keyboard shortcuts

| Action | Shortcut |
|---|---|
| Toggle sessions pane | `Cmd/Ctrl + B` |
| Toggle context pane | `Cmd/Ctrl + \` |
| Focus composer | `Cmd/Ctrl + L` |
| Context tabs 1 to 5 | `Cmd/Ctrl + 1` to `5` |
| Stop run | `Esc` |
| Permission card | `Y` allow, `A` always, `N` deny |
| Send / newline | `Enter` / `Shift + Enter` |

## Notes and limits

- The agent in the prototype is simulated: replies are canned and no real model or backend is involved.
- Colors and fonts are an original warm-neutral palette inspired by the Claude Code look, not Anthropic's official brand values. Swap the tokens in `DESIGN.md` and in the `:root` block of `workspace.html` to rebrand.
- Checked in a browser at desktop and phone widths in dark mode. Light mode and every interaction were not exhaustively tested.

## Suggested next steps

1. Scaffold a Vite + React + TypeScript project using `react-resizable-panels`, Tailwind mapped to the tokens, Radix primitives, Zustand, `xterm.js` and a diff viewer.
2. Connect it to the Claude Agent SDK over WebSocket or SSE and render real messages, tool calls and diffs.
3. Add Storybook stories and visual regression tests for light and dark.

Created 2026-11-12.
