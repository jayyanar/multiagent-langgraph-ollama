# DESIGN.md — Agent Workspace UI

A three-panel desktop workspace for working with a coding agent: **Sessions** (left), **Conversation** (center), **Context** (right). This file is the source of truth for look, feel and behavior. When code and this file disagree, fix one of them in the same change.

> Agents: read this fully before writing UI. Use tokens, never raw values. If a needed token or pattern is missing, propose an addition here first.

---

## 1. Principles

1. **Conversation is the product.** The center column gets priority for space, contrast and motion. Side panels support it; they never compete.
2. **Calm density.** Information-rich but quiet: small type, generous line height, restrained color. No decoration that carries no meaning.
3. **Show the work, collapse the noise.** Tool calls, diffs and logs are first-class but collapsed by default; one click reveals detail.
4. **Always legible state.** The user can tell at a glance: what is running, what needs them, what finished.
5. **Keyboard first, mouse friendly.** Every action has a shortcut and a visible affordance.
6. **Warm, not sterile.** Warm neutrals and one accent. Light and dark are equal citizens.

---

## 2. Layout

```
┌──────────────┬────────────────────────────────────┬─────────────────────┐
│  Sessions    │  Conversation                      │  Context            │
│  (sidebar)   │  header · transcript · composer    │  tabs: Diff Files   │
│              │                                    │  Terminal Preview   │
└──────────────┴────────────────────────────────────┴─────────────────────┘
```

| Region | Default | Min | Max | Collapsible | Persist |
|---|---|---|---|---|---|
| Sessions | 18% (≈260px) | 220px | 360px | Yes, `⌘B` | size + open |
| Conversation | flex | 420px | — | No | — |
| Context | 32% | 320px | 60% | Yes, `⌘\` | size + open + active tab |

- Dividers are 1px (`--border`), with a 9px invisible hit area. On hover/drag they become `--accent` and the cursor is `col-resize`. Double-click resets to default.
- Window chrome: 44px top bar spanning all panels (drag region, traffic lights inset 16px, pane toggles at the far edges).
- Conversation content is capped at **720px** and centered; extra width is whitespace, not wider lines.
- **Responsive:** `< 1100px` Context becomes an overlay drawer; `< 800px` Sessions also becomes an overlay. Center never drops below its minimum.
- Panes mount lazily; hidden tabs keep state (terminal scrollback, diff scroll position).

---

## 3. Design tokens

Implement as CSS variables on `:root`, overridden under `[data-theme="dark"]`. Respect `prefers-color-scheme` by default, with a user override.

### 3.1 Color

Neutral scale is warm (slight red/yellow bias). Accent is a single terracotta-style orange; do not introduce a second brand hue.

| Token | Light | Dark | Use |
|---|---|---|---|
| `--bg-app` | `#FAF9F5` | `#1F1E1D` | App background, center column |
| `--bg-sidebar` | `#F3F1EA` | `#262624` | Sessions pane |
| `--bg-raised` | `#FFFFFF` | `#2D2C2A` | Cards, composer, menus |
| `--bg-sunken` | `#EFEDE5` | `#191817` | Code blocks, terminal, diff gutters |
| `--bg-hover` | `#00000008` | `#FFFFFF0A` | Row/button hover overlay |
| `--bg-selected` | `#0000000F` | `#FFFFFF14` | Selected row |
| `--border` | `#E6E3D9` | `#3A3836` | Dividers, outlines |
| `--border-strong` | `#D2CEC0` | `#4A4744` | Inputs, focused containers |
| `--text` | `#1F1E1D` | `#ECEAE3` | Primary text |
| `--text-muted` | `#6B6860` | `#A9A59B` | Secondary text, metadata |
| `--text-faint` | `#97938A` | `#77736B` | Placeholders, disabled |
| `--accent` | `#C96442` | `#D9775A` | Primary action, focus, active indicators |
| `--accent-fg` | `#FFFFFF` | `#1F1E1D` | Text on accent |
| `--accent-soft` | `#C9644214` | `#D9775A22` | Accent tints, user message bubble |
| `--success` | `#2F7D4F` | `#5DB985` | Added lines, passed, done |
| `--warning` | `#A8741A` | `#E0B04C` | Needs attention, permission |
| `--danger` | `#B3372E` | `#EA7B72` | Removed lines, errors, destructive |
| `--info` | `#3B6FB0` | `#7FA8E0` | Links, neutral status |

Diff tints: `--diff-add-bg` = `--success` @ 12%, `--diff-del-bg` = `--danger` @ 12%; word-level highlights at 24%.

**Rules**
- Body text contrast ≥ **4.5:1**, UI components ≥ **3:1**. Verify both themes.
- Color is never the only signal: pair status colors with an icon or label.
- Accent covers < 5% of any screen. One primary action per view.
- Never pure `#000` or `#FFF` for text on backgrounds.

### 3.2 Typography

| Role | Family | Notes |
|---|---|---|
| UI / prose | `Inter`, system-ui, -apple-system, "Segoe UI", sans-serif | Optional serif for assistant prose: `"Source Serif 4", Georgia, serif` — pick one per product and keep it consistent |
| Code | `"JetBrains Mono"`, "SF Mono", Menlo, monospace | Ligatures off in diffs and terminal |

| Token | Size / line | Weight | Use |
|---|---|---|---|
| `--text-xs` | 11 / 16 | 500 | Badges, timestamps, shortcuts |
| `--text-sm` | 13 / 20 | 400–500 | Sidebar rows, tabs, tool cards, metadata |
| `--text-base` | 15 / 24 | 400 | Conversation prose, composer |
| `--text-lg` | 17 / 26 | 600 | Section titles |
| `--text-xl` | 22 / 30 | 600 | Empty-state headings |
| `--code` | 13 / 20 | 400 | Inline and block code, terminal, diffs |

- Tabular numerals (`font-variant-numeric: tabular-nums`) for counts, durations, diff stats.
- Max prose line length ≈ 70ch.
- Letter-spacing: 0 everywhere except `--text-xs` uppercase labels (+0.04em).

### 3.3 Spacing, radius, elevation

- **Spacing:** 4px base. Scale: `0, 2, 4, 6, 8, 12, 16, 20, 24, 32, 48`. Panel padding 16px; compact rows 6–8px vertical.
- **Radius:** `--r-sm` 6px (chips, inputs in toolbars), `--r-md` 10px (buttons, rows, tool cards), `--r-lg` 16px (composer, menus, dialogs), `--r-full` for avatars and status dots.
- **Elevation:** prefer borders over shadows. Shadows only for floating layers.
  - `--shadow-menu`: `0 8px 24px rgb(0 0 0 / .12), 0 0 0 1px var(--border)`
  - `--shadow-dialog`: `0 16px 48px rgb(0 0 0 / .20), 0 0 0 1px var(--border)`
- **Z-index:** base 0, sticky 10, drawer 30, menu 40, dialog 50, toast 60.

### 3.4 Motion

| Token | Value | Use |
|---|---|---|
| `--dur-fast` | 120ms | Hover, press, color changes |
| `--dur-base` | 200ms | Collapse/expand, tab switch, menus |
| `--dur-slow` | 320ms | Pane open/close, drawers |
| `--ease` | `cubic-bezier(.2, .0, .0, 1)` | All transitions |

- Animate `opacity` and `transform` only; never animate layout properties in the transcript.
- Streaming text appears token by token with no per-token animation. Use one soft pulsing indicator for "working".
- Honor `prefers-reduced-motion`: replace movement with instant or fade-only changes.

---

## 4. Components

### 4.1 Sessions sidebar
- Top: **New session** (primary, full width) and search field (`⌘K`).
- Grouped list (Pinned, Today, Yesterday, Earlier). Row height 32px, 8px horizontal padding, `--r-md`.
- Row anatomy: status dot · title (single line, ellipsis) · relative time (`--text-faint`, hidden on hover in favor of actions).
- **Status dot (8px):**
  - running: accent, pulsing
  - needs input / permission: warning, solid
  - unread result: info, solid
  - idle: none
  - error: danger, solid
- Hover reveals pin and archive icon buttons. Selected row: `--bg-selected` plus a 2px accent bar on the left edge.
- Footer: account/settings, usage meter, theme toggle.

### 4.2 Conversation
**Header (44px):** session title (editable on click), branch/folder chip, model chip, overflow menu. Bottom border appears only after scrolling.

**Transcript:** vertical rhythm of 24px between turns, 8px between blocks within a turn.
- **User message:** right-aligned bubble on `--accent-soft`, `--r-lg`, max 85% width. Attachments appear as chips above text.
- **Assistant message:** no bubble, full column width, `--text-base`. Markdown fully styled (lists, tables, quotes, headings capped at `--text-lg`).
- **Code block:** `--bg-sunken`, 1px border, `--r-md`, header with language and Copy button, horizontal scroll (never wrap by default).
- **Tool call card:** collapsed one-liner (`icon · verb · target · status · duration`). Expand to input/output. Use `--text-sm`, `--bg-raised`, 1px border. Consecutive calls group under one disclosure: "Read 4 files, ran 2 commands".
- **Diff stat chip:** `+12 −3 · file.ts`, click to open in Context → Diff.
- **Permission request:** inline card with warning left border. Buttons: **Allow** (primary), **Allow always**, **Deny**. Keyboard: `Y` / `A` / `N`. Blocks the run visibly, and the session shows the warning dot.
- **Thinking/working:** a single muted line with a pulsing dot, elapsed time, and a **Stop** button (`Esc`).
- **Errors:** inline, danger-tinted card with plain-language message, expandable raw detail, and a Retry action.
- **Autoscroll:** follow the stream only while the user is within 80px of the bottom; otherwise show a floating "Jump to latest" pill.

**Composer:** pinned bottom, centered at the same 720px, `--bg-raised`, 1px `--border-strong`, `--r-lg`, min 2 rows, auto-grows to 12 rows then scrolls.
- Contents: attachment chips, textarea, toolbar row (attach `+`, mode/permission picker, model picker, send).
- `Enter` sends, `Shift+Enter` newline, `↑` recalls last prompt, `/` opens slash commands, `@` opens file mentions, drag-and-drop attaches files.
- Send becomes **Stop** while running. Disabled send uses `--text-faint`, never hidden.
- Focus ring: 2px `--accent` at 40% opacity plus the border switching to `--accent`.

### 4.3 Context pane
Tab bar (36px): **Diff · Files · Terminal · Preview · Plan** (extensible). Tabs are text-only with a 2px accent underline when active; a count badge for Diff. Overflow collapses into a `…` menu. Pane has its own close button.

- **Diff:** file list (left, collapsible) + unified/split toggle. Line numbers in `--bg-sunken` gutters, word-level highlights, sticky file headers, per-file collapse, "Open in editor" action. Added/removed use tints + `+`/`−` glyphs.
- **Files:** tree with 24px rows, chevrons, file-type icons, modified markers (dot, success/warning). Click opens a read-only viewer with syntax highlighting.
- **Terminal:** `--bg-sunken`, code font, ANSI 16-color palette mapped to tokens, selectable text, copy on select, clear action. Read-only unless the user explicitly takes over.
- **Preview:** iframe/webview with address bar, reload, device-size toggle (desktop / tablet / mobile), and a console drawer.
- **Plan:** checklist with pending / in-progress / done states, updated live from the agent.
- **Empty state:** quiet illustration-free message: one line of explanation, one action.

### 4.4 Shared controls
| Control | Spec |
|---|---|
| **Button** | Height 32px (sm 28, lg 40). Variants: *primary* (accent fill), *secondary* (raised + border), *ghost* (transparent, hover overlay), *danger*. Padding 0 12px, `--r-md`, label `--text-sm` 500. Loading shows an inline spinner and keeps width. |
| **Icon button** | 28×28 hit area minimum 32×32 with padding, tooltip after 500ms, `aria-label` required. |
| **Input** | 32px, `--bg-raised`, 1px `--border-strong`, `--r-md`, placeholder `--text-faint`. Error: danger border + message below. |
| **Tabs / segmented** | Text 13px/500, active has accent underline (tabs) or raised pill (segmented). |
| **Menu / popover** | `--bg-raised`, `--shadow-menu`, `--r-lg`, 4px padding, items 32px, shortcuts right-aligned in `--text-faint`. Typeahead and arrow-key navigation. |
| **Dialog** | Max 480px (form) or 720px (content), `--r-lg`, scrim `rgb(0 0 0 / .4)`, focus trapped, `Esc` closes, primary action rightmost. |
| **Tooltip** | `--text` on inverted background, 12px, max 240px, no interactive content. |
| **Toast** | Bottom-center, 4s auto-dismiss (errors persist), max 3 stacked, optional action. |
| **Badge/chip** | 20px high, `--text-xs`, `--r-sm`, neutral by default; tinted variants for status. |
| **Skeleton** | `--bg-hover` shimmer; only for loads > 300ms. |

---

## 5. Interaction & keyboard

| Action | Shortcut |
|---|---|
| New session | `⌘N` |
| Command palette / search sessions | `⌘K` |
| Toggle sidebar | `⌘B` |
| Toggle context pane | `⌘\` |
| Focus composer | `⌘L` |
| Switch context tab | `⌘1…5` |
| Previous / next session | `⌘[` / `⌘]` |
| Stop run | `Esc` |
| Send / newline | `Enter` / `Shift+Enter` |
| Open shortcut help | `?` |

- Every shortcut is shown in its tooltip and menu item.
- Focus order follows visual order: sidebar → transcript → composer → context pane. Panes are landmarks (`nav`, `main`, `complementary`).
- Focus is always visible (2px accent ring, 2px offset). Never remove outlines without replacement.
- Destructive actions (delete, discard changes) require confirmation or provide Undo for 6 seconds.
- Optimistic UI: user message appears instantly; failures offer Retry in place.

---

## 6. States to design for every view

Every component and pane must define: **default · hover · active/pressed · focus · selected · disabled · loading · empty · error · offline**. Long titles truncate with ellipsis and a full-text tooltip. Streaming and very long outputs (10k+ lines) must stay responsive: virtualize lists, cap rendered tool output with "Show all".

---

## 7. Accessibility

- WCAG 2.2 AA minimum, both themes.
- Full keyboard operability, including resizing panels (`←/→` on a focused divider, 16px steps).
- Screen readers: transcript is a `log` region with polite live updates; announce "Run finished", "Permission needed" assertively.
- Hit targets ≥ 32×32 (44×44 on touch).
- Text scales to 200% without loss; layout uses `rem` for type, `px` only for borders.
- Respect `prefers-reduced-motion`, `prefers-contrast`, and forced-colors.

---

## 8. Voice & content

- Plain, direct, lower ceremony. Sentence case everywhere ("New session", not "New Session").
- Verbs on buttons ("Allow", "Discard changes"), never "OK" or "Yes".
- Errors say what happened, why if known, and what to do next. No blame, no exclamation marks.
- Empty states: one sentence + one action.
- Dates relative within 7 days, absolute after; always show the full timestamp on hover.

---

## 9. Implementation notes

- **Stack:** React + TypeScript, Tailwind mapped to the tokens above (extend theme, don't hard-code), `react-resizable-panels`, Radix primitives for menus/dialogs/tabs, Zustand for UI state, `xterm.js` for the terminal, Monaco diff or `react-diff-view` for diffs.
- **Tokens as single source:** keep them in `tokens.css`; generate the Tailwind theme from it. No raw hex in components.
- **Persisted UI state:** pane sizes/open flags, active tab, theme, and diff mode in local storage, scoped per window.
- **Performance budget:** first interaction < 100ms; typing latency < 16ms with a 50k-token transcript; no layout shift when streaming.
- **Testing:** Storybook stories for each component and state; visual regression in light and dark; axe checks in CI.

---

## 10. Do / Don't

**Do**
- Use tokens, 4px spacing, and the type scale.
- Collapse tool output by default.
- Keep one accent, one primary action per view.
- Make state (running / waiting / done) visible in the sidebar.

**Don't**
- Add gradients, glows, heavy shadows, or emoji as UI icons.
- Use color alone to convey status.
- Widen the reading column on large screens.
- Animate layout while content is streaming.
- Invent new radii, font sizes, or colors without updating this file.

---

## 11. Changelog

| Date | Change |
|---|---|
| 2026-11-12 | Initial version |
